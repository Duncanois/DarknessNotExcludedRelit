# Reconstructed Darkness Not Excluded Relit 1.4.1

Recovered on 20 November 2026 from the local Steam item 3609476592 and January repository commit b83df126e939c7d7c75e1963ae9f90994b48fc97.

The original source layout and comments are retained. The only recovered gameplay-source change is in `src/features/InGameConfig/DarknessToggleButton.cs`: remove the right-click options action and its tooltip instructions, matching the published DLL.

The project targets .NET Framework 4.8, version 1.4.1, with PLib 4.19.0. Its build configuration was reconstructed; it is not the lost laptop project file. It references the game's Newtonsoft.Json.dll and current game assemblies. It does not install or upload anything.

Build from this folder:

```powershell
dotnet build project.csproj -t:Package
```

For another game location:

```powershell
dotnet build project.csproj -t:Package '-p:GameLibsDir=D:\SteamLibrary\steamapps\common\OxygenNotIncluded\OxygenNotIncluded_Data\Managed'
```

The resulting four-file mod package is written to `artifacts/package`. The supplied mod metadata and preview are copied unchanged from the preserved Steam download.

Validation: packaging passed with zero warnings and errors. All 205 decompiled code files, including embedded PLib, matched the published DLL after excluding assembly metadata. The DLL bytes differ; build provenance and dependency references are not identical. No game launch, save loading, or gameplay testing was performed.

This archive is a staged recovery candidate. The active January source has not been overwritten. Raw decompiler output and the input backups are preserved alongside the recovery audit outside the repository.
