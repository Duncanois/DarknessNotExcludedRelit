using System;
using System.Collections.Generic;
using System.Reflection;
using PeterHan.PLib.Core;
using PeterHan.PLib.Detours;
using UnityEngine;

namespace PeterHan.PLib.Buildings
{
	internal abstract class ColoredRangeVisualizer : KMonoBehaviour
	{
		private delegate ulong RegisterCellChangedHandlerNew(CellChangeMonitor instance, Transform transform, Action<object> callback);

		private delegate int RegisterCellChangedHandlerOld(CellChangeMonitor instance, Transform transform, System.Action callback, string handler);

		private delegate void UnregisterCellChangedHandlerNew(CellChangeMonitor instance, ref ulong id);

		private delegate void UnregisterCellChangedHandlerOld(CellChangeMonitor instance, Transform transform, System.Action callback);

		protected sealed class VisCellData : IComparable<VisCellData>
		{
			public int Cell { get; }

			public KBatchedAnimController Controller { get; private set; }

			public Color Tint { get; }

			public VisCellData(int cell)
				: this(cell, Color.white)
			{
			}

			public VisCellData(int cell, Color tint)
			{
				Cell = cell;
				Controller = null;
				Tint = tint;
			}

			public int CompareTo(VisCellData other)
			{
				if (other == null)
				{
					throw new ArgumentNullException("other");
				}
				return Cell.CompareTo(other.Cell);
			}

			public void CreateController(Grid.SceneLayer sceneLayer)
			{
				Controller = FXHelpers.CreateEffect("transferarmgrid_kanim", Grid.CellToPosCCC(Cell, sceneLayer), null, update_looping_sounds_position: false, sceneLayer, set_inactive: true);
				Controller.destroyOnAnimComplete = false;
				Controller.visibilityType = KAnimControllerBase.VisibilityType.Always;
				Controller.gameObject.SetActive(value: true);
				Controller.Play(PRE_ANIMS, KAnim.PlayMode.Loop);
				Controller.TintColour = Tint;
			}

			public void Destroy()
			{
				if (Controller != null)
				{
					Controller.destroyOnAnimComplete = true;
					Controller.Play(POST_ANIM);
					Controller = null;
				}
			}

			public override bool Equals(object obj)
			{
				if (obj is VisCellData visCellData && visCellData.Cell == Cell)
				{
					return Tint.Equals(visCellData.Tint);
				}
				return false;
			}

			public override int GetHashCode()
			{
				return Cell;
			}

			public override string ToString()
			{
				return "CellData[cell={0:D},color={1}]".F(Cell, Tint);
			}
		}

		private static readonly RegisterCellChangedHandlerNew REGISTER_NEW;

		private static readonly DetouredMethod<RegisterCellChangedHandlerOld> REGISTER_OLD;

		private static readonly UnregisterCellChangedHandlerNew UNREGISTER_NEW;

		private static readonly DetouredMethod<UnregisterCellChangedHandlerOld> UNREGISTER_OLD;

		private const string ANIM_NAME = "transferarmgrid_kanim";

		private static readonly HashedString[] PRE_ANIMS;

		private static readonly HashedString POST_ANIM;

		[MyCmpGet]
		protected BuildingPreview preview;

		[MyCmpGet]
		protected Rotatable rotatable;

		private readonly HashSet<VisCellData> cells;

		private ulong handlerID;

		public Grid.SceneLayer Layer { get; set; }

		static ColoredRangeVisualizer()
		{
			REGISTER_OLD = typeof(CellChangeMonitor).DetourLazy<RegisterCellChangedHandlerOld>("RegisterCellChangedHandler");
			UNREGISTER_OLD = typeof(CellChangeMonitor).DetourLazy<UnregisterCellChangedHandlerOld>("UnregisterCellChangedHandler");
			PRE_ANIMS = new HashedString[2] { "grid_pre", "grid_loop" };
			POST_ANIM = "grid_pst";
			MethodInfo methodSafe = typeof(CellChangeMonitor).GetMethodSafe("RegisterCellChangedHandler", false, typeof(Transform), typeof(Action<object>));
			if (methodSafe != null)
			{
				REGISTER_NEW = methodSafe.Detour<RegisterCellChangedHandlerNew>();
				UNREGISTER_NEW = typeof(CellChangeMonitor).Detour<UnregisterCellChangedHandlerNew>("UnregisterCellChangedHandler");
			}
			else
			{
				REGISTER_NEW = null;
				UNREGISTER_NEW = null;
			}
		}

		protected ColoredRangeVisualizer()
		{
			cells = new HashSet<VisCellData>();
			handlerID = 0uL;
			Layer = Grid.SceneLayer.FXFront;
		}

		private void CreateVisualizers()
		{
			HashSetPool<VisCellData, ColoredRangeVisualizer>.PooledHashSet pooledHashSet = HashSetPool<VisCellData, ColoredRangeVisualizer>.Allocate();
			ListPool<VisCellData, ColoredRangeVisualizer>.PooledList pooledList = ListPool<VisCellData, ColoredRangeVisualizer>.Allocate();
			try
			{
				if (gameObject != null)
				{
					VisualizeCells(pooledHashSet);
				}
				foreach (VisCellData cell in cells)
				{
					if (pooledHashSet.Remove(cell))
					{
						pooledList.Add(cell);
					}
					else
					{
						cell.Destroy();
					}
				}
				foreach (VisCellData item in pooledHashSet)
				{
					item.CreateController(Layer);
					pooledList.Add(item);
				}
				cells.Clear();
				foreach (VisCellData item2 in pooledList)
				{
					cells.Add(item2);
				}
			}
			finally
			{
				pooledHashSet.Recycle();
				pooledList.Recycle();
			}
		}

		private void OnCellChange(object _)
		{
			CreateVisualizers();
		}

		protected override void OnCleanUp()
		{
			Unsubscribe(-1503271301);
			if (preview != null)
			{
				UnregisterCellChangedHandler();
				if (rotatable != null)
				{
					Unsubscribe(-1643076535);
				}
			}
			RemoveVisualizers();
			base.OnCleanUp();
		}

		private void OnRotated(object _)
		{
			CreateVisualizers();
		}

		private void OnSelect(object data)
		{
			if (data is bool flag)
			{
				Vector3 position = transform.position;
				if (flag)
				{
					PGameUtils.PlaySound("RadialGrid_form", position);
					CreateVisualizers();
				}
				else
				{
					PGameUtils.PlaySound("RadialGrid_disappear", position);
					RemoveVisualizers();
				}
			}
		}

		protected override void OnSpawn()
		{
			base.OnSpawn();
			Subscribe(-1503271301, OnSelect);
			if (preview != null)
			{
				RegisterCellChangedHandler();
				if (rotatable != null)
				{
					Subscribe(-1643076535, OnRotated);
				}
			}
		}

		private void RegisterCellChangedHandler()
		{
			if (REGISTER_NEW != null)
			{
				handlerID = REGISTER_NEW(Singleton<CellChangeMonitor>.Instance, transform, OnCellChange);
			}
			else
			{
				REGISTER_OLD.Invoke(Singleton<CellChangeMonitor>.Instance, transform, CreateVisualizers, "ColoredRangeVisualizer.OnSpawn");
			}
		}

		private void RemoveVisualizers()
		{
			foreach (VisCellData cell in cells)
			{
				cell.Destroy();
			}
			cells.Clear();
		}

		protected int RotateOffsetCell(int baseCell, CellOffset offset)
		{
			if (rotatable != null)
			{
				offset = rotatable.GetRotatedCellOffset(offset);
			}
			return Grid.OffsetCell(baseCell, offset);
		}

		private void UnregisterCellChangedHandler()
		{
			if (UNREGISTER_NEW != null)
			{
				UNREGISTER_NEW(Singleton<CellChangeMonitor>.Instance, ref handlerID);
			}
			else
			{
				UNREGISTER_OLD.Invoke(Singleton<CellChangeMonitor>.Instance, transform, CreateVisualizers);
			}
		}

		protected abstract void VisualizeCells(ICollection<VisCellData> newCells);
	}
}
