using System;
using System.Collections.Generic;
using PeterHan.PLib.Core;
using STRINGS;
using TUNING;
using UnityEngine;

namespace PeterHan.PLib.Buildings
{
	internal sealed class PBuilding
	{
		private bool addedPlan;

		private bool addedStrings;

		private bool addedTech;

		private static readonly HashedString DEFAULT_CATEGORY = new HashedString("Base");

		public string AddAfter { get; set; }

		public bool AlwaysOperational { get; set; }

		public string Animation { get; set; }

		public string AudioCategory { get; set; }

		public string AudioSize { get; set; }

		public bool Breaks { get; set; }

		public HashedString Category { get; set; }

		public float ConstructionTime { get; set; }

		public EffectorValues Decor { get; set; }

		public string Description { get; set; }

		public string EffectText { get; set; }

		public bool Entombs { get; set; }

		public float ExhaustHeatGeneration { get; set; }

		public bool Floods { get; set; }

		public int? DefaultPriority { get; set; }

		public float HeatGeneration { get; set; }

		public int Height { get; set; }

		public int HP { get; set; }

		public IList<BuildIngredient> Ingredients { get; }

		public string ID { get; }

		public bool IndustrialMachine { get; set; }

		public IList<ConduitConnection> InputConduits { get; }

		public bool IsSolidTile { get; set; }

		public IList<LogicPorts.Port> LogicIO { get; }

		public string Name { get; private set; }

		public EffectorValues Noise { get; set; }

		public ObjectLayer ObjectLayer { get; set; }

		public IList<ConduitConnection> OutputConduits { get; }

		public float? OverheatTemperature { get; set; }

		public BuildLocationRule Placement { get; set; }

		public PowerRequirement PowerInput { get; set; }

		public PowerRequirement PowerOutput { get; set; }

		public PermittedRotations RotateMode { get; set; }

		public Grid.SceneLayer SceneLayer { get; set; }

		public string SubCategory { get; set; }

		public string Tech { get; set; }

		public HashedString ViewMode { get; set; }

		public int Width { get; set; }

		public PBuilding(string id, string name)
		{
			if (string.IsNullOrEmpty(id))
			{
				throw new ArgumentNullException("id");
			}
			if (string.IsNullOrEmpty(name))
			{
				throw new ArgumentNullException("name");
			}
			AddAfter = null;
			AlwaysOperational = false;
			Animation = "";
			AudioCategory = "Metal";
			AudioSize = "medium";
			Breaks = true;
			Category = DEFAULT_CATEGORY;
			ConstructionTime = 10f;
			Decor = TUNING.BUILDINGS.DECOR.NONE;
			DefaultPriority = null;
			Description = "Default Building Description";
			EffectText = "Default Building Effect";
			Entombs = true;
			ExhaustHeatGeneration = 0f;
			Floods = true;
			HeatGeneration = 0f;
			Height = 1;
			Ingredients = new List<BuildIngredient>(4);
			IndustrialMachine = false;
			InputConduits = new List<ConduitConnection>(4);
			HP = 100;
			ID = id;
			LogicIO = new List<LogicPorts.Port>(4);
			Name = name;
			Noise = NOISE_POLLUTION.NONE;
			ObjectLayer = PGameUtils.GetObjectLayer("Building", ObjectLayer.Building);
			OutputConduits = new List<ConduitConnection>(4);
			OverheatTemperature = null;
			Placement = BuildLocationRule.OnFloor;
			PowerInput = null;
			PowerOutput = null;
			RotateMode = PermittedRotations.Unrotatable;
			SceneLayer = Grid.SceneLayer.Building;
			SubCategory = "default";
			Tech = null;
			ViewMode = OverlayModes.None.ID;
			Width = 1;
			addedPlan = false;
			addedStrings = false;
			addedTech = false;
		}

		public BuildingDef CreateDef()
		{
			if (Width < 1)
			{
				throw new InvalidOperationException("Building width: " + Width);
			}
			if (Height < 1)
			{
				throw new InvalidOperationException("Building height: " + Height);
			}
			if (HP < 1)
			{
				throw new InvalidOperationException("Building HP: " + HP);
			}
			if (ConstructionTime.IsNaNOrInfinity())
			{
				throw new InvalidOperationException("Construction time: " + ConstructionTime);
			}
			int count = Ingredients.Count;
			if (count < 1)
			{
				throw new InvalidOperationException("No ingredients for build");
			}
			float[] array = new float[count];
			string[] array2 = new string[count];
			for (int i = 0; i < count; i++)
			{
				BuildIngredient buildIngredient = Ingredients[i];
				if (buildIngredient == null)
				{
					throw new ArgumentNullException("ingredient");
				}
				array[i] = buildIngredient.Quantity;
				array2[i] = buildIngredient.Material;
			}
			BuildingDef buildingDef = BuildingTemplates.CreateBuildingDef(ID, Width, Height, Animation, HP, Math.Max(0.1f, ConstructionTime), array, array2, 2400f, Placement, Decor, Noise);
			if (IsSolidTile)
			{
				buildingDef.BaseTimeUntilRepair = -1f;
				buildingDef.UseStructureTemperature = false;
				BuildingTemplates.CreateFoundationTileDef(buildingDef);
			}
			buildingDef.AudioCategory = AudioCategory;
			buildingDef.AudioSize = AudioSize;
			if (OverheatTemperature.HasValue)
			{
				buildingDef.Overheatable = true;
				buildingDef.OverheatTemperature = OverheatTemperature ?? 348.15f;
			}
			else
			{
				buildingDef.Overheatable = false;
			}
			if (PowerInput != null)
			{
				buildingDef.RequiresPowerInput = true;
				buildingDef.EnergyConsumptionWhenActive = PowerInput.MaxWattage;
				buildingDef.PowerInputOffset = PowerInput.PlugLocation;
			}
			if (PowerOutput != null)
			{
				buildingDef.RequiresPowerOutput = true;
				buildingDef.GeneratorWattageRating = PowerOutput.MaxWattage;
				buildingDef.PowerOutputOffset = PowerOutput.PlugLocation;
			}
			buildingDef.Breakable = Breaks;
			buildingDef.PermittedRotations = RotateMode;
			buildingDef.ExhaustKilowattsWhenActive = ExhaustHeatGeneration;
			buildingDef.SelfHeatKilowattsWhenActive = HeatGeneration;
			buildingDef.Floodable = Floods;
			buildingDef.Entombable = Entombs;
			buildingDef.ObjectLayer = ObjectLayer;
			buildingDef.SceneLayer = SceneLayer;
			buildingDef.ViewMode = ViewMode;
			if (InputConduits.Count > 1)
			{
				throw new InvalidOperationException("Only supports one input conduit");
			}
			foreach (ConduitConnection inputConduit in InputConduits)
			{
				buildingDef.UtilityInputOffset = inputConduit.Location;
				buildingDef.InputConduitType = inputConduit.Type;
			}
			if (OutputConduits.Count > 1)
			{
				throw new InvalidOperationException("Only supports one output conduit");
			}
			foreach (ConduitConnection outputConduit in OutputConduits)
			{
				buildingDef.UtilityOutputOffset = outputConduit.Location;
				buildingDef.OutputConduitType = outputConduit.Type;
			}
			TUNING.BUILDINGS.PLANSUBCATEGORYSORTING[ID] = SubCategory;
			return buildingDef;
		}

		public void ConfigureBuildingTemplate(GameObject go)
		{
			if (AlwaysOperational)
			{
				ApplyAlwaysOperational(go);
			}
		}

		public void CreateLogicPorts(GameObject go)
		{
			SplitLogicPorts(go);
		}

		public void DoPostConfigureComplete(GameObject go)
		{
			if (InputConduits.Count == 1)
			{
				ConduitConsumer conduitConsumer = go.AddOrGet<ConduitConsumer>();
				foreach (ConduitConnection inputConduit in InputConduits)
				{
					conduitConsumer.alwaysConsume = true;
					conduitConsumer.conduitType = inputConduit.Type;
					conduitConsumer.wrongElementResult = ConduitConsumer.WrongElementResult.Store;
				}
			}
			if (OutputConduits.Count == 1)
			{
				ConduitDispenser conduitDispenser = go.AddOrGet<ConduitDispenser>();
				foreach (ConduitConnection outputConduit in OutputConduits)
				{
					conduitDispenser.alwaysDispense = true;
					conduitDispenser.conduitType = outputConduit.Type;
					conduitDispenser.elementFilter = null;
				}
			}
			if (IndustrialMachine && go.TryGetComponent<KPrefabID>(out var component))
			{
				component.AddTag(RoomConstraints.ConstraintTags.IndustrialMachinery);
			}
			if (PowerInput != null)
			{
				go.AddOrGet<EnergyConsumer>();
			}
			if (PowerOutput != null)
			{
				go.AddOrGet<EnergyGenerator>();
			}
			if (DefaultPriority.HasValue && go.TryGetComponent<Prioritizable>(out var component2))
			{
				Prioritizable.AddRef(go);
				component2.SetMasterPriority(new PrioritySetting(PriorityScreen.PriorityClass.basic, DefaultPriority ?? 5));
			}
		}

		public override string ToString()
		{
			return "PBuilding[ID={0}]".F(ID);
		}

		private static void ApplyAlwaysOperational(GameObject go)
		{
			if (go.TryGetComponent<BuildingEnabledButton>(out var component))
			{
				UnityEngine.Object.DestroyImmediate(component);
			}
			if (go.TryGetComponent<Operational>(out var component2))
			{
				UnityEngine.Object.DestroyImmediate(component2);
			}
			if (go.TryGetComponent<LogicPorts>(out var component3))
			{
				UnityEngine.Object.DestroyImmediate(component3);
			}
		}

		public static LogicPorts.Port CompatLogicPort(LogicPortSpriteType type, CellOffset offset)
		{
			return new LogicPorts.Port(LogicOperationalController.PORT_ID, offset, STRINGS.UI.LOGIC_PORTS.CONTROL_OPERATIONAL, STRINGS.UI.LOGIC_PORTS.CONTROL_OPERATIONAL_ACTIVE, STRINGS.UI.LOGIC_PORTS.CONTROL_OPERATIONAL_INACTIVE, show_wire_missing_icon: false, type);
		}

		public void AddPlan()
		{
			if (addedPlan || !Category.IsValid)
			{
				return;
			}
			bool flag = false;
			foreach (PlanScreen.PlanInfo item in TUNING.BUILDINGS.PLANORDER)
			{
				if (item.category == Category)
				{
					AddPlanToCategory(item);
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				PUtil.LogWarning("Unable to find build menu: " + Category.ToString());
			}
			addedPlan = true;
		}

		private void AddPlanToCategory(PlanScreen.PlanInfo menu)
		{
			List<KeyValuePair<string, string>> buildingAndSubcategoryData = menu.buildingAndSubcategoryData;
			if (buildingAndSubcategoryData != null)
			{
				string addAfter = AddAfter;
				bool flag = false;
				if (addAfter != null)
				{
					int count = buildingAndSubcategoryData.Count;
					for (int i = 0; i < count - 1; i++)
					{
						if (flag)
						{
							break;
						}
						if (buildingAndSubcategoryData[i].Key == addAfter)
						{
							buildingAndSubcategoryData.Insert(i + 1, new KeyValuePair<string, string>(ID, SubCategory));
							flag = true;
						}
					}
				}
				if (!flag)
				{
					buildingAndSubcategoryData.Add(new KeyValuePair<string, string>(ID, SubCategory));
				}
			}
			else
			{
				PUtil.LogWarning("Build menu " + Category.ToString() + " has invalid entries!");
			}
		}

		public void AddStrings()
		{
			if (!addedStrings)
			{
				string text = "STRINGS.BUILDINGS.PREFABS." + ID.ToUpperInvariant() + ".";
				string text2 = text + "NAME";
				if (Strings.TryGet(text2, out var result))
				{
					Name = result.String;
				}
				else
				{
					Strings.Add(text2, Name);
				}
				if (Description != null)
				{
					Strings.Add(text + "DESC", Description);
				}
				if (EffectText != null)
				{
					Strings.Add(text + "EFFECT", EffectText);
				}
				addedStrings = true;
			}
		}

		public void AddTech()
		{
			if (!addedTech && Tech != null)
			{
				(Db.Get().Techs?.TryGet(Tech))?.unlockedItemIDs?.Add(ID);
				addedTech = true;
			}
		}

		private void SplitLogicPorts(GameObject go)
		{
			int count = LogicIO.Count;
			List<LogicPorts.Port> list = new List<LogicPorts.Port>(count);
			List<LogicPorts.Port> list2 = new List<LogicPorts.Port>(count);
			foreach (LogicPorts.Port item in LogicIO)
			{
				if (item.spriteType == LogicPortSpriteType.Output)
				{
					list2.Add(item);
				}
				else
				{
					list.Add(item);
				}
			}
			LogicPorts logicPorts = go.AddOrGet<LogicPorts>();
			if (list.Count > 0)
			{
				logicPorts.inputPortInfo = list.ToArray();
			}
			if (list2.Count > 0)
			{
				logicPorts.outputPortInfo = list2.ToArray();
			}
		}
	}
}
