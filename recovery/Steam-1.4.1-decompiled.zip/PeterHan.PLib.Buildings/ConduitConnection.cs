namespace PeterHan.PLib.Buildings
{
	internal class ConduitConnection
	{
		public CellOffset Location { get; }

		public ConduitType Type { get; }

		public ConduitConnection(ConduitType type, CellOffset location)
		{
			Location = location;
			Type = type;
		}

		public override string ToString()
		{
			return $"Connection[Type={Type},Location={Location}]";
		}
	}
}
