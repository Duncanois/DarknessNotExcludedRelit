using System;
using PeterHan.PLib.Core;

namespace PeterHan.PLib.Buildings
{
	internal class PowerRequirement
	{
		public float MaxWattage { get; }

		public CellOffset PlugLocation { get; }

		public PowerRequirement(float wattage, CellOffset plugLocation)
		{
			if (wattage.IsNaNOrInfinity() || wattage < 0f)
			{
				throw new ArgumentException("wattage");
			}
			MaxWattage = wattage;
			PlugLocation = plugLocation;
		}

		public override string ToString()
		{
			return "Power[Watts={0:F0},Location={1}]".F(MaxWattage, PlugLocation);
		}
	}
}
