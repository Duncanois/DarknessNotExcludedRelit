using System.Collections;
using PeterHan.PLib.Core;
using PeterHan.PLib.Detours;
using STRINGS;
using UnityEngine;

namespace PeterHan.PLib.AVC
{
	internal sealed class ModOutdatedWarning : KMonoBehaviour
	{
		private static readonly IDetouredField<MainMenu, KButton> RESUME_GAME = PDetours.DetourFieldLazy<MainMenu, KButton>("Button_ResumeGame");

		private GameObject modsButton;

		internal static ModOutdatedWarning Instance { get; private set; }

		internal ModOutdatedWarning()
		{
			modsButton = null;
		}

		private void FindModsButton(Transform buttonParent)
		{
			int childCount = buttonParent.childCount;
			for (int i = 0; i < childCount; i++)
			{
				GameObject gameObject = buttonParent.GetChild(i).gameObject;
				if (gameObject != null && gameObject.GetComponentInChildren<LocText>()?.text == STRINGS.UI.FRONTEND.MODS.TITLE)
				{
					modsButton = gameObject;
					break;
				}
			}
			if (modsButton == null)
			{
				PUtil.LogWarning("Unable to find Mods menu button, main menu update warning will not be functional");
			}
		}

		protected override void OnCleanUp()
		{
			Instance = null;
			base.OnCleanUp();
		}

		protected override void OnPrefabInit()
		{
			base.OnPrefabInit();
			MainMenu component = GetComponent<MainMenu>();
			Instance = this;
			try
			{
				KButton kButton;
				Transform parent;
				if (component != null && (kButton = RESUME_GAME.Get(component)) != null && (parent = kButton.transform.parent) != null)
				{
					FindModsButton(parent);
				}
			}
			catch (DetourException)
			{
			}
			UpdateText();
		}

		private void UpdateText()
		{
			PVersionCheck instance = PVersionCheck.Instance;
			if (modsButton != null && instance != null)
			{
				LocText componentInChildren = modsButton.GetComponentInChildren<LocText>();
				int outdatedMods = instance.OutdatedMods;
				if (outdatedMods > 0 && componentInChildren != null)
				{
					string text = STRINGS.UI.FRONTEND.MODS.TITLE;
					text = ((outdatedMods != 1) ? (text + string.Format(PLibStrings.MAINMENU_UPDATE, outdatedMods)) : (text + PLibStrings.MAINMENU_UPDATE_1));
					componentInChildren.text = text;
				}
			}
		}

		public IEnumerator UpdateTextThreaded()
		{
			yield return null;
			UpdateText();
		}
	}
}
