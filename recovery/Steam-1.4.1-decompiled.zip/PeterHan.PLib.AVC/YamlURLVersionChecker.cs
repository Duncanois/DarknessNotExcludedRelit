using System;
using KMod;
using Klei;
using UnityEngine;
using UnityEngine.Networking;

namespace PeterHan.PLib.AVC
{
	internal sealed class YamlURLVersionChecker : IModVersionChecker
	{
		public string YamlVersionURL { get; }

		public event PVersionCheck.OnVersionCheckComplete OnVersionCheckCompleted;

		public YamlURLVersionChecker(string url)
		{
			if (string.IsNullOrEmpty(url))
			{
				throw new ArgumentNullException("url");
			}
			YamlVersionURL = url;
		}

		public bool CheckVersion(Mod mod)
		{
			if (mod == null)
			{
				throw new ArgumentNullException("mod");
			}
			UnityWebRequest request = UnityWebRequest.Get(YamlVersionURL);
			request.SetRequestHeader("Content-Type", "application/x-yaml");
			request.SetRequestHeader("User-Agent", "PLib AVC");
			request.timeout = 8;
			request.SendWebRequest().completed += (AsyncOperation _) =>
			{
				OnRequestFinished(request, mod);
			};
			return true;
		}

		private void OnRequestFinished(UnityWebRequest request, Mod mod)
		{
			ModVersionCheckResults result = null;
			if (request.result == UnityWebRequest.Result.Success)
			{
				Mod.PackagedModInfo packagedModInfo = YamlIO.Parse<Mod.PackagedModInfo>(request.downloadHandler.text, default);
				string text = packagedModInfo?.version;
				if (packagedModInfo != null && !string.IsNullOrEmpty(text))
				{
					string currentVersion = PVersionCheck.GetCurrentVersion(mod);
					result = new ModVersionCheckResults(mod.staticID, text == currentVersion, text);
				}
			}
			request.Dispose();
			OnVersionCheckCompleted?.Invoke(result);
		}
	}
}
