using KMod;

namespace PeterHan.PLib.AVC
{
	internal interface IModVersionChecker
	{
		event PVersionCheck.OnVersionCheckComplete OnVersionCheckCompleted;

		bool CheckVersion(Mod mod);
	}
}
