using HarmonyLib;
using UnityEngine;

namespace DarknessNotIncluded.Plants
{
	public static class DuskCapMaxLux
	{
		[HarmonyPatch(typeof(MushroomPlantConfig))]
		[HarmonyPatch("CreatePrefab")]
		private static class Patched_MushroomPlantConfig_CreatePrefab
		{
			private static void Postfix(ref GameObject __result)
			{
				IlluminationVulnerable illuminationVulnerable = __result.AddOrGet<IlluminationVulnerable>();
				Config.ObserveFor(illuminationVulnerable, (Config config) =>
				{
					illuminationVulnerable.SetMaxLux(config.duskCapPlantMaxLux);
				});
			}
		}
	}
}
