using System;
using HarmonyLib;

namespace DarknessNotIncluded.Darkness
{
	internal static class FadeUnlitCells
	{
		[HarmonyPatch(typeof(PropertyTextures))]
		[HarmonyPatch("UpdateFogOfWar")]
		private static class Patched_PropertyTextures_UpdateFogOfWar
		{
			private static bool Prefix(TextureRegion region, int x0, int y0, int x1, int y1)
			{
				if (Game.Instance.SandboxModeActive && !darknessInSandboxMode)
				{
					return true;
				}
				byte[] visible = Grid.Visible;
				int y2 = Grid.HeightInCells;
				if (ClusterManager.Instance != null)
				{
					WorldContainer activeWorld = ClusterManager.Instance.activeWorld;
					y2 = activeWorld.WorldSize.Y + activeWorld.WorldOffset.Y - 1;
				}
				int num = minimumFogLevel;
				float timeInCycles = GameClock.Instance.GetTimeInCycles();
				if (timeInCycles < gracePeriodCycles)
				{
					float num2 = 1f - timeInCycles / gracePeriodCycles;
					num = Math.Max(num, (int)(num2 * (float)initialFogLevel));
				}
				if (OverlayScreen.Instance?.GetMode() != OverlayModes.None.ID)
				{
					num = Math.Min(255, num * 2);
				}
				int num3 = 255 - num;
				for (int i = y0; i <= y1; i++)
				{
					for (int j = x0; j <= x1; j++)
					{
						int num4 = Grid.XYToCell(j, i);
						if (!Grid.IsActiveWorld(num4))
						{
							num4 = Grid.XYToCell(j, y2);
						}
						if (!Grid.IsValidCell(num4))
						{
							region.SetBytes(j, i, 0);
							continue;
						}
						if (visible[num4] == 0)
						{
							region.SetBytes(j, i, 0);
							continue;
						}
						if (!Behavior.enabled)
						{
							region.SetBytes(j, i, visible[num4]);
							continue;
						}
						int val = Behavior.ActualOrImpliedLightLevel(num4);
						int num5 = num + Math.Min(val, fullyVisibleLuxThreshold) * num3 / fullyVisibleLuxThreshold;
						region.SetBytes(j, i, Math.Min((byte)num5, visible[num4]));
					}
				}
				return false;
			}
		}

		private static float gracePeriodCycles;

		private static bool darknessInSandboxMode;

		private static int initialFogLevel;

		private static int minimumFogLevel;

		private static int fullyVisibleLuxThreshold;

		private static Config.Observer configObserver = new Config.Observer((Config config) =>
		{
			gracePeriodCycles = config.gracePeriodCycles;
			darknessInSandboxMode = config.darknessInSandboxMode;
			initialFogLevel = config.initialFogLevel;
			minimumFogLevel = config.minimumFogLevel;
			fullyVisibleLuxThreshold = config.fullyVisibleLuxThreshold;
		});
	}
}
