namespace DarknessNotIncluded.Darkness
{
	public enum InspectionLevel
	{
		None,
		BasicDetails,
		FullDetails
	}
}
