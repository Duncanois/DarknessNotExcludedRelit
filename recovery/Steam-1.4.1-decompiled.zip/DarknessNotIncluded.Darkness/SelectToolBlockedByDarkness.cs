using System.Collections.Generic;
using HarmonyLib;
using STRINGS;
using UnityEngine;

namespace DarknessNotIncluded.Darkness
{
	internal static class SelectToolBlockedByDarkness
	{
		[HarmonyPatch(typeof(SelectToolHoverTextCard))]
		[HarmonyPatch("UpdateHoverElements")]
		private static class Patched_SelectToolHoverTextCard_UpdateHoverElements
		{
			private static bool Prefix(SelectToolHoverTextCard __instance, List<KSelectable> hoverObjects)
			{
				int cell = Grid.PosToCell(Camera.main.ScreenToWorldPoint(KInputManager.GetMousePos()));
				switch (Behavior.InspectionLevelForCell(cell))
				{
				case InspectionLevel.None:
					RenderUnknownHoverCard(__instance);
					return false;
				case InspectionLevel.BasicDetails:
					RenderBasicHoverCard(__instance, cell, hoverObjects);
					return false;
				default:
					return true;
				}
			}

			private static void RenderUnknownHoverCard(SelectToolHoverTextCard hoverCard)
			{
				HoverTextDrawer hoverTextDrawer = HoverTextScreen.Instance.BeginDrawing();
				hoverTextDrawer.BeginShadowBar();
				hoverTextDrawer.DrawIcon(hoverCard.iconWarning);
				hoverTextDrawer.DrawText(UI.TOOLS.GENERIC.UNKNOWN, hoverCard.Styles_BodyText.Standard);
				hoverTextDrawer.EndShadowBar();
				hoverCard.recentNumberOfDisplayedSelectables = 1;
				hoverTextDrawer.EndDrawing();
			}

			private static void RenderBasicHoverCard(SelectToolHoverTextCard hoverCard, int cell, List<KSelectable> hoverObjects)
			{
				HoverTextDrawer hoverTextDrawer = HoverTextScreen.Instance.BeginDrawing();
				hoverTextDrawer.BeginShadowBar();
				hoverTextDrawer.DrawIcon(hoverCard.iconWarning);
				hoverTextDrawer.DrawText("UNLIT", hoverCard.Styles_Title.Standard);
				hoverTextDrawer.EndShadowBar();
				foreach (KSelectable hoverObject in hoverObjects)
				{
					if (!CellSelectionObject.IsSelectionObject(hoverObject.gameObject))
					{
						PrimaryElement component = hoverObject.GetComponent<PrimaryElement>();
						string text = GameUtil.GetUnitFormattedName(hoverObject.gameObject, upperName: true);
						if (component != null && (bool)hoverObject.GetComponent<Building>())
						{
							text = StringFormatter.Replace(StringFormatter.Replace(UI.TOOLS.GENERIC.BUILDING_HOVER_NAME_FMT, "{Name}", text), "{Element}", component.Element.nameUpperCase);
						}
						hoverTextDrawer.BeginShadowBar(SelectTool.Instance.selected == hoverObject);
						hoverTextDrawer.DrawText(text, hoverCard.Styles_Title.Standard);
						hoverTextDrawer.EndShadowBar();
					}
				}
				if (!Grid.DupePassable[cell] || !Grid.Solid[cell])
				{
					Element element = Grid.Element[cell];
					hoverTextDrawer.BeginShadowBar();
					hoverTextDrawer.DrawText(element.nameUpperCase, hoverCard.Styles_Title.Standard);
					hoverTextDrawer.EndShadowBar();
				}
				hoverTextDrawer.EndDrawing();
			}
		}

		[HarmonyPatch(typeof(SelectTool))]
		[HarmonyPatch("Select")]
		private static class Patched_SelectTool_Select
		{
			private static bool Prefix(KSelectable new_selected, bool skipSound)
			{
				if (new_selected == null)
				{
					return true;
				}
				int cell = Grid.PosToCell(new_selected);
				switch (Behavior.InspectionLevelForCell(cell))
				{
				case InspectionLevel.None:
					return false;
				case InspectionLevel.FullDetails:
					return true;
				default:
					return !CellSelectionObject.IsSelectionObject(new_selected.gameObject);
				}
			}
		}
	}
}
