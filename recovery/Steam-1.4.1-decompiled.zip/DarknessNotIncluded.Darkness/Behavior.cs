using System;

namespace DarknessNotIncluded.Darkness
{
	public static class Behavior
	{
		public static bool enabled = true;

		private static bool selectToolBlockedByDarkness;

		private static float gracePeriodCycles;

		private static Config.Observer configObserver = new Config.Observer((Config config) =>
		{
			selectToolBlockedByDarkness = config.selectToolBlockedByDarkness;
			gracePeriodCycles = config.gracePeriodCycles;
		});

		public static int ActualOrImpliedLightLevel(int cell)
		{
			if (!Grid.IsValidCell(cell))
			{
				return 0;
			}
			int num = Grid.LightIntensity[cell];
			if (num > 0)
			{
				return num;
			}
			int maxLux = 0;
			ConsiderLux(ref maxLux, Grid.CellAbove(cell));
			ConsiderLux(ref maxLux, Grid.CellRight(cell));
			ConsiderLux(ref maxLux, Grid.CellBelow(cell));
			ConsiderLux(ref maxLux, Grid.CellLeft(cell));
			if (maxLux > 0)
			{
				return maxLux * 3 / 4;
			}
			int maxLux2 = 0;
			ConsiderLux(ref maxLux2, Grid.CellUpRight(cell));
			ConsiderLux(ref maxLux2, Grid.CellDownRight(cell));
			ConsiderLux(ref maxLux2, Grid.CellDownLeft(cell));
			ConsiderLux(ref maxLux2, Grid.CellUpLeft(cell));
			ConsiderLux(ref maxLux2, Grid.CellAbove(Grid.CellAbove(cell)));
			ConsiderLux(ref maxLux2, Grid.CellRight(Grid.CellRight(cell)));
			ConsiderLux(ref maxLux2, Grid.CellBelow(Grid.CellBelow(cell)));
			ConsiderLux(ref maxLux2, Grid.CellLeft(Grid.CellLeft(cell)));
			if (maxLux2 > 0)
			{
				return maxLux2 / 2;
			}
			int maxLux3 = 0;
			ConsiderLux(ref maxLux3, Grid.CellUpRight(Grid.CellAbove(cell)));
			ConsiderLux(ref maxLux3, Grid.CellUpRight(Grid.CellRight(cell)));
			ConsiderLux(ref maxLux3, Grid.CellDownRight(Grid.CellRight(cell)));
			ConsiderLux(ref maxLux3, Grid.CellDownRight(Grid.CellBelow(cell)));
			ConsiderLux(ref maxLux3, Grid.CellDownLeft(Grid.CellBelow(cell)));
			ConsiderLux(ref maxLux3, Grid.CellDownLeft(Grid.CellLeft(cell)));
			ConsiderLux(ref maxLux3, Grid.CellUpLeft(Grid.CellLeft(cell)));
			ConsiderLux(ref maxLux3, Grid.CellUpLeft(Grid.CellAbove(cell)));
			if (maxLux3 > 0)
			{
				return maxLux3 / 4;
			}
			return 0;
		}

		private static void ConsiderLux(ref int maxLux, int cell)
		{
			if (Grid.IsValidCell(cell))
			{
				maxLux = Math.Max(maxLux, Grid.LightIntensity[cell]);
			}
		}

		public static InspectionLevel InspectionLevelForCell(int cell)
		{
			if (!Grid.IsValidCell(cell))
			{
				return InspectionLevel.None;
			}
			if (!enabled)
			{
				return InspectionLevel.FullDetails;
			}
			if (DebugHandler.RevealFogOfWar)
			{
				return InspectionLevel.FullDetails;
			}
			if (Grid.Visible[cell] <= 0)
			{
				return InspectionLevel.None;
			}
			if (!selectToolBlockedByDarkness)
			{
				return InspectionLevel.FullDetails;
			}
			if (GameClock.Instance.GetTimeInCycles() < gracePeriodCycles)
			{
				return InspectionLevel.FullDetails;
			}
			int num = ActualOrImpliedLightLevel(cell);
			return (num <= 0) ? InspectionLevel.BasicDetails : InspectionLevel.FullDetails;
		}
	}
}
