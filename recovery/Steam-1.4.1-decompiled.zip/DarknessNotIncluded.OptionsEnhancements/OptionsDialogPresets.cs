using System;
using System.Reflection;
using HarmonyLib;
using PeterHan.PLib.UI;
using UnityEngine;

namespace DarknessNotIncluded.OptionsEnhancements
{
	internal static class OptionsDialogPresets
	{
		[HarmonyPatch]
		private static class Patched_OptionsDialog_AddModInfoScreen
		{
			private static MethodBase TargetMethod()
			{
				Type type = Assembly.GetExecutingAssembly().GetType("PeterHan.PLib.Options.OptionsDialog");
				return AccessTools.Method(type, "AddModInfoScreen");
			}

			private static void Postfix(object __instance, PDialog __0)
			{
				PPanel body = __0.Body;
				PPanel pPanel = (PPanel)body.GetChildNamed("ModInfo");
				if (pPanel == null)
				{
					return;
				}
				pPanel.Margin = new RectOffset(0, 10, 0, 0);
				PLabel pLabel = (PLabel)pPanel.GetChildNamed("ModImage");
				if (pLabel != null)
				{
					pLabel.Margin = new RectOffset(0, 0, 0, 0);
				}
				PPanel pPanel2 = new PPanel("PresetsContainer")
				{
					Margin = new RectOffset(0, 0, 20, 0),
					Direction = PanelDirection.Vertical,
					FlexSize = new Vector2(1f, 0f)
				};
				pPanel.AddChild(pPanel2);
				PLabel child = new PLabel("PresetsLabel")
				{
					Text = "Presets",
					TextStyle = PUITuning.Fonts.UILightStyle,
					TextAlignment = TextAnchor.UpperCenter,
					Margin = new RectOffset(0, 0, 0, 10)
				};
				pPanel2.AddChild(child);
				Type OptionsType = Traverse.Create(__instance).Field("optionsType").GetValue<Type>();
				PButton child2 = new PButton("DefaultConfig")
				{
					Text = "Default",
					FlexSize = new Vector2(1f, 0f),
					Margin = PDialog.BUTTON_MARGIN,
					OnClick = (GameObject source) =>
					{
						SetConfig(__instance, AccessTools.Constructor(OptionsType).Invoke(new object[0]));
					}
				}.SetKleiPinkStyle();
				pPanel2.AddChild(child2);
				MethodInfo[] methods = OptionsType.GetMethods(BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
				foreach (MethodInfo method in methods)
				{
					OptionPreset customAttribute = method.GetCustomAttribute<OptionPreset>();
					if (customAttribute != null)
					{
						PButton child3 = new PButton("Preset." + method.Name)
						{
							Text = customAttribute.Name,
							FlexSize = new Vector2(1f, 0f),
							Margin = PDialog.BUTTON_MARGIN,
							OnClick = (GameObject source) =>
							{
								SetConfig(__instance, method.Invoke(null, new object[0]));
							}
						}.SetKleiPinkStyle();
						pPanel2.AddChild(child3);
					}
				}
			}

			private static void SetConfig(object optionsDialog, object config)
			{
				Traverse.Create(optionsDialog).Field("options").SetValue(config);
				Traverse.Create(optionsDialog).Method("UpdateOptions").GetValue();
			}
		}
	}
}
