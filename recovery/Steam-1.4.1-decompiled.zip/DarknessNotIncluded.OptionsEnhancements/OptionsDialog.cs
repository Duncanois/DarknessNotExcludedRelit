using System;
using System.Reflection;
using HarmonyLib;

namespace DarknessNotIncluded.OptionsEnhancements
{
	internal static class OptionsDialog
	{
		public static void Show<TConfigType>(Type ConfigType, Action<TConfigType> onClose)
		{
			Type type = Assembly.GetExecutingAssembly().GetType("PeterHan.PLib.Options.OptionsDialog");
			object root = AccessTools.Constructor(type, new Type[1] { typeof(Type) }).Invoke(new object[1] { ConfigType });
			Traverse traverse = Traverse.Create(root);
			Action<object> value = (object config) =>
			{
				onClose((TConfigType)config);
			};
			traverse.Property("OnClose").SetValue(value);
			traverse.Method("ShowDialog").GetValue();
		}
	}
}
