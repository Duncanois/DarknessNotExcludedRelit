using System;
using System.Reflection;
using HarmonyLib;

namespace DarknessNotIncluded.OptionsEnhancements
{
	internal static class OptionsDialogConsumesMouseScroll
	{
		[HarmonyPatch]
		private static class Patched_OptionsDialog_ShowDialog
		{
			private static MethodBase TargetMethod()
			{
				Type type = AccessTools.TypeByName("PeterHan.PLib.Options.OptionsDialog");
				return AccessTools.Method(type, "ShowDialog");
			}

			private static void Postfix(object __instance)
			{
				KScreen value = Traverse.Create(__instance).Field("dialog").GetValue<KScreen>();
				if (!(value == null))
				{
					value.ConsumeMouseScroll = true;
				}
			}
		}
	}
}
