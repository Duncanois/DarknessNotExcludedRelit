using System;

namespace DarknessNotIncluded.OptionsEnhancements
{
	[AttributeUsage(AttributeTargets.Method, AllowMultiple = false, Inherited = true)]
	public class OptionPreset : Attribute
	{
		public string Name { get; }

		public OptionPreset(string name)
		{
			Name = name;
		}
	}
}
