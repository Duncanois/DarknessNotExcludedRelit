using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using HarmonyLib;
using PeterHan.PLib.Core;
using UnityEngine;

namespace PeterHan.PLib.Lighting
{
	internal sealed class PLightManager : PForwardedComponent
	{
		public delegate void CastLightDelegate(LightingArgs args);

		private sealed class CacheEntry
		{
			internal int BaseLux { get; set; }

			internal IDictionary<int, float> Intensity { get; }

			internal GameObject Owner { get; }

			internal CacheEntry(GameObject owner)
			{
				Intensity = new Dictionary<int, float>(64);
				Owner = owner;
			}

			public override string ToString()
			{
				return "Lighting Cache Entry for " + ((Owner == null) ? "" : Owner.name);
			}
		}

		private static readonly List<object> EMPTY_SHAPES = new List<object>(1);

		internal static readonly Version VERSION = new Version("4.19.0.0");

		private readonly ConcurrentDictionary<LightGridManager.LightGridEmitter, CacheEntry> brightCache;

		private readonly IList<ILightShape> shapes;

		internal static bool ForceSmoothLight { get; set; }

		internal static PLightManager Instance { get; private set; }

		public override Version Version => VERSION;

		internal GameObject PreviewObject { get; set; }

		public static float GetDefaultFalloff(float falloffRate, int cell, int origin)
		{
			return 1f / Math.Max(1f, Mathf.RoundToInt(falloffRate * (float)Math.Max(Grid.GetCellDistance(origin, cell), 1)));
		}

		public static float GetSmoothFalloff(float falloffRate, int cell, int origin)
		{
			Vector2I vector2I = Grid.CellToXY(cell);
			Vector2I vector2I2 = Grid.CellToXY(origin);
			return 1f / Math.Max(1f, falloffRate * PUtil.Distance(vector2I2.X, vector2I2.Y, vector2I.X, vector2I.Y));
		}

		internal static LightShape LightShapeToRayShape(Light2D light)
		{
			LightShape lightShape = light.shape;
			if (lightShape != LightShape.Cone && lightShape != LightShape.Circle)
			{
				lightShape = Instance.GetRayShape(lightShape);
			}
			return lightShape;
		}

		internal static void LogLightingDebug(string message)
		{
			Debug.LogFormat("[PLibLighting] {0}", message);
		}

		internal static void LogLightingWarning(string message)
		{
			Debug.LogWarningFormat("[PLibLighting] {0}", message);
		}

		public PLightManager()
		{
			brightCache = new ConcurrentDictionary<LightGridManager.LightGridEmitter, CacheEntry>(2, 128);
			PreviewObject = null;
			shapes = new List<ILightShape>(16);
		}

		internal void AddLight(LightGridManager.LightGridEmitter source, GameObject owner)
		{
			if (owner == null)
			{
				throw new ArgumentNullException("owner");
			}
			if (source == null)
			{
				throw new ArgumentNullException("source");
			}
			brightCache.TryAdd(source, new CacheEntry(owner));
		}

		public override void Bootstrap(Harmony plibInstance)
		{
			SetSharedData(new List<object>(16));
		}

		internal void DestroyLight(LightGridManager.LightGridEmitter source)
		{
			if (source != null)
			{
				brightCache.TryRemove(source, out var _);
			}
		}

		internal bool GetBrightness(LightGridManager.LightGridEmitter source, int location, LightGridManager.LightGridEmitter.State state, out int result)
		{
			LightShape shape = state.shape;
			bool flag;
			if (shape != LightShape.Cone && shape != LightShape.Circle)
			{
				flag = brightCache.TryGetValue(source, out var value);
				if (flag)
				{
					flag = value.Intensity.TryGetValue(location, out var value2);
					if (flag)
					{
						result = Mathf.RoundToInt((float)value.BaseLux * value2);
					}
					else
					{
						result = 0;
					}
				}
				else
				{
					result = 0;
				}
			}
			else if (ForceSmoothLight)
			{
				result = Mathf.RoundToInt((float)state.intensity * GetSmoothFalloff(state.falloffRate, location, state.origin));
				flag = true;
			}
			else
			{
				result = 0;
				flag = false;
			}
			return flag;
		}

		internal LightShape GetRayShape(LightShape shape)
		{
			int num = (int)(shape - 1 - 1);
			ILightShape lightShape;
			if (num >= 0 && num < shapes.Count && (lightShape = shapes[num]) != null)
			{
				LightShape rayMode = lightShape.RayMode;
				if (rayMode >= LightShape.Circle)
				{
					shape = rayMode;
				}
			}
			return shape;
		}

		public override void Initialize(Harmony plibInstance)
		{
			Instance = this;
			shapes.Clear();
			foreach (object sharedDatum in GetSharedData(EMPTY_SHAPES))
			{
				ILightShape lightShape = PRemoteLightWrapper.LightToInstance(sharedDatum);
				shapes.Add(lightShape);
				if (lightShape == null)
				{
					LogLightingWarning("Foreign contaminant in PLightManager!");
				}
			}
			LightingPatches.ApplyPatches(plibInstance);
		}

		internal bool PreviewLight(int origin, float radius, LightShape shape, int lux)
		{
			bool result = false;
			GameObject previewObject = PreviewObject;
			int num = (int)(shape - 1 - 1);
			if (num >= 0 && num < shapes.Count && previewObject != null)
			{
				DictionaryPool<int, float, PLightManager>.PooledDictionary pooledDictionary = DictionaryPool<int, float, PLightManager>.Allocate();
				shapes[num]?.FillLight(new LightingArgs(previewObject, origin, (int)radius, pooledDictionary));
				foreach (KeyValuePair<int, float> item in pooledDictionary)
				{
					int key = item.Key;
					if (Grid.IsValidCell(key))
					{
						int num2 = Mathf.RoundToInt((float)lux * item.Value);
						LightGridManager.previewLightCells.Add(new Tuple<int, int>(key, num2));
						LightGridManager.previewLux[key] = num2;
					}
				}
				PreviewObject = null;
				result = true;
				pooledDictionary.Recycle();
			}
			return result;
		}

		public ILightShape Register(string identifier, CastLightDelegate handler, LightShape rayMode = (LightShape)(-1))
		{
			if (string.IsNullOrEmpty(identifier))
			{
				throw new ArgumentNullException("identifier");
			}
			if (handler == null)
			{
				throw new ArgumentNullException("handler");
			}
			ILightShape lightShape = null;
			RegisterForForwarding();
			List<object> sharedData = GetSharedData(EMPTY_SHAPES);
			int count = sharedData.Count;
			foreach (object item in sharedData)
			{
				ILightShape lightShape2 = PRemoteLightWrapper.LightToInstance(item);
				if (lightShape2 != null && lightShape2.Identifier == identifier)
				{
					LogLightingDebug("Found existing light shape: " + identifier + " from " + (item.GetType().Assembly.GetNameSafe() ?? "?"));
					lightShape = lightShape2;
					break;
				}
			}
			if (lightShape == null)
			{
				lightShape = new PLightShape(count + 1, identifier, handler, rayMode);
				LogLightingDebug("Registered new light shape: " + identifier);
				sharedData.Add(lightShape);
			}
			return lightShape;
		}

		internal bool UpdateLitCells(LightGridManager.LightGridEmitter source, LightGridManager.LightGridEmitter.State state, IList<int> litCells)
		{
			bool result = false;
			int num = (int)(state.shape - 1 - 1);
			if (source == null)
			{
				throw new ArgumentNullException("source");
			}
			if (num >= 0 && num < shapes.Count && litCells != null && brightCache.TryGetValue(source, out var value))
			{
				ILightShape lightShape = shapes[num];
				IDictionary<int, float> intensity = value.Intensity;
				intensity.Clear();
				value.BaseLux = state.intensity;
				lightShape.FillLight(new LightingArgs(value.Owner, state.origin, (int)state.radius, intensity));
				foreach (KeyValuePair<int, float> item in intensity)
				{
					litCells.Add(item.Key);
				}
				result = true;
			}
			return result;
		}
	}
}
