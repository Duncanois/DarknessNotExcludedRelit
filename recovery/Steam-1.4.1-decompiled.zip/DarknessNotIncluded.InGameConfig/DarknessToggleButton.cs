using DarknessNotIncluded.Darkness;
using HarmonyLib;
using PeterHan.PLib.UI;
using UnityEngine;

namespace DarknessNotIncluded.InGameConfig
{
	internal static class DarknessToggleButton
	{
		[HarmonyPatch(typeof(TopLeftControlScreen))]
		[HarmonyPatch("OnActivate")]
		private static class Patched_TopLeftControlScreen_OnActivate
		{
			private static void Postfix(RectTransform ___secondaryRow, MultiToggle ___kleiItemDropButton)
			{
				PButton component = new PButton("DarknessToggle")
				{
					ToolTip = DARKNESS_ACTIVE_TOOLTIP,
					Sprite = Assets.GetSprite("icon_category_lights_disabled"),
					SpriteSize = new Vector2(24f, 24f),
					Margin = new RectOffset(3, 3, 3, 3),
					Color = PUITuning.Colors.ButtonBlueStyle
				}.AddOnRealize((GameObject realized) =>
				{
					KButton kButton = realized.GetComponent<KButton>();
					kButton.onBtnClick += (KKeyCode btn) =>
					{
						if (btn == KKeyCode.Mouse0)
						{
							ToggleDarkness(kButton);
						}
					};
				});
				component.AddTo(___secondaryRow.gameObject);
			}

			private static void ToggleDarkness(KButton button)
			{
				Behavior.enabled = !Behavior.enabled;
				button.GetComponent<ToolTip>().SetSimpleTooltip(Behavior.enabled ? DARKNESS_ACTIVE_TOOLTIP : DARKNESS_DISABLED_TOOLTIP);
				button.bgImage.colorStyleSetting = (Behavior.enabled ? PUITuning.Colors.ButtonBlueStyle : PUITuning.Colors.ButtonPinkStyle);
				button.fgImage.sprite = Assets.GetSprite(Behavior.enabled ? "icon_category_lights_disabled" : "icon_category_lights");
			}
		}

		private static LocString DARKNESS_ACTIVE_TOOLTIP = "<style=\"consumed\">Disable Darkness</style>\n\nGetting to be a little too much? It's ok, we won't judge you ...too much.";

		private static LocString DARKNESS_DISABLED_TOOLTIP = "<style=\"produced\">Re-Enable Darkness</style>\n\nAh! Welcome back to the challenge.";
	}
}
