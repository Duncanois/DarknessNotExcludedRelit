using HarmonyLib;

namespace PeterHan.PLib.PatchManager
{
	internal interface IPatchMethodInstance
	{
		void Run(Harmony instance);
	}
}
