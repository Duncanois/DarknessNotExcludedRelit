using System;
using System.Reflection;
using HarmonyLib;
using PeterHan.PLib.Core;

namespace PeterHan.PLib.PatchManager
{
	internal sealed class PLibPatchInstance : IPatchMethodInstance
	{
		public PLibPatchAttribute Descriptor { get; }

		public MethodInfo Method { get; }

		public PLibPatchInstance(PLibPatchAttribute attribute, MethodInfo method)
		{
			Descriptor = attribute ?? throw new ArgumentNullException("attribute");
			Method = method ?? throw new ArgumentNullException("method");
		}

		private HarmonyPatchType GetPatchType()
		{
			HarmonyPatchType harmonyPatchType = Descriptor.PatchType;
			if (harmonyPatchType == HarmonyPatchType.All)
			{
				string name = Method.Name;
				foreach (object value in Enum.GetValues(typeof(HarmonyPatchType)))
				{
					if (value is HarmonyPatchType harmonyPatchType2 && harmonyPatchType2 != harmonyPatchType && name.EndsWith(harmonyPatchType2.ToString(), StringComparison.Ordinal))
					{
						harmonyPatchType = harmonyPatchType2;
						break;
					}
				}
			}
			return harmonyPatchType;
		}

		private MethodBase GetTargetConstructor(Type targetType, Type[] argumentTypes)
		{
			if (argumentTypes == null)
			{
				ConstructorInfo[] constructors = targetType.GetConstructors(BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
				if (constructors == null || constructors.Length != 1)
				{
					throw new InvalidOperationException("No constructor for {0} found".F(targetType.FullName));
				}
				return constructors[0];
			}
			return targetType.GetConstructor(BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic, null, argumentTypes, null);
		}

		private MethodBase GetTargetMethod(Type requiredType)
		{
			Type type = Descriptor.TargetType;
			Type[] argumentTypes = Descriptor.ArgumentTypes;
			string methodName = Descriptor.MethodName;
			if (type == null)
			{
				type = requiredType;
			}
			if (type == null)
			{
				throw new InvalidOperationException("No type specified to patch");
			}
			MethodBase methodBase;
			if (!string.IsNullOrEmpty(methodName) && !(methodName == ".ctor"))
			{
				methodBase = ((argumentTypes == null) ? type.GetMethod(methodName, BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic) : type.GetMethod(methodName, BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic, null, argumentTypes, null));
			}
			else
			{
				methodBase = GetTargetConstructor(type, argumentTypes);
			}
			if (methodBase == null)
			{
				throw new InvalidOperationException("Method {0}.{1} not found".F(type.FullName, methodName));
			}
			return methodBase;
		}

		private bool LogIgnoreOnFail(Exception e)
		{
			bool ignoreOnFail = Descriptor.IgnoreOnFail;
			if (ignoreOnFail)
			{
				PUtil.LogDebug("Patch for {0} not applied: {1}".F(Descriptor.MethodName, e.Message));
			}
			return ignoreOnFail;
		}

		public void Run(Harmony instance)
		{
			if (!PPatchManager.CheckConditions(Descriptor.RequireAssembly, Descriptor.RequireType, out var requiredType))
			{
				return;
			}
			HarmonyMethod harmonyMethod = new HarmonyMethod(Method);
			if (instance == null)
			{
				throw new ArgumentNullException("instance");
			}
			try
			{
				MethodBase targetMethod = GetTargetMethod(requiredType);
				switch (GetPatchType())
				{
				case HarmonyPatchType.Postfix:
					instance.Patch(targetMethod, null, harmonyMethod);
					break;
				case HarmonyPatchType.Prefix:
					instance.Patch(targetMethod, harmonyMethod);
					break;
				case HarmonyPatchType.Transpiler:
					instance.Patch(targetMethod, null, null, harmonyMethod);
					break;
				default:
					throw new ArgumentOutOfRangeException("HarmonyPatchType");
				}
			}
			catch (AmbiguousMatchException e)
			{
				if (!LogIgnoreOnFail(e))
				{
					throw;
				}
			}
			catch (InvalidOperationException e2)
			{
				if (!LogIgnoreOnFail(e2))
				{
					throw;
				}
			}
		}
	}
}
