namespace PeterHan.PLib
{
	internal static class PVersion
	{
		public const string VERSION = "4.19.0.0";
	}
}
