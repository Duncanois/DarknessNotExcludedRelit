using System;

namespace PeterHan.PLib.Detours
{
	internal class DetourException : ArgumentException
	{
		public DetourException(string message)
			: base(message)
		{
		}
	}
}
