using System;

namespace PeterHan.PLib.Actions
{
	internal sealed class PAction
	{
		private readonly int id;

		public static Action MaxAction { get; }

		internal PKeyBinding DefaultBinding { get; }

		public string Identifier { get; }

		public LocString Title { get; }

		static PAction()
		{
			if (!Enum.TryParse<Action>("NumActions", out var result))
			{
				result = Action.Find;
			}
			MaxAction = result;
		}

		internal PAction(int id, string identifier, LocString title, PKeyBinding binding)
		{
			if (id <= 0)
			{
				throw new ArgumentOutOfRangeException("id");
			}
			DefaultBinding = binding;
			Identifier = identifier;
			this.id = id;
			Title = title;
		}

		public override bool Equals(object obj)
		{
			if (obj is PAction pAction)
			{
				return pAction.id == id;
			}
			return false;
		}

		public Action GetKAction()
		{
			return MaxAction + id;
		}

		public override int GetHashCode()
		{
			return id;
		}

		public override string ToString()
		{
			return "PAction[" + Identifier + "]: " + Title;
		}
	}
}
