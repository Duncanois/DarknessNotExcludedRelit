namespace PeterHan.PLib.Actions
{
	internal sealed class PKeyBinding
	{
		public GamepadButton GamePadButton { get; set; }

		public KKeyCode Key { get; set; }

		public Modifier Modifiers { get; set; }

		public PKeyBinding(KKeyCode keyCode = KKeyCode.None, Modifier modifiers = Modifier.None, GamepadButton gamePadButton = GamepadButton.NumButtons)
		{
			GamePadButton = gamePadButton;
			Key = keyCode;
			Modifiers = modifiers;
		}

		public PKeyBinding(PKeyBinding other)
			: this()
		{
			if (other != null)
			{
				GamePadButton = other.GamePadButton;
				Key = other.Key;
				Modifiers = other.Modifiers;
			}
		}

		public override bool Equals(object obj)
		{
			if (obj is PKeyBinding pKeyBinding && pKeyBinding.Key == Key && pKeyBinding.Modifiers == Modifiers)
			{
				return pKeyBinding.GamePadButton == GamePadButton;
			}
			return false;
		}

		public override int GetHashCode()
		{
			return ((1488379021 + GamePadButton.GetHashCode()) * -1521134295 + Key.GetHashCode()) * -1521134295 + Modifiers.GetHashCode();
		}

		public override string ToString()
		{
			return Modifiers.ToString() + " " + Key;
		}
	}
}
