using System;
using System.Collections.Generic;
using PeterHan.PLib.Core;
using UnityEngine;

namespace PeterHan.PLib.Actions
{
	internal sealed class PToolMode
	{
		public string Key { get; }

		public ToolParameterMenu.ToggleState State { get; }

		public LocString Title { get; }

		public static IDictionary<string, ToolParameterMenu.ToggleState> PopulateMenu(ToolParameterMenu menu, ICollection<PToolMode> options)
		{
			if (options == null)
			{
				throw new ArgumentNullException("options");
			}
			Dictionary<string, ToolParameterMenu.ToggleState> dictionary = new Dictionary<string, ToolParameterMenu.ToggleState>(options.Count);
			foreach (PToolMode option in options)
			{
				string key = option.Key;
				if (!string.IsNullOrEmpty(option.Title))
				{
					Strings.Add("STRINGS.UI.TOOLS.FILTERLAYERS." + key, option.Title);
				}
				dictionary.Add(key, option.State);
			}
			menu.PopulateMenu(dictionary);
			return dictionary;
		}

		public static void RegisterTool<T>(PlayerController controller) where T : InterfaceTool
		{
			if (controller == null)
			{
				throw new ArgumentNullException("controller");
			}
			ListPool<InterfaceTool, PlayerController>.PooledList pooledList = ListPool<InterfaceTool, PlayerController>.Allocate();
			pooledList.AddRange(controller.tools);
			GameObject gameObject = new GameObject(typeof(T).Name);
			T item = gameObject.AddComponent<T>();
			gameObject.transform.SetParent(controller.gameObject.transform);
			gameObject.gameObject.SetActive(value: true);
			gameObject.gameObject.SetActive(value: false);
			pooledList.Add(item);
			controller.tools = pooledList.ToArray();
			pooledList.Recycle();
		}

		public PToolMode(string key, LocString title, ToolParameterMenu.ToggleState state = ToolParameterMenu.ToggleState.Off)
		{
			if (string.IsNullOrEmpty(key))
			{
				throw new ArgumentNullException("key");
			}
			Key = key;
			State = state;
			Title = title;
		}

		public override bool Equals(object obj)
		{
			if (obj is PToolMode pToolMode)
			{
				return pToolMode.Key == Key;
			}
			return false;
		}

		public override int GetHashCode()
		{
			return Key.GetHashCode();
		}

		public override string ToString()
		{
			return "{0} ({1})".F(Key, Title);
		}
	}
}
