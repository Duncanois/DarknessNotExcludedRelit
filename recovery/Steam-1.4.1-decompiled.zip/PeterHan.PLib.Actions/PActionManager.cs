using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using PeterHan.PLib.Core;
using PeterHan.PLib.Detours;

namespace PeterHan.PLib.Actions
{
	internal sealed class PActionManager : PForwardedComponent
	{
		private delegate BindingEntry NewEntry(string group, GamepadButton button, KKeyCode key_code, Modifier modifier, Action action);

		public const string CATEGORY = "PLib";

		private static readonly NewEntry NEW_BINDING_ENTRY = typeof(BindingEntry).DetourConstructor<NewEntry>();

		internal static readonly Version VERSION = new Version("4.19.0.0");

		private readonly IList<PAction> actions;

		private int maxAction;

		internal static PActionManager Instance { get; private set; }

		public override Version Version => VERSION;

		private static void AssignKeyBindings()
		{
			IEnumerable<PForwardedComponent> allComponents = PRegistry.Instance.GetAllComponents(typeof(PActionManager).FullName);
			if (allComponents == null)
			{
				return;
			}
			foreach (PForwardedComponent item in allComponents)
			{
				item.Process(0u, null);
			}
		}

		private static void CKeyDef_Postfix(KInputController.KeyDef __instance)
		{
			if (Instance != null)
			{
				__instance.mActionFlags = ExtendFlags(__instance.mActionFlags, Instance.GetMaxAction());
			}
		}

		internal static bool[] ExtendFlags(bool[] oldActionFlags, int newMax)
		{
			int num = oldActionFlags.Length;
			bool[] array;
			if (num < newMax)
			{
				array = new bool[newMax];
				Array.Copy(oldActionFlags, array, num);
			}
			else
			{
				array = oldActionFlags;
			}
			return array;
		}

		private static bool FindKeyBinding(IEnumerable<BindingEntry> currentBindings, Action action)
		{
			bool result = false;
			foreach (BindingEntry currentBinding in currentBindings)
			{
				if (currentBinding.mAction == action)
				{
					LogKeyBind("Action {0} already exists; assigned to KeyCode {1}".F(action, currentBinding.mKeyCode));
					result = true;
					break;
				}
			}
			return result;
		}

		private static string GetBindingTitle(string category, string item)
		{
			return "STRINGS.INPUT_BINDINGS." + category.ToUpperInvariant() + "." + item.ToUpperInvariant();
		}

		internal static string GetExtraKeycodeLocalized(KKeyCode code)
		{
			string result = null;
			switch (code)
			{
			case KKeyCode.Home:
				result = PLibStrings.KEY_HOME;
				break;
			case KKeyCode.End:
				result = PLibStrings.KEY_END;
				break;
			case KKeyCode.Delete:
				result = PLibStrings.KEY_DELETE;
				break;
			case KKeyCode.PageDown:
				result = PLibStrings.KEY_PAGEDOWN;
				break;
			case KKeyCode.PageUp:
				result = PLibStrings.KEY_PAGEUP;
				break;
			case KKeyCode.LeftArrow:
				result = PLibStrings.KEY_ARROWLEFT;
				break;
			case KKeyCode.UpArrow:
				result = PLibStrings.KEY_ARROWUP;
				break;
			case KKeyCode.RightArrow:
				result = PLibStrings.KEY_ARROWRIGHT;
				break;
			case KKeyCode.DownArrow:
				result = PLibStrings.KEY_ARROWDOWN;
				break;
			case KKeyCode.Pause:
				result = PLibStrings.KEY_PAUSE;
				break;
			case KKeyCode.SysReq:
				result = PLibStrings.KEY_SYSRQ;
				break;
			case KKeyCode.Print:
				result = PLibStrings.KEY_PRTSCREEN;
				break;
			}
			return result;
		}

		private static bool GetKeycodeLocalized_Prefix(KKeyCode key_code, ref string __result)
		{
			string extraKeycodeLocalized = GetExtraKeycodeLocalized(key_code);
			if (extraKeycodeLocalized != null)
			{
				__result = extraKeycodeLocalized;
			}
			return extraKeycodeLocalized == null;
		}

		private static void IsActive_Prefix(ref bool[] ___mActionState)
		{
			if (Instance != null)
			{
				___mActionState = ExtendFlags(___mActionState, Instance.GetMaxAction());
			}
		}

		internal static void LogKeyBind(string message)
		{
			Debug.LogFormat("[PKeyBinding] {0}", message);
		}

		internal static void LogKeyBindWarning(string message)
		{
			Debug.LogWarningFormat("[PKeyBinding] {0}", message);
		}

		private static void QueueButtonEvent_Prefix(ref bool[] ___mActionState, KInputController.KeyDef key_def)
		{
			if (KInputManager.isFocused && Instance != null)
			{
				int newMax = Instance.GetMaxAction();
				key_def.mActionFlags = ExtendFlags(key_def.mActionFlags, newMax);
				___mActionState = ExtendFlags(___mActionState, newMax);
			}
		}

		private static void SetDefaultKeyBindings_Postfix()
		{
			Instance?.UpdateMaxAction();
		}

		public PActionManager()
		{
			actions = new List<PAction>(8);
			maxAction = 0;
		}

		public override void Bootstrap(Harmony plibInstance)
		{
			plibInstance.Patch(typeof(GameInputMapping), "LoadBindings", PatchMethod("AssignKeyBindings"));
		}

		public PAction CreateAction(string identifier, LocString title, PKeyBinding binding = null)
		{
			RegisterForForwarding();
			int sharedData = GetSharedData(1);
			PAction pAction = new PAction(sharedData, identifier, title, binding);
			SetSharedData(sharedData + 1);
			actions.Add(pAction);
			return pAction;
		}

		public int GetMaxAction()
		{
			int num = (int)PAction.MaxAction;
			if (maxAction <= 0)
			{
				return num - 1;
			}
			return maxAction + num;
		}

		public override void Initialize(Harmony plibInstance)
		{
			Instance = this;
			plibInstance.Patch(typeof(GameInputMapping), "SetDefaultKeyBindings", null, PatchMethod("SetDefaultKeyBindings_Postfix"));
			plibInstance.Patch(typeof(GameUtil), "GetKeycodeLocalized", PatchMethod("GetKeycodeLocalized_Prefix"));
			plibInstance.PatchConstructor(typeof(KInputController.KeyDef), new Type[2]
			{
				typeof(KKeyCode),
				typeof(Modifier)
			}, null, PatchMethod("CKeyDef_Postfix"));
			plibInstance.Patch(typeof(KInputController), "IsActive", PatchMethod("IsActive_Prefix"));
			plibInstance.Patch(typeof(KInputController), "QueueButtonEvent", PatchMethod("QueueButtonEvent_Prefix"));
		}

		public override void PostInitialize(Harmony plibInstance)
		{
			Strings.Add(GetBindingTitle("PLib", "NAME"), PLibStrings.KEY_CATEGORY_TITLE);
			IEnumerable<PForwardedComponent> allComponents = PRegistry.Instance.GetAllComponents(ID);
			if (allComponents == null)
			{
				return;
			}
			foreach (PForwardedComponent item in allComponents)
			{
				item.Process(1u, null);
			}
		}

		public override void Process(uint operation, object _)
		{
			if (actions.Count <= 0)
			{
				return;
			}
			switch (operation)
			{
			case 0u:
				RegisterKeyBindings();
				break;
			case 1u:
			{
				foreach (PAction action in actions)
				{
					Strings.Add(GetBindingTitle("PLib", action.GetKAction().ToString()), action.Title);
				}
				break;
			}
			}
		}

		private void RegisterKeyBindings()
		{
			int count = actions.Count;
			LogKeyBind("Registering {0:D} key bind(s) for mod {1}".F(count, Assembly.GetExecutingAssembly().GetNameSafe() ?? "?"));
			List<BindingEntry> list = new List<BindingEntry>(GameInputMapping.DefaultBindings);
			foreach (PAction action in actions)
			{
				Action kAction = action.GetKAction();
				PKeyBinding pKeyBinding = action.DefaultBinding;
				if (!FindKeyBinding(list, kAction))
				{
					if (pKeyBinding == null)
					{
						pKeyBinding = new PKeyBinding();
					}
					list.Add(NEW_BINDING_ENTRY("PLib", pKeyBinding.GamePadButton, pKeyBinding.Key, pKeyBinding.Modifiers, kAction));
				}
			}
			GameInputMapping.SetDefaultKeyBindings(list.ToArray());
			UpdateMaxAction();
		}

		private void UpdateMaxAction()
		{
			maxAction = GetSharedData(0);
		}
	}
}
