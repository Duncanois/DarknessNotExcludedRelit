using System;
using UnityEngine;

namespace PeterHan.PLib.UI.Layouts
{
	internal sealed class BoxLayoutStatus
	{
		public readonly PanelDirection direction;

		public readonly RectTransform.Edge edge;

		public readonly float offset;

		public readonly float size;

		internal BoxLayoutStatus(PanelDirection direction, RectOffset margins, float size)
		{
			this.direction = direction;
			switch (direction)
			{
			case PanelDirection.Horizontal:
				edge = RectTransform.Edge.Left;
				offset = margins.left;
				this.size = size - offset - (float)margins.right;
				break;
			case PanelDirection.Vertical:
				edge = RectTransform.Edge.Top;
				offset = margins.top;
				this.size = size - offset - (float)margins.bottom;
				break;
			default:
				throw new ArgumentException("direction");
			}
		}
	}
}
