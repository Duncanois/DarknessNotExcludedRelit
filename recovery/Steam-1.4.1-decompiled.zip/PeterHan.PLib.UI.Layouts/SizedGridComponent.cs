using UnityEngine;

namespace PeterHan.PLib.UI.Layouts
{
	internal sealed class SizedGridComponent : GridComponentSpec
	{
		public LayoutSizes HorizontalSize { get; set; }

		public LayoutSizes VerticalSize { get; set; }

		internal SizedGridComponent(GridComponentSpec spec, GameObject item)
		{
			Alignment = spec.Alignment;
			Column = spec.Column;
			ColumnSpan = spec.ColumnSpan;
			Margin = spec.Margin;
			Row = spec.Row;
			RowSpan = spec.RowSpan;
			HorizontalSize = new LayoutSizes(item);
			VerticalSize = new LayoutSizes(item);
		}
	}
}
