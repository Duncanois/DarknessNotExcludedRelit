using System.Collections;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace PeterHan.PLib.UI.Layouts
{
	internal abstract class AbstractLayoutGroup : UIBehaviour, ISettableFlexSize, ILayoutGroup, ILayoutController, ILayoutElement
	{
		[SerializeField]
		protected bool locked;

		[SerializeField]
		private float mMinWidth;

		[SerializeField]
		private float mMinHeight;

		[SerializeField]
		private float mPreferredWidth;

		[SerializeField]
		private float mPreferredHeight;

		[SerializeField]
		private float mFlexibleWidth;

		[SerializeField]
		private float mFlexibleHeight;

		[SerializeField]
		private int mLayoutPriority;

		private RectTransform cachedTransform;

		public float minWidth
		{
			get
			{
				return mMinWidth;
			}
			set
			{
				mMinWidth = value;
			}
		}

		public float preferredWidth
		{
			get
			{
				return mPreferredWidth;
			}
			set
			{
				mPreferredWidth = value;
			}
		}

		public float flexibleWidth
		{
			get
			{
				return mFlexibleWidth;
			}
			set
			{
				mFlexibleWidth = value;
			}
		}

		public float minHeight
		{
			get
			{
				return mMinHeight;
			}
			set
			{
				mMinHeight = value;
			}
		}

		public float preferredHeight
		{
			get
			{
				return mPreferredHeight;
			}
			set
			{
				mPreferredHeight = value;
			}
		}

		public float flexibleHeight
		{
			get
			{
				return mFlexibleHeight;
			}
			set
			{
				mFlexibleHeight = value;
			}
		}

		public int layoutPriority
		{
			get
			{
				return mLayoutPriority;
			}
			set
			{
				mLayoutPriority = value;
			}
		}

		protected RectTransform rectTransform
		{
			get
			{
				if (cachedTransform == null)
				{
					cachedTransform = gameObject.rectTransform();
				}
				return cachedTransform;
			}
		}

		internal static IEnumerator DelayedSetDirty(RectTransform transform)
		{
			yield return null;
			LayoutRebuilder.MarkLayoutForRebuild(transform);
		}

		internal static void DestroyAndReplaceLayout(GameObject component)
		{
			if (component != null && component.TryGetComponent<AbstractLayoutGroup>(out var component2))
			{
				LayoutElement layoutElement = component.AddOrGet<LayoutElement>();
				layoutElement.flexibleHeight = component2.flexibleHeight;
				layoutElement.flexibleWidth = component2.flexibleWidth;
				layoutElement.layoutPriority = component2.layoutPriority;
				layoutElement.minHeight = component2.minHeight;
				layoutElement.minWidth = component2.minWidth;
				layoutElement.preferredHeight = component2.preferredHeight;
				layoutElement.preferredWidth = component2.preferredWidth;
				Object.DestroyImmediate(component2);
			}
		}

		protected AbstractLayoutGroup()
		{
			cachedTransform = null;
			locked = false;
			mLayoutPriority = 1;
		}

		public abstract void CalculateLayoutInputHorizontal();

		public abstract void CalculateLayoutInputVertical();

		public virtual Vector2 LockLayout()
		{
			RectTransform rectTransform = gameObject.rectTransform();
			if (rectTransform != null)
			{
				locked = false;
				CalculateLayoutInputHorizontal();
				rectTransform.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, minWidth);
				SetLayoutHorizontal();
				CalculateLayoutInputVertical();
				rectTransform.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, minHeight);
				SetLayoutVertical();
				locked = true;
			}
			return new Vector2(minWidth, minHeight);
		}

		protected override void OnDidApplyAnimationProperties()
		{
			base.OnDidApplyAnimationProperties();
			SetDirty();
		}

		protected override void OnDisable()
		{
			base.OnDisable();
			SetDirty();
		}

		protected override void OnEnable()
		{
			base.OnEnable();
			SetDirty();
		}

		protected override void OnRectTransformDimensionsChange()
		{
			base.OnRectTransformDimensionsChange();
			SetDirty();
		}

		protected virtual void SetDirty()
		{
			if (gameObject != null && IsActive())
			{
				if (CanvasUpdateRegistry.IsRebuildingLayout())
				{
					LayoutRebuilder.MarkLayoutForRebuild(rectTransform);
				}
				else
				{
					StartCoroutine(DelayedSetDirty(rectTransform));
				}
			}
		}

		public abstract void SetLayoutHorizontal();

		public abstract void SetLayoutVertical();

		public virtual void UnlockLayout()
		{
			locked = false;
			LayoutRebuilder.MarkLayoutForRebuild(gameObject.rectTransform());
		}
	}
}
