using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.UI;

namespace PeterHan.PLib.UI.Layouts
{
	internal static class RelativeLayoutUtil
	{
		internal static void CalcX(this ICollection<RelativeLayoutResults> children, RectTransform all, IDictionary<GameObject, RelativeLayoutParams> constraints)
		{
			ListPool<Component, RelativeLayoutGroup>.PooledList pooledList = ListPool<Component, RelativeLayoutGroup>.Allocate();
			DictionaryPool<GameObject, RelativeLayoutResults, RelativeLayoutGroup>.PooledDictionary pooledDictionary = DictionaryPool<GameObject, RelativeLayoutResults, RelativeLayoutGroup>.Allocate();
			int childCount = all.childCount;
			children.Clear();
			for (int i = 0; i < childCount; i++)
			{
				GameObject gameObject = all.GetChild(i)?.gameObject;
				if (!(gameObject != null))
				{
					continue;
				}
				pooledList.Clear();
				gameObject.GetComponents(pooledList);
				LayoutSizes layoutSizes = PUIUtils.CalcSizes(gameObject, PanelDirection.Horizontal, pooledList);
				if (layoutSizes.ignore)
				{
					continue;
				}
				float preferredWidth = layoutSizes.preferred;
				RelativeLayoutResults relativeLayoutResults;
				if (constraints.TryGetValue(gameObject, out var value))
				{
					relativeLayoutResults = new RelativeLayoutResults(gameObject.rectTransform(), value);
					Vector2 overrideSize = relativeLayoutResults.OverrideSize;
					if (overrideSize.x > 0f)
					{
						preferredWidth = overrideSize.x;
					}
					pooledDictionary[gameObject] = relativeLayoutResults;
				}
				else
				{
					relativeLayoutResults = new RelativeLayoutResults(gameObject.rectTransform(), null);
				}
				relativeLayoutResults.PreferredWidth = preferredWidth;
				children.Add(relativeLayoutResults);
			}
			foreach (RelativeLayoutResults child in children)
			{
				child.TopParams = InitResolve(child.TopEdge, pooledDictionary);
				child.BottomParams = InitResolve(child.BottomEdge, pooledDictionary);
				child.LeftParams = InitResolve(child.LeftEdge, pooledDictionary);
				child.RightParams = InitResolve(child.RightEdge, pooledDictionary);
			}
			pooledDictionary.Recycle();
			pooledList.Recycle();
		}

		internal static void CalcY(this ICollection<RelativeLayoutResults> children)
		{
			ListPool<Component, RelativeLayoutGroup>.PooledList pooledList = ListPool<Component, RelativeLayoutGroup>.Allocate();
			foreach (RelativeLayoutResults child in children)
			{
				GameObject gameObject = child.Transform.gameObject;
				Vector2 overrideSize = child.OverrideSize;
				pooledList.Clear();
				gameObject.gameObject.GetComponents(pooledList);
				float preferredHeight = PUIUtils.CalcSizes(gameObject, PanelDirection.Vertical, pooledList).preferred;
				if (overrideSize.y > 0f)
				{
					preferredHeight = overrideSize.y;
				}
				child.PreferredHeight = preferredHeight;
			}
			pooledList.Recycle();
		}

		internal static float ElbowRoom(RelativeLayoutParamsBase<GameObject>.EdgeStatus min, RelativeLayoutParamsBase<GameObject>.EdgeStatus max, float effective)
		{
			float fromAnchor = min.FromAnchor;
			float fromAnchor2 = max.FromAnchor;
			float offset = min.Offset;
			float offset2 = max.Offset;
			if (fromAnchor2 > fromAnchor)
			{
				return (effective + offset - offset2) / (fromAnchor2 - fromAnchor);
			}
			return Math.Max(effective, Math.Max(Math.Abs(offset), Math.Abs(offset2)));
		}

		internal static void ExecuteX(this IEnumerable<RelativeLayoutResults> children, List<ILayoutController> scratch, float mLeft = 0f, float mRight = 0f)
		{
			foreach (RelativeLayoutResults child in children)
			{
				RectTransform transform = child.Transform;
				RectOffset insets = child.Insets;
				RelativeLayoutParamsBase<GameObject>.EdgeStatus leftEdge = child.LeftEdge;
				RelativeLayoutParamsBase<GameObject>.EdgeStatus rightEdge = child.RightEdge;
				transform.anchorMin = new Vector2(leftEdge.FromAnchor, 0f);
				transform.anchorMax = new Vector2(rightEdge.FromAnchor, 1f);
				if (child.UseSizeDeltaX)
				{
					transform.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, child.PreferredWidth);
				}
				else
				{
					transform.offsetMin = new Vector2(leftEdge.Offset + (float)insets.left + ((leftEdge.FromAnchor <= 0f) ? mLeft : 0f), transform.offsetMin.y);
					transform.offsetMax = new Vector2(rightEdge.Offset - (float)insets.right - ((rightEdge.FromAnchor >= 1f) ? mRight : 0f), transform.offsetMax.y);
				}
				scratch.Clear();
				transform.gameObject.GetComponents(scratch);
				foreach (ILayoutController item in scratch)
				{
					item.SetLayoutHorizontal();
				}
			}
		}

		internal static void ExecuteY(this IEnumerable<RelativeLayoutResults> children, List<ILayoutController> scratch, float mBottom = 0f, float mTop = 0f)
		{
			foreach (RelativeLayoutResults child in children)
			{
				RectTransform transform = child.Transform;
				RectOffset insets = child.Insets;
				RelativeLayoutParamsBase<GameObject>.EdgeStatus topEdge = child.TopEdge;
				RelativeLayoutParamsBase<GameObject>.EdgeStatus bottomEdge = child.BottomEdge;
				transform.anchorMin = new Vector2(transform.anchorMin.x, bottomEdge.FromAnchor);
				transform.anchorMax = new Vector2(transform.anchorMax.x, topEdge.FromAnchor);
				if (child.UseSizeDeltaY)
				{
					transform.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, child.PreferredHeight);
				}
				else
				{
					transform.offsetMin = new Vector2(transform.offsetMin.x, bottomEdge.Offset + (float)insets.bottom + ((bottomEdge.FromAnchor <= 0f) ? mBottom : 0f));
					transform.offsetMax = new Vector2(transform.offsetMax.x, topEdge.Offset - (float)insets.top - ((topEdge.FromAnchor >= 1f) ? mTop : 0f));
				}
				scratch.Clear();
				transform.gameObject.GetComponents(scratch);
				foreach (ILayoutController item in scratch)
				{
					item.SetLayoutVertical();
				}
			}
		}

		internal static float GetMinSizeX(this IEnumerable<RelativeLayoutResults> children)
		{
			float num = 0f;
			foreach (RelativeLayoutResults child in children)
			{
				float num2 = ElbowRoom(child.LeftEdge, child.RightEdge, child.EffectiveWidth);
				if (num2 > num)
				{
					num = num2;
				}
			}
			return num;
		}

		internal static float GetMinSizeY(this IEnumerable<RelativeLayoutResults> children)
		{
			float num = 0f;
			foreach (RelativeLayoutResults child in children)
			{
				float num2 = ElbowRoom(child.BottomEdge, child.TopEdge, child.EffectiveHeight);
				if (num2 > num)
				{
					num = num2;
				}
			}
			return num;
		}

		private static RelativeLayoutResults InitResolve(RelativeLayoutParamsBase<GameObject>.EdgeStatus edge, IDictionary<GameObject, RelativeLayoutResults> lookup)
		{
			RelativeLayoutResults value = null;
			if (edge.Constraint == RelativeConstraintType.ToComponent && !lookup.TryGetValue(edge.FromComponent, out value))
			{
				edge.Constraint = RelativeConstraintType.Unconstrained;
			}
			return value;
		}

		private static bool LockEdgeAnchor(RelativeLayoutParamsBase<GameObject>.EdgeStatus edge, RelativeLayoutParamsBase<GameObject>.EdgeStatus otherEdge)
		{
			int num;
			if (edge.Constraint == RelativeConstraintType.ToAnchor && otherEdge.Constraint == RelativeConstraintType.ToAnchor)
			{
				num = ((edge.FromAnchor == otherEdge.FromAnchor) ? 1 : 0);
				if (num != 0)
				{
					edge.Constraint = RelativeConstraintType.Locked;
					otherEdge.Constraint = RelativeConstraintType.Locked;
					edge.Offset = 0f;
					otherEdge.Offset = 0f;
				}
			}
			else
			{
				num = 0;
			}
			return (byte)num != 0;
		}

		private static void LockEdgeAnchor(RelativeLayoutParamsBase<GameObject>.EdgeStatus edge)
		{
			if (edge.Constraint == RelativeConstraintType.ToAnchor)
			{
				edge.Constraint = RelativeConstraintType.Locked;
				edge.Offset = 0f;
			}
		}

		private static void LockEdgeComponent(RelativeLayoutParamsBase<GameObject>.EdgeStatus edge, RelativeLayoutParamsBase<GameObject>.EdgeStatus otherEdge)
		{
			if (edge.Constraint == RelativeConstraintType.ToComponent && otherEdge.Locked)
			{
				edge.Constraint = RelativeConstraintType.Locked;
				edge.FromAnchor = otherEdge.FromAnchor;
				edge.Offset = otherEdge.Offset;
			}
		}

		private static void LockEdgeRelative(RelativeLayoutParamsBase<GameObject>.EdgeStatus edge, float size, RelativeLayoutParamsBase<GameObject>.EdgeStatus opposing)
		{
			if (edge.Constraint == RelativeConstraintType.Unconstrained)
			{
				if (opposing.Locked)
				{
					edge.Constraint = RelativeConstraintType.Locked;
					edge.FromAnchor = opposing.FromAnchor;
					edge.Offset = opposing.Offset + size;
				}
				else if (opposing.Constraint == RelativeConstraintType.Unconstrained)
				{
					edge.Constraint = RelativeConstraintType.Locked;
					edge.FromAnchor = 0f;
					edge.Offset = 0f;
					opposing.Constraint = RelativeConstraintType.Locked;
					opposing.FromAnchor = 1f;
					opposing.Offset = 0f;
				}
			}
		}

		internal static bool RunPassX(this IEnumerable<RelativeLayoutResults> children)
		{
			bool result = true;
			foreach (RelativeLayoutResults child in children)
			{
				float effectiveWidth = child.EffectiveWidth;
				RelativeLayoutParamsBase<GameObject>.EdgeStatus leftEdge = child.LeftEdge;
				RelativeLayoutParamsBase<GameObject>.EdgeStatus rightEdge = child.RightEdge;
				if (LockEdgeAnchor(leftEdge, rightEdge))
				{
					child.UseSizeDeltaX = true;
				}
				LockEdgeAnchor(leftEdge);
				LockEdgeAnchor(rightEdge);
				LockEdgeRelative(leftEdge, 0f - effectiveWidth, rightEdge);
				LockEdgeRelative(rightEdge, effectiveWidth, leftEdge);
				if (child.LeftParams != null)
				{
					LockEdgeComponent(leftEdge, child.LeftParams.RightEdge);
				}
				if (child.RightParams != null)
				{
					LockEdgeComponent(rightEdge, child.RightParams.LeftEdge);
				}
				if (!leftEdge.Locked || !rightEdge.Locked)
				{
					result = false;
				}
			}
			return result;
		}

		internal static bool RunPassY(this IEnumerable<RelativeLayoutResults> children)
		{
			bool result = true;
			foreach (RelativeLayoutResults child in children)
			{
				float effectiveHeight = child.EffectiveHeight;
				RelativeLayoutParamsBase<GameObject>.EdgeStatus topEdge = child.TopEdge;
				RelativeLayoutParamsBase<GameObject>.EdgeStatus bottomEdge = child.BottomEdge;
				if (LockEdgeAnchor(topEdge, bottomEdge))
				{
					child.UseSizeDeltaY = true;
				}
				LockEdgeAnchor(bottomEdge);
				LockEdgeAnchor(topEdge);
				LockEdgeRelative(bottomEdge, 0f - effectiveHeight, topEdge);
				LockEdgeRelative(topEdge, effectiveHeight, bottomEdge);
				if (child.BottomParams != null)
				{
					LockEdgeComponent(bottomEdge, child.BottomParams.TopEdge);
				}
				if (child.TopParams != null)
				{
					LockEdgeComponent(topEdge, child.TopParams.BottomEdge);
				}
				if (!topEdge.Locked || !bottomEdge.Locked)
				{
					result = false;
				}
			}
			return result;
		}

		internal static void ThrowUnresolvable(this IEnumerable<RelativeLayoutResults> children, int limit, PanelDirection direction)
		{
			StringBuilder stringBuilder = new StringBuilder(256);
			stringBuilder.Append("After ").Append(limit);
			stringBuilder.Append(" passes, unable to complete resolution of RelativeLayout:");
			foreach (RelativeLayoutResults child in children)
			{
				string name = child.Transform.gameObject.name;
				if (direction == PanelDirection.Horizontal)
				{
					if (!child.LeftEdge.Locked)
					{
						stringBuilder.Append(' ');
						stringBuilder.Append(name);
						stringBuilder.Append(".Left");
					}
					if (!child.RightEdge.Locked)
					{
						stringBuilder.Append(' ');
						stringBuilder.Append(name);
						stringBuilder.Append(".Right");
					}
				}
				else
				{
					if (!child.BottomEdge.Locked)
					{
						stringBuilder.Append(' ');
						stringBuilder.Append(name);
						stringBuilder.Append(".Bottom");
					}
					if (!child.TopEdge.Locked)
					{
						stringBuilder.Append(' ');
						stringBuilder.Append(name);
						stringBuilder.Append(".Top");
					}
				}
			}
			throw new InvalidOperationException(stringBuilder.ToString());
		}
	}
}
