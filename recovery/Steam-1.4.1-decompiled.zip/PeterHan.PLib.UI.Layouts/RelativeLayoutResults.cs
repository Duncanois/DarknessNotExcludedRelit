using System;
using UnityEngine;

namespace PeterHan.PLib.UI.Layouts
{
	internal sealed class RelativeLayoutResults : RelativeLayoutParamsBase<GameObject>
	{
		private static readonly RectOffset ZERO = new RectOffset();

		private Vector2 prefSize;

		internal RelativeLayoutResults BottomParams { get; set; }

		internal float EffectiveHeight { get; private set; }

		internal float EffectiveWidth { get; private set; }

		internal RelativeLayoutResults LeftParams { get; set; }

		internal float PreferredHeight
		{
			get
			{
				return prefSize.y;
			}
			set
			{
				prefSize.y = value;
				EffectiveHeight = value + (float)Insets.top + (float)Insets.bottom;
			}
		}

		internal float PreferredWidth
		{
			get
			{
				return prefSize.x;
			}
			set
			{
				prefSize.x = value;
				EffectiveWidth = value + (float)Insets.left + (float)Insets.right;
			}
		}

		internal RelativeLayoutResults RightParams { get; set; }

		internal RelativeLayoutResults TopParams { get; set; }

		internal RectTransform Transform { get; set; }

		internal bool UseSizeDeltaX { get; set; }

		internal bool UseSizeDeltaY { get; set; }

		internal RelativeLayoutResults(RectTransform transform, RelativeLayoutParams other)
		{
			Transform = transform ?? throw new ArgumentNullException("transform");
			if (other != null)
			{
				BottomEdge.CopyFrom(other.BottomEdge);
				TopEdge.CopyFrom(other.TopEdge);
				RightEdge.CopyFrom(other.RightEdge);
				LeftEdge.CopyFrom(other.LeftEdge);
				Insets = other.Insets ?? ZERO;
				OverrideSize = other.OverrideSize;
			}
			else
			{
				Insets = ZERO;
			}
			BottomParams = (LeftParams = (TopParams = (RightParams = null)));
			PreferredWidth = (PreferredHeight = 0f);
			UseSizeDeltaX = (UseSizeDeltaY = false);
		}

		public override string ToString()
		{
			GameObject gameObject = Transform.gameObject;
			return string.Format("component={0} {1:F2}x{2:F2}", (gameObject == null) ? "null" : gameObject.name, prefSize.x, prefSize.y);
		}
	}
}
