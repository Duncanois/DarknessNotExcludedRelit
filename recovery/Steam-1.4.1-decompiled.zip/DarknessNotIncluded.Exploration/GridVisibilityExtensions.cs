using System;
using HarmonyLib;

namespace DarknessNotIncluded.Exploration
{
	public static class GridVisibilityExtensions
	{
		[HarmonyPatch(typeof(GridVisibility))]
		[HarmonyPatch("OnCellChange")]
		private static class Patched_GridVisibility_OnCellChange
		{
			private static bool Prefix(GridVisibility __instance)
			{
				if (__instance == null)
				{
					return false;
				}
				if (__instance.gameObject == null)
				{
					return false;
				}
				if (__instance.gameObject.HasTag(GameTags.Dead))
				{
					return false;
				}
				int num = Grid.PosToCell(__instance);
				if (!Grid.IsValidCell(num))
				{
					return false;
				}
				VisibilityUtils.RevealArea(num, __instance.radius, __instance.innerRadius);
				return false;
			}
		}

		public static void SetRadius(this GridVisibility gridVisibility, int radius)
		{
			if (!(gridVisibility == null))
			{
				radius = Math.Max(1, radius);
				if (radius != gridVisibility.radius)
				{
					gridVisibility.radius = radius;
					gridVisibility.innerRadius = (float)gridVisibility.radius * 0.7f;
				}
			}
		}
	}
}
