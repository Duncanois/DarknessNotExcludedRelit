using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;

namespace DarknessNotIncluded.Exploration
{
	public static class DragOverFogOfWar
	{
		[HarmonyPatch(typeof(DragTool))]
		[HarmonyPatch("OnLeftClickUp")]
		private static class Patched_DragTool_OnLeftClickUp
		{
			private static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
			{
				MethodInfo GridIsVisible = typeof(Grid).GetMethod("IsVisible");
				foreach (CodeInstruction instruction in instructions)
				{
					if (instruction.Calls(GridIsVisible))
					{
						yield return CodeInstruction.Call(typeof(DragOverFogOfWar), "ShouldConsiderCell");
					}
					else
					{
						yield return instruction;
					}
				}
			}
		}

		private static bool dragToolIgnoresVisibility;

		private static Config.Observer configObserver = new Config.Observer((Config config) =>
		{
			dragToolIgnoresVisibility = config.dragToolIgnoresVisibility;
		});

		private static bool ShouldConsiderCell(int cell)
		{
			if (dragToolIgnoresVisibility)
			{
				return true;
			}
			return Grid.IsVisible(cell);
		}
	}
}
