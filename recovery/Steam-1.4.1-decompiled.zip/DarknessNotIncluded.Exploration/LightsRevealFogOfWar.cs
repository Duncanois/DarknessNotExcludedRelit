using System;
using System.Collections.Generic;
using HarmonyLib;

namespace DarknessNotIncluded.Exploration
{
	internal static class LightsRevealFogOfWar
	{
		[HarmonyPatch(typeof(LightGridManager.LightGridEmitter))]
		[HarmonyPatch("AddToGrid")]
		private static class Patched_LightGridManager_LightGridEmitter_AddToGrid
		{
			private static void Postfix(List<int> ___litCells)
			{
				try
				{
					if ((Config.instance != null && Config.instance.occludeVisibilityByWalls) || ___litCells == null || ___litCells.Count == 0)
					{
						return;
					}
					bool flag = false;
					foreach (int ___litCell in ___litCells)
					{
						if (!Grid.IsValidCell(___litCell) || Grid.Visible[___litCell] <= 0)
						{
							continue;
						}
						flag = true;
						break;
					}
					if (!flag)
					{
						return;
					}
					HashSet<int> hashSet = ExpandRegion(___litCells);
					foreach (int item in hashSet)
					{
						if (Grid.IsValidCell(item))
						{
							try
							{
								Grid.Reveal(item);
							}
							catch (Exception arg)
							{
								Debug.LogWarning($"[DarknessNotIncluded] LightsRevealFogOfWar Grid.Reveal failed for cell {item}: {arg}");
							}
						}
					}
				}
				catch (Exception arg2)
				{
					Debug.LogWarning($"[DarknessNotIncluded] LightsRevealFogOfWar AddToGrid postfix threw: {arg2}");
				}
			}
		}

		private static HashSet<int> ExpandRegion(List<int> litCells)
		{
			HashSet<int> hashSet = new HashSet<int>(litCells);
			foreach (int litCell in litCells)
			{
				hashSet.Add(Grid.CellAbove(litCell));
				hashSet.Add(Grid.CellUpRight(litCell));
				hashSet.Add(Grid.CellRight(litCell));
				hashSet.Add(Grid.CellDownRight(litCell));
				hashSet.Add(Grid.CellBelow(litCell));
				hashSet.Add(Grid.CellDownLeft(litCell));
				hashSet.Add(Grid.CellLeft(litCell));
				hashSet.Add(Grid.CellUpLeft(litCell));
				hashSet.Add(Grid.CellUpLeft(Grid.CellAbove(litCell)));
				hashSet.Add(Grid.CellAbove(Grid.CellAbove(litCell)));
				hashSet.Add(Grid.CellUpRight(Grid.CellAbove(litCell)));
				hashSet.Add(Grid.CellUpRight(Grid.CellRight(litCell)));
				hashSet.Add(Grid.CellRight(Grid.CellRight(litCell)));
				hashSet.Add(Grid.CellDownRight(Grid.CellRight(litCell)));
				hashSet.Add(Grid.CellDownRight(Grid.CellBelow(litCell)));
				hashSet.Add(Grid.CellBelow(Grid.CellBelow(litCell)));
				hashSet.Add(Grid.CellDownLeft(Grid.CellBelow(litCell)));
				hashSet.Add(Grid.CellDownLeft(Grid.CellLeft(litCell)));
				hashSet.Add(Grid.CellLeft(Grid.CellLeft(litCell)));
				hashSet.Add(Grid.CellUpLeft(Grid.CellLeft(litCell)));
			}
			return hashSet;
		}
	}
}
