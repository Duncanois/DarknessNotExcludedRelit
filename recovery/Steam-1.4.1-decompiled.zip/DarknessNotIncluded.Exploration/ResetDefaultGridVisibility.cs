using HarmonyLib;
using UnityEngine;

namespace DarknessNotIncluded.Exploration
{
	internal static class ResetDefaultGridVisibility
	{
		[HarmonyPatch(typeof(MinionConfig))]
		[HarmonyPatch("CreatePrefab")]
		private static class Patched_MinionConfig_CreatePrefab
		{
			private static void Postfix(GameObject __result)
			{
				GridVisibility gridVisibility = __result.AddOrGet<GridVisibility>();
				gridVisibility.SetRadius(0);
			}
		}
	}
}
