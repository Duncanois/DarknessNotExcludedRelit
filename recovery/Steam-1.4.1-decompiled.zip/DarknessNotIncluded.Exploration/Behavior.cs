using System;
using System.Collections.Generic;
using UnityEngine;

namespace DarknessNotIncluded.Exploration
{
	public static class Behavior
	{
		public class BuildingLightingManager : KMonoBehaviour
		{
			public BuildingType buildingType;

			protected LightConfig lightConfig;

			protected Light2D light;

			protected GridVisibility gridVisibility;

			protected override void OnPrefabInit()
			{
				base.OnPrefabInit();
				light = gameObject.AddOrGet<Light2D>();
				gridVisibility = gameObject.AddOrGet<GridVisibility>();
				Config.ObserveFor(this, (Config config) =>
				{
					lightConfig = config.buildingLightingConfig[buildingType];
					lightConfig.ConfigureLight(light);
					gridVisibility.SetRadius(Math.Max(0, lightConfig.reveal - 1));
					if (gridVisibility.isSpawned)
					{
						VisibilityUtils.RevealArea(Grid.PosToCell(gameObject), gridVisibility.radius, gridVisibility.innerRadius);
					}
				});
			}
		}

		public class BuildingAnimatedLightingManager : BuildingLightingManager
		{
			private static Dictionary<BuildingType, Dictionary<string, Dictionary<int, Vector2>>> FRAME_OFFSETS = new Dictionary<BuildingType, Dictionary<string, Dictionary<int, Vector2>>>();

			private string currentAnimName;

			private int currentFrame;

			[MyCmpGet]
			private KBatchedAnimController animController;

			public static void RegisterFrameOffsets(BuildingType buildingType, Dictionary<string, Dictionary<int, Vector2>> frameOffsets)
			{
				FRAME_OFFSETS[buildingType] = frameOffsets;
			}

			public void Update()
			{
				if (FRAME_OFFSETS.ContainsKey(buildingType) && !(animController == null) && animController.CurrentAnim != null && (!(animController.CurrentAnim.name == currentAnimName) || animController.currentFrame != currentFrame))
				{
					currentAnimName = animController.CurrentAnim.name;
					currentFrame = animController.currentFrame;
					Dictionary<string, Dictionary<int, Vector2>> dictionary = FRAME_OFFSETS[buildingType];
					if (dictionary.ContainsKey(currentAnimName) && dictionary[currentAnimName].ContainsKey(currentFrame))
					{
						light.enabled = lightConfig.enabled;
						light.Offset = dictionary[currentAnimName][currentFrame];
					}
					else
					{
						light.enabled = false;
					}
					light.FullRefresh();
				}
			}
		}
	}
}
