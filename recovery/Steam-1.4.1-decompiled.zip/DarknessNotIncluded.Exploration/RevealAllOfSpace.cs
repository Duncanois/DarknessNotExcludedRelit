using System;
using System.Collections.Generic;
using HarmonyLib;
using ProcGen;

namespace DarknessNotIncluded.Exploration
{
	public static class RevealAllOfSpace
	{
		[HarmonyPatch(typeof(World))]
		[HarmonyPatch("OnSpawn")]
		private static class Patched_World_OnSpawn
		{
			private static void Postfix()
			{
				if (!isHooked)
				{
					isHooked = true;
					Grid.OnReveal = (Action<int>)Delegate.Combine(Grid.OnReveal, new Action<int>(OnReveal));
				}
			}

			private static void OnReveal(int targetCell)
			{
				try
				{
					if (Grid.IsValidCell(targetCell) && !(Game.Instance == null) && !(Game.Instance.world == null) && !(ClusterManager.Instance == null) && IsSpaceBiomeAndLitBySunlight(targetCell) && !SEEN.Contains(targetCell))
					{
						SEEN.Add(targetCell);
						frontier.Enqueue(targetCell);
						EnsureProcessing();
					}
				}
				catch (Exception arg)
				{
					Debug.LogWarning($"[DarknessNotIncluded] RevealAllOfSpace OnReveal handler threw: {arg}");
				}
			}

			private static void EnsureProcessing()
			{
				if (isProcessing)
				{
					return;
				}
				isProcessing = true;
				try
				{
					GameScheduler.Instance.Schedule("DNI_RevealAllOfSpace", 0f, ProcessBatch);
				}
				catch (Exception arg)
				{
					isProcessing = false;
					Debug.LogWarning($"[DarknessNotIncluded] Failed to schedule RevealAllOfSpace batch processor: {arg}");
				}
			}

			private static void ProcessBatch(object _)
			{
				try
				{
					if (Game.Instance == null || Game.Instance.world == null || ClusterManager.Instance == null)
					{
						frontier.Clear();
						isProcessing = false;
						return;
					}
					int num = 0;
					while (num < 250 && frontier.Count > 0)
					{
						int num2 = frontier.Dequeue();
						if (Grid.IsValidCell(num2) && IsSpaceBiomeAndLitBySunlight(num2))
						{
							try
							{
								Grid.Reveal(num2);
							}
							catch (Exception arg)
							{
								Debug.LogWarning($"[DarknessNotIncluded] Grid.Reveal failed for cell {num2}: {arg}");
							}
							int num3 = -1;
							try
							{
								num3 = Grid.WorldIdx[num2];
							}
							catch
							{
								num3 = -1;
							}
							if (num3 >= 0)
							{
								EnqueueIfEligible(num3, Grid.CellAbove(num2));
								EnqueueIfEligible(num3, Grid.CellRight(num2));
								EnqueueIfEligible(num3, Grid.CellBelow(num2));
								EnqueueIfEligible(num3, Grid.CellLeft(num2));
								EnqueueIfEligible(num3, Grid.CellUpRight(num2));
								EnqueueIfEligible(num3, Grid.CellDownRight(num2));
								EnqueueIfEligible(num3, Grid.CellDownLeft(num2));
								EnqueueIfEligible(num3, Grid.CellUpLeft(num2));
							}
							num++;
						}
					}
					if (frontier.Count > 0)
					{
						GameScheduler.Instance.Schedule("DNI_RevealAllOfSpace", 0f, ProcessBatch);
					}
					else
					{
						isProcessing = false;
					}
				}
				catch (Exception arg2)
				{
					isProcessing = false;
					Debug.LogWarning($"[DarknessNotIncluded] RevealAllOfSpace batch processor threw: {arg2}");
				}
			}

			private static void EnqueueIfEligible(int worldIdx, int neighbour)
			{
				if (!Grid.IsValidCell(neighbour))
				{
					return;
				}
				try
				{
					if (Grid.WorldIdx[neighbour] != worldIdx)
					{
						return;
					}
				}
				catch
				{
					return;
				}
				if (SEEN.Add(neighbour) && IsSpaceBiomeAndLitBySunlight(neighbour))
				{
					frontier.Enqueue(neighbour);
				}
			}

			private static bool IsSpaceBiomeAndLitBySunlight(int cell)
			{
				if (!Grid.IsValidCell(cell))
				{
					return false;
				}
				if (Game.Instance == null || Game.Instance.world == null)
				{
					return false;
				}
				SubworldZoneRenderData zoneRenderData = Game.Instance.world.zoneRenderData;
				if (zoneRenderData == null)
				{
					return false;
				}
				SubWorld.ZoneType subWorldZoneType;
				try
				{
					subWorldZoneType = zoneRenderData.GetSubWorldZoneType(cell);
				}
				catch
				{
					return false;
				}
				bool flag = subWorldZoneType == SubWorld.ZoneType.Space;
				bool flag2;
				try
				{
					flag2 = Grid.Objects[cell, 2] == null;
				}
				catch
				{
					return false;
				}
				bool flag3;
				try
				{
					flag3 = Grid.ExposedToSunlight[cell] > 0;
				}
				catch
				{
					return false;
				}
				return flag & flag2 & flag3;
			}
		}

		private static readonly HashSet<int> SEEN = new HashSet<int>();

		private static readonly Queue<int> frontier = new Queue<int>();

		private static bool isHooked;

		private static bool isProcessing;

		private const int REVEAL_BATCH_SIZE = 250;
	}
}
