using System.Collections.Generic;
using HarmonyLib;
using TUNING;
using UnityEngine;

namespace DarknessNotIncluded.Exploration
{
	internal static class HydrogenGeneratorLighting
	{
		[HarmonyPatch(typeof(HydrogenGeneratorConfig))]
		[HarmonyPatch("DoPostConfigureComplete")]
		private static class Patched_HydrogenGeneratorConfig_DoPostConfigureComplete
		{
			private static void Postfix(GameObject go)
			{
				Light2D light2D = go.AddOrGet<Light2D>();
				light2D.drawOverlay = true;
				light2D.overlayColour = LIGHT2D.LIGHT_OVERLAY;
				Behavior.BuildingAnimatedLightingManager buildingAnimatedLightingManager = go.AddOrGet<Behavior.BuildingAnimatedLightingManager>();
				buildingAnimatedLightingManager.buildingType = BuildingType.HydrogenGenerator;
				Behavior.BuildingAnimatedLightingManager.RegisterFrameOffsets(BuildingType.HydrogenGenerator, new Dictionary<string, Dictionary<int, Vector2>> { 
				{
					"working_loop",
					new Dictionary<int, Vector2>
					{
						{
							34,
							new Vector2(1.45f, 2.65f)
						},
						{
							35,
							new Vector2(1.45f, 2.65f)
						},
						{
							36,
							new Vector2(1.45f, 2.65f)
						},
						{
							37,
							new Vector2(1.45f, 2.55f)
						},
						{
							38,
							new Vector2(1.45f, 2.45f)
						},
						{
							39,
							new Vector2(1.45f, 2.425f)
						},
						{
							40,
							new Vector2(1.45f, 2.4f)
						},
						{
							41,
							new Vector2(1.45f, 2.35f)
						},
						{
							42,
							new Vector2(1.45f, 2.3f)
						},
						{
							43,
							new Vector2(1.45f, 2.25f)
						},
						{
							44,
							new Vector2(1.45f, 2.125f)
						},
						{
							45,
							new Vector2(1.45f, 2.05f)
						},
						{
							46,
							new Vector2(1.45f, 2f)
						},
						{
							47,
							new Vector2(1.45f, 1.95f)
						},
						{
							48,
							new Vector2(1.45f, 1.85f)
						},
						{
							49,
							new Vector2(1.45f, 1.75f)
						},
						{
							50,
							new Vector2(1.45f, 1.7f)
						},
						{
							51,
							new Vector2(1.45f, 1.65f)
						},
						{
							52,
							new Vector2(1.45f, 1.6f)
						},
						{
							53,
							new Vector2(1.45f, 1.55f)
						},
						{
							54,
							new Vector2(1.45f, 1.558f)
						},
						{
							55,
							new Vector2(1.45f, 1.555f)
						},
						{
							56,
							new Vector2(1.45f, 1.5f)
						},
						{
							57,
							new Vector2(1.45f, 1.45f)
						},
						{
							58,
							new Vector2(1.45f, 1.45f)
						},
						{
							59,
							new Vector2(1.45f, 1.45f)
						}
					}
				} });
			}
		}
	}
}
