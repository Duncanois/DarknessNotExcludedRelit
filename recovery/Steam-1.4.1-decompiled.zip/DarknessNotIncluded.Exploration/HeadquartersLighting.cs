using HarmonyLib;
using UnityEngine;

namespace DarknessNotIncluded.Exploration
{
	internal static class HeadquartersLighting
	{
		[HarmonyPatch(typeof(HeadquartersConfig))]
		[HarmonyPatch("ConfigureBuildingTemplate")]
		private static class Patched_HeadquartersConfig_ConfigureBuildingTemplate
		{
			private static void Postfix(GameObject go)
			{
				Behavior.BuildingLightingManager buildingLightingManager = go.AddComponent<Behavior.BuildingLightingManager>();
				buildingLightingManager.buildingType = BuildingType.PrintingPod;
			}
		}

		[HarmonyPatch(typeof(WorldGenSpawner))]
		[HarmonyPatch("OnSpawn")]
		private static class Patched_WorldGenSpawner_OnSpawn
		{
			private static bool isGeneratingWorld;

			private static void Prefix(bool ___hasPlacedTemplates)
			{
				isGeneratingWorld = !___hasPlacedTemplates;
			}

			private static void Postfix()
			{
				if (isGeneratingWorld)
				{
					isGeneratingWorld = false;
					for (int i = 0; i < Grid.CellCount; i++)
					{
						Grid.Visible[i] = 0;
					}
				}
			}
		}
	}
}
