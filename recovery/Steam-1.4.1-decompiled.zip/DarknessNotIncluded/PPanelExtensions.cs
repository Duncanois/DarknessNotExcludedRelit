using System.Collections.Generic;
using HarmonyLib;
using PeterHan.PLib.UI;

namespace DarknessNotIncluded
{
	public static class PPanelExtensions
	{
		public static IUIComponent GetChildNamed(this PPanel panel, string name)
		{
			if (panel == null)
			{
				return null;
			}
			IEnumerable<object> value = Traverse.Create(panel).Field("children").GetValue<IEnumerable<object>>();
			foreach (object item in value)
			{
				string value2 = Traverse.Create(item).Property("Name").GetValue<string>();
				if (value2 == name)
				{
					return item as IUIComponent;
				}
			}
			return null;
		}
	}
}
