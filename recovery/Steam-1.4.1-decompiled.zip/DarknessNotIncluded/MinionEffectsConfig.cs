using System.Collections.Generic;

namespace DarknessNotIncluded
{
	public class MinionEffectsConfig : Dictionary<MinionEffectType, MinionEffectsConfig.EffectConfig>
	{
		public class EffectConfig
		{
			public bool enabled { get; set; }

			public int luxThreshold { get; set; }

			public int agilityModifier { get; set; }

			public int statsModifier { get; set; }

			public EffectConfig(bool enabled, int luxThreshold, int agilityModifier, int athleticsModifier)
			{
				this.enabled = enabled;
				this.luxThreshold = luxThreshold;
				this.agilityModifier = agilityModifier;
				statsModifier = athleticsModifier;
			}

			public EffectConfig DeepClone()
			{
				return new EffectConfig(enabled, luxThreshold, agilityModifier, statsModifier);
			}
		}

		public MinionEffectsConfig()
		{
			Add(MinionEffectType.Dim, new EffectConfig(enabled: true, 700, -2, -1));
			Add(MinionEffectType.Dark, new EffectConfig(enabled: true, 300, -4, -2));
		}

		public MinionEffectsConfig DeepClone()
		{
			MinionEffectsConfig minionEffectsConfig = new MinionEffectsConfig();
			using (Enumerator enumerator = GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					KeyValuePair<MinionEffectType, EffectConfig> current = enumerator.Current;
					minionEffectsConfig[current.Key] = current.Value.DeepClone();
				}
			}
			return minionEffectsConfig;
		}
	}
}
