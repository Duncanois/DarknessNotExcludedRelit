namespace DarknessNotIncluded
{
	public enum LightShape
	{
		Circle,
		SmoothCircle,
		Pill,
		DirectedCone
	}
}
