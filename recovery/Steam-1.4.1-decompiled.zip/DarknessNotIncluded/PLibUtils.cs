using System;
using System.Reflection;
using TMPro;
using UnityEngine;

namespace DarknessNotIncluded
{
	public static class PLibUtils
	{
		public static void SetFieldText(GameObject field, string newText)
		{
			if (!(field == null))
			{
				TMP_InputField componentInChildren = field.GetComponentInChildren<TMP_InputField>();
				if (!(componentInChildren == null))
				{
					componentInChildren.text = newText;
				}
			}
		}

		public static Assembly ActiveAssembly()
		{
			return Global.Instance?.gameObject?.GetComponent("PRegistryComponent")?.GetType()?.Assembly ?? Assembly.GetExecutingAssembly();
		}

		public static string ActiveVersion()
		{
			Type type = ActiveAssembly().GetType("PeterHan.PLib.PVersion");
			return type.GetField("VERSION").GetValue(null) as string;
		}
	}
}
