using System;
using System.Collections.Generic;
using PeterHan.PLib.Options;
using PeterHan.PLib.UI;
using UnityEngine;

namespace DarknessNotIncluded
{
	public class MinionEffectsConfigEntry : OptionsEntry
	{
		private static Dictionary<MinionEffectType, string> LABELS = new Dictionary<MinionEffectType, string>
		{
			{
				MinionEffectType.Dim,
				"Dim"
			},
			{
				MinionEffectType.Dark,
				"Dark"
			}
		};

		private static Dictionary<MinionEffectType, string> TOOLTIPS = new Dictionary<MinionEffectType, string>
		{
			{
				MinionEffectType.Dim,
				"How should dupes be effected by dim light?"
			},
			{
				MinionEffectType.Dark,
				"How should dupes be effected by darkness?"
			}
		};

		private Dictionary<MinionEffectType, GameObject> enabledComponents;

		private Dictionary<MinionEffectType, GameObject> luxThresholdComponents;

		private Dictionary<MinionEffectType, GameObject> agilityModifierComponents;

		private Dictionary<MinionEffectType, GameObject> statsModifierComponents;

		private MinionEffectsConfig value;

		public override object Value
		{
			get
			{
				return value;
			}
			set
			{
				if (value is MinionEffectsConfig minionEffectsConfig)
				{
					this.value = minionEffectsConfig.DeepClone();
					UpdateComponents();
					return;
				}
				throw new ArgumentException("Expected a MinionEffectsConfig");
			}
		}

		public MinionEffectsConfigEntry(string field, IOptionSpec spec)
			: base(field, spec)
		{
		}

		public override void CreateUIEntry(PGridPanel parent, ref int parentRow)
		{
			PGridPanel pGridPanel = new PGridPanel("MinionLightingConfig")
			{
				FlexSize = Vector2.right
			};
			enabledComponents = new Dictionary<MinionEffectType, GameObject>();
			luxThresholdComponents = new Dictionary<MinionEffectType, GameObject>();
			agilityModifierComponents = new Dictionary<MinionEffectType, GameObject>();
			statsModifierComponents = new Dictionary<MinionEffectType, GameObject>();
			pGridPanel.AddColumn(new GridColumnSpec());
			pGridPanel.AddColumn(new GridColumnSpec(0f, 1f));
			pGridPanel.AddColumn(new GridColumnSpec());
			pGridPanel.AddColumn(new GridColumnSpec());
			pGridPanel.AddColumn(new GridColumnSpec());
			pGridPanel.AddRow(new GridRowSpec(0f, 1f));
			pGridPanel.AddChild(new PLabel
			{
				Text = "lux",
				TextStyle = PUITuning.Fonts.TextLightStyle
			}, new GridComponentSpec(0, 2));
			pGridPanel.AddChild(new PLabel
			{
				Text = "agility",
				TextStyle = PUITuning.Fonts.TextLightStyle
			}, new GridComponentSpec(0, 3));
			pGridPanel.AddChild(new PLabel
			{
				Text = "stats",
				TextStyle = PUITuning.Fonts.TextLightStyle
			}, new GridComponentSpec(0, 4));
			int num = 1;
			foreach (MinionEffectType type in Enum.GetValues(typeof(MinionEffectType)))
			{
				string name = Enum.GetName(typeof(MinionEffectType), type);
				pGridPanel.AddRow(new GridRowSpec(0f, 1f));
				PCheckBox pCheckBox = new PCheckBox(name + ".enabled")
				{
					OnChecked = (GameObject o, int state) =>
					{
						value[type].enabled = state != 1;
						UpdateComponents();
					}
				};
				pCheckBox.SetKleiBlueStyle();
				pCheckBox.AddOnRealize((GameObject o) =>
				{
					enabledComponents.Add(type, o);
				});
				pGridPanel.AddChild(pCheckBox, new GridComponentSpec(num, 0)
				{
					Margin = OptionsEntry.LABEL_MARGIN
				});
				PLabel child = new PLabel(name + ".label")
				{
					Text = (LABELS.ContainsKey(type) ? LABELS[type] : $"{type}"),
					ToolTip = (TOOLTIPS.ContainsKey(type) ? TOOLTIPS[type] : ""),
					TextStyle = PUITuning.Fonts.TextLightStyle
				};
				pGridPanel.AddChild(child, new GridComponentSpec(num, 1)
				{
					Margin = OptionsEntry.LABEL_MARGIN,
					Alignment = TextAnchor.MiddleLeft
				});
				PTextField pTextField = new PTextField(name + ".luxThreshold")
				{
					Type = PTextField.FieldType.Integer,
					MinWidth = 48,
					OnTextChanged = (GameObject o, string text) =>
					{
						if (int.TryParse(text, out var result))
						{
							value[type].luxThreshold = result;
							UpdateComponents();
						}
					}
				};
				pTextField.AddOnRealize((GameObject o) =>
				{
					luxThresholdComponents.Add(type, o);
				});
				pGridPanel.AddChild(pTextField, new GridComponentSpec(num, 2)
				{
					Margin = OptionsEntry.LABEL_MARGIN
				});
				PTextField pTextField2 = new PTextField(name + ".agilityModifier")
				{
					Type = PTextField.FieldType.Integer,
					MinWidth = 48,
					OnTextChanged = (GameObject o, string text) =>
					{
						if (int.TryParse(text, out var result))
						{
							value[type].agilityModifier = result;
							UpdateComponents();
						}
					}
				};
				pTextField2.AddOnRealize((GameObject o) =>
				{
					agilityModifierComponents.Add(type, o);
				});
				pGridPanel.AddChild(pTextField2, new GridComponentSpec(num, 3)
				{
					Margin = OptionsEntry.LABEL_MARGIN
				});
				PTextField pTextField3 = new PTextField(name + ".statsModifier")
				{
					Type = PTextField.FieldType.Integer,
					MinWidth = 48,
					OnTextChanged = (GameObject o, string text) =>
					{
						if (int.TryParse(text, out var result))
						{
							value[type].statsModifier = result;
							UpdateComponents();
						}
					}
				};
				pTextField3.AddOnRealize((GameObject o) =>
				{
					statsModifierComponents.Add(type, o);
				});
				pGridPanel.AddChild(pTextField3, new GridComponentSpec(num, 4)
				{
					Margin = OptionsEntry.LABEL_MARGIN
				});
				num++;
			}
			parent.AddChild(pGridPanel, new GridComponentSpec(parentRow, 0)
			{
				ColumnSpan = 2
			});
			UpdateComponents();
		}

		private void UpdateComponents()
		{
			if (value == null)
			{
				return;
			}
			foreach (KeyValuePair<MinionEffectType, MinionEffectsConfig.EffectConfig> item in value)
			{
				if (enabledComponents.ContainsKey(item.Key))
				{
					PCheckBox.SetCheckState(enabledComponents[item.Key], item.Value.enabled ? 1 : 0);
					PLibUtils.SetFieldText(luxThresholdComponents[item.Key], item.Value.luxThreshold.ToString());
					PLibUtils.SetFieldText(agilityModifierComponents[item.Key], item.Value.agilityModifier.ToString());
					PLibUtils.SetFieldText(statsModifierComponents[item.Key], item.Value.statsModifier.ToString());
				}
			}
		}

		public override GameObject GetUIComponent()
		{
			throw new NotImplementedException();
		}
	}
}
