using System;
using System.Collections.Generic;
using UnityEngine;

namespace DarknessNotIncluded
{
	public static class VisibilityUtils
	{
		public static IEnumerable<int> CellsOnLine(int x0, int y0, int x1, int y1)
		{
			int dx = Math.Abs(x1 - x0);
			int dy = -Math.Abs(y1 - y0);
			int sx = ((x0 < x1) ? 1 : (-1));
			int sy = ((y0 < y1) ? 1 : (-1));
			int err = dx + dy;
			int x2 = x0;
			int y2 = y0;
			while (true)
			{
				yield return Grid.XYToCell(x2, y2);
				if (x2 == x1 && y2 == y1)
				{
					break;
				}
				int e2 = 2 * err;
				if (e2 >= dy)
				{
					err += dy;
					x2 += sx;
				}
				if (e2 <= dx)
				{
					err += dx;
					y2 += sy;
				}
			}
		}

		public static bool IsBlockingCell(int cell)
		{
			if (!Grid.IsValidCell(cell))
			{
				return false;
			}
			try
			{
				Config instance = Config.instance;
				if (instance != null && !instance.occludeVisibilityByWalls)
				{
					return false;
				}
			}
			catch
			{
			}
			if (Grid.Solid[cell])
			{
				return true;
			}
			GameObject gameObject = Grid.Objects[cell, 1];
			if (gameObject != null)
			{
				return true;
			}
			return false;
		}

		public static void RevealWithLineOfSight(int origin, int radius)
		{
			try
			{
				if (!Grid.IsValidCell(origin))
				{
					return;
				}
				Vector2I vector2I = Grid.CellToXY(origin);
				int x = vector2I.x;
				int y = vector2I.y;
				int num = Math.Max(1, radius);
				int num2 = Math.Max(0, x - num);
				int num3 = Math.Min(Grid.WidthInCells - 1, x + num);
				int num4 = Math.Max(0, y - num);
				int num5 = Math.Min(Grid.HeightInCells - 1, y + num);
				Grid.Reveal(origin);
				RevealIfValid(Grid.CellAbove(origin));
				RevealIfValid(Grid.CellRight(origin));
				RevealIfValid(Grid.CellBelow(origin));
				RevealIfValid(Grid.CellLeft(origin));
				for (int i = num4; i <= num5; i++)
				{
					for (int j = num2; j <= num3; j++)
					{
						int num6 = Grid.XYToCell(j, i);
						if (!Grid.IsValidCell(num6) || num6 == origin || Math.Abs(j - x) + Math.Abs(i - y) == 1 || (j - x) * (j - x) + (i - y) * (i - y) > num * num)
						{
							continue;
						}
						bool flag = false;
						foreach (int item in CellsOnLine(x, y, j, i))
						{
							if (item != origin)
							{
								if (item == num6)
								{
									break;
								}
								if (IsBlockingCell(item))
								{
									flag = true;
									break;
								}
							}
						}
						try
						{
							if (flag)
							{
								if (Grid.LightIntensity[num6] > 0 || Grid.Visible[num6] > 0 || Grid.ExposedToSunlight[num6] > 0)
								{
									Grid.Reveal(num6);
								}
							}
							else
							{
								Grid.Reveal(num6);
							}
						}
						catch (Exception arg)
						{
							Debug.LogWarning($"[DarknessNotIncluded] RevealWithLineOfSight Grid.Reveal failed for cell {num6}: {arg}");
						}
					}
				}
			}
			catch (Exception arg2)
			{
				Debug.LogWarning($"[DarknessNotIncluded] RevealWithLineOfSight threw: {arg2}");
			}
			void RevealIfValid(int c)
			{
				try
				{
					if (Grid.IsValidCell(c))
					{
						Grid.Reveal(c);
					}
				}
				catch
				{
				}
			}
		}

		public static void RevealArea(int originCell, int radius, float innerRadius)
		{
			try
			{
				if (!Grid.IsValidCell(originCell))
				{
					return;
				}
				bool flag = false;
				try
				{
					flag = Config.instance != null && Config.instance.occludeVisibilityByWalls;
				}
				catch
				{
				}
				if (flag)
				{
					RevealWithLineOfSight(originCell, radius);
					return;
				}
				Vector2I vector2I = Grid.CellToXY(originCell);
				try
				{
					GridVisibility.Reveal(vector2I.x, vector2I.y, radius, innerRadius);
				}
				catch (Exception arg)
				{
					Debug.LogWarning($"[DarknessNotIncluded] GridVisibility.Reveal threw for originCell {originCell}: {arg}");
				}
			}
			catch (Exception arg2)
			{
				Debug.LogWarning($"[DarknessNotIncluded] RevealArea threw for originCell {originCell}: {arg2}");
			}
		}
	}
}
