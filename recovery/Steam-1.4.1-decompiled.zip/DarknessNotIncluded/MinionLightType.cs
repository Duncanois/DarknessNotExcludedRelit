namespace DarknessNotIncluded
{
	public enum MinionLightType
	{
		None,
		Intrinsic,
		Mining1,
		Mining2,
		Mining3,
		Mining4,
		Science,
		Rocketry,
		AtmoSuit,
		JetSuit,
		LeadSuit,
		Rover,
		Bionic
	}
}
