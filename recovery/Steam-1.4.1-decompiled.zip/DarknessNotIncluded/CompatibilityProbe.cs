using System;
using System.Reflection;
using HarmonyLib;

namespace DarknessNotIncluded
{
	internal static class CompatibilityProbe
	{
		public static void Run()
		{
			try
			{
				ProbeType("Game");
				ProbeMethod(typeof(Game), "OnPrefabInit");
				ProbeType("RationalAi");
				ProbeMethod(typeof(RationalAi), "InitializeStates");
				ProbeType("ModifierSet");
				ProbeMethod(typeof(ModifierSet), "Initialize");
				ProbeType("SleepChore+States");
				Type nestedType = typeof(SleepChore).GetNestedType("States", BindingFlags.Public | BindingFlags.NonPublic);
				if (nestedType != null)
				{
					ProbeMethod(nestedType, "InitializeStates");
				}
				else
				{
					Log.Warn("SleepChore.States type missing");
				}
				Type nestedType2 = typeof(SleepChore).GetNestedType("StatesInstance", BindingFlags.Public | BindingFlags.NonPublic);
				if (nestedType2 != null)
				{
					ProbeMethod(nestedType2, "CheckLightLevel");
				}
				else
				{
					Log.Warn("SleepChore.StatesInstance type missing");
				}
				ProbeType("World");
				ProbeMethod(typeof(World), "OnSpawn");
				Type type = AccessTools.TypeByName("PeterHan.PLib.Options.OptionsDialog");
				if (type == null)
				{
					Log.Warn("OptionsDialog type not found; presets injection may fail");
					return;
				}
				Log.Info("OptionsDialog type OK: {0}", type.FullName);
			}
			catch (Exception ex)
			{
				Log.Error("Compatibility probe failed", ex);
			}
		}

		private static void ProbeType(string typeName)
		{
			Type type = AccessTools.TypeByName(typeName);
			if (type == null)
			{
				Log.Warn("Type missing: {0}", typeName);
			}
			else
			{
				Log.Info("Type present: {0}", typeName);
			}
		}

		private static void ProbeMethod(Type type, string methodName)
		{
			if (!(type == null))
			{
				MethodInfo methodInfo = AccessTools.Method(type, methodName);
				if (methodInfo == null)
				{
					Log.Warn("Method missing: {0}.{1}", type.Name, methodName);
				}
				else
				{
					Log.Info("Method present: {0}.{1}()", type.Name, methodName);
				}
			}
		}
	}
}
