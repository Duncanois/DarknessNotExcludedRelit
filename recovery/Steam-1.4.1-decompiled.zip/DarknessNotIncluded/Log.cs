using System;

namespace DarknessNotIncluded
{
	internal static class Log
	{
		private static string LINE_FORMAT = $"[Darkness Not Excluded v{Mod.Version.Major}.{Mod.Version.Minor}.{Mod.Version.Build}] {{0}}";

		public static void Info(string message, params object[] details)
		{
			Debug.Log(Format(message, details));
		}

		public static void Warn(string message, params object[] details)
		{
			Debug.LogWarning(Format(message, details));
		}

		public static void Error(string message, params object[] details)
		{
			Debug.LogError(Format(message, details));
		}

		public static void Assert(string message, bool condition)
		{
			if (condition)
			{
				return;
			}
			Debug.LogError(Format("Assertion failed: {{0}}", message));
			throw new Exception("Assertion failed: " + message);
		}

		private static string Format(string message, params object[] details)
		{
			string text = message;
			foreach (object arg in details)
			{
				text += $" {arg}";
			}
			return string.Format(LINE_FORMAT, text);
		}
	}
}
