using System.Collections.Generic;

namespace DarknessNotIncluded
{
	public static class GridUtils
	{
		public static List<int> GetOrthogonallyAdjacentCells(int cell)
		{
			List<int> list = new List<int>();
			if (Grid.IsValidCell(Grid.CellAbove(cell)))
			{
				list.Add(Grid.CellAbove(cell));
			}
			if (Grid.IsValidCell(Grid.CellRight(cell)))
			{
				list.Add(Grid.CellRight(cell));
			}
			if (Grid.IsValidCell(Grid.CellBelow(cell)))
			{
				list.Add(Grid.CellBelow(cell));
			}
			if (Grid.IsValidCell(Grid.CellLeft(cell)))
			{
				list.Add(Grid.CellLeft(cell));
			}
			return list;
		}
	}
}
