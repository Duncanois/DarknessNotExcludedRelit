namespace DarknessNotIncluded
{
	public class UnitOrientation : KMonoBehaviour, ISim33ms
	{
		public enum Orientation
		{
			Unknown,
			Left,
			UpLeft,
			Up,
			UpRight,
			Right,
			DownRight,
			Down,
			DownLeft
		}

		[MyCmpGet]
		private Navigator navigator;

		public Orientation orientation = Orientation.Unknown;

		public void Sim33ms(float dt)
		{
			Orientation currentOrientation = GetCurrentOrientation();
			if (currentOrientation != Orientation.Unknown)
			{
				orientation = currentOrientation;
			}
		}

		private Orientation GetCurrentOrientation()
		{
			if (navigator == null || !navigator.IsMoving() || !navigator.path.IsValid())
			{
				float x = gameObject.transform.localScale.x;
				return (x < 0f) ? Orientation.Left : Orientation.Right;
			}
			int cell = Grid.PosToCell(gameObject);
			if (navigator.path.nodes == null || navigator.path.nodes.Count < 2)
			{
				return Orientation.Unknown;
			}
			int cell2 = navigator.path.nodes[1].cell;
			int num = Grid.CellRow(cell2) - Grid.CellRow(cell);
			int num2 = Grid.CellColumn(cell2) - Grid.CellColumn(cell);
			if (num2 < 0 && num == 0)
			{
				return Orientation.Left;
			}
			if (num2 < 0 && num > 0)
			{
				return Orientation.UpLeft;
			}
			if (num2 == 0 && num > 0)
			{
				return Orientation.Up;
			}
			if (num2 > 0 && num > 0)
			{
				return Orientation.UpRight;
			}
			if (num2 > 0 && num == 0)
			{
				return Orientation.Right;
			}
			if (num2 > 0 && num < 0)
			{
				return Orientation.DownRight;
			}
			if (num2 == 0 && num < 0)
			{
				return Orientation.Down;
			}
			if (num2 < 0 && num < 0)
			{
				return Orientation.DownLeft;
			}
			return Orientation.Unknown;
		}
	}
}
