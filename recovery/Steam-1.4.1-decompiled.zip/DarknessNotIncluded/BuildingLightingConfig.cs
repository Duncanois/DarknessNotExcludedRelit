using System.Collections.Generic;
using TUNING;

namespace DarknessNotIncluded
{
	public class BuildingLightingConfig : Dictionary<BuildingType, LightConfig>
	{
		public BuildingLightingConfig()
		{
			Add(BuildingType.PrintingPod, new LightConfig(enabled: true, 2000, 5, 0, LightShape.Circle, LIGHT2D.LIGHT_YELLOW));
			Add(BuildingType.MicrobeMusher, new LightConfig(enabled: true, 1000, 1, 0, LightShape.Circle, LIGHT2D.LIGHT_YELLOW));
			Add(BuildingType.HydrogenGenerator, new LightConfig(enabled: true, 1000, 1, 0, LightShape.Circle, LIGHT2D.LIGHT_YELLOW));
		}

		public BuildingLightingConfig DeepClone()
		{
			BuildingLightingConfig buildingLightingConfig = new BuildingLightingConfig();
			using (Enumerator enumerator = GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					KeyValuePair<BuildingType, LightConfig> current = enumerator.Current;
					buildingLightingConfig[current.Key] = current.Value.DeepClone();
				}
			}
			return buildingLightingConfig;
		}

		public LightConfig Get(BuildingType lightType)
		{
			return ContainsKey(lightType) ? base[lightType] : LightConfig.None;
		}
	}
}
