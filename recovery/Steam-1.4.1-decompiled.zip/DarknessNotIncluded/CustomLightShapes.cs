using System;
using System.Collections.Generic;
using PeterHan.PLib.Lighting;

namespace DarknessNotIncluded
{
	public static class CustomLightShapes
	{
		public static bool Enabled = true;

		public static ILightShape SmoothCircle;

		public static ILightShape Pill;

		public static ILightShape DirectedCone;

		public static void Initialize()
		{
			Enabled = true;
			PLightManager pLightManager = new PLightManager();
			SmoothCircle = pLightManager.Register("nevir.DarknessNotExcluded.SmoothCircle", SmoothCircleCaster);
			Pill = pLightManager.Register("nevir.DarknessNotExcluded.Pill", PillCaster);
			DirectedCone = pLightManager.Register("nevir.DarknessNotExcluded.DirectedCone", DirectedConeCaster);
		}

		public static void SmoothCircleCaster(LightingArgs args)
		{
			int sourceCell = args.SourceCell;
			int range = Math.Max(0, args.Range - 1);
			IDictionary<int, float> brightness = args.Brightness;
			CastSmoothCircle(brightness, range, sourceCell);
		}

		public static void PillCaster(LightingArgs args)
		{
			int sourceCell = args.SourceCell;
			int range = Math.Max(0, args.Range - 1);
			IDictionary<int, float> brightness = args.Brightness;
			CastSmoothCircle(brightness, range, sourceCell);
			CastSmoothCircle(brightness, range, Grid.CellAbove(sourceCell));
		}

		public static void DirectedConeCaster(LightingArgs args)
		{
			UnitOrientation unitOrientation = args.Source.AddOrGet<UnitOrientation>();
			int sourceCell = args.SourceCell;
			int range = Math.Max(0, args.Range - 1);
			IDictionary<int, float> brightness = args.Brightness;
			PillCaster(args);
			MultiplyBrightness(brightness, 0.35f);
			brightness[sourceCell] = 1f;
			OctantBuilder octantBuilder = new OctantBuilder(brightness, Grid.CellAbove(sourceCell))
			{
				Falloff = 0.5f,
				SmoothLight = true
			};
			switch (unitOrientation.orientation)
			{
			case UnitOrientation.Orientation.Left:
				octantBuilder.AddOctant(range, DiscreteShadowCaster.Octant.W_SW);
				octantBuilder.AddOctant(range, DiscreteShadowCaster.Octant.W_NW);
				break;
			case UnitOrientation.Orientation.UpLeft:
				octantBuilder.AddOctant(range, DiscreteShadowCaster.Octant.W_NW);
				octantBuilder.AddOctant(range, DiscreteShadowCaster.Octant.N_NW);
				break;
			case UnitOrientation.Orientation.Up:
				octantBuilder.AddOctant(range, DiscreteShadowCaster.Octant.N_NW);
				octantBuilder.AddOctant(range, DiscreteShadowCaster.Octant.N_NE);
				break;
			case UnitOrientation.Orientation.UpRight:
				octantBuilder.AddOctant(range, DiscreteShadowCaster.Octant.N_NE);
				octantBuilder.AddOctant(range, DiscreteShadowCaster.Octant.E_NE);
				break;
			case UnitOrientation.Orientation.Right:
				octantBuilder.AddOctant(range, DiscreteShadowCaster.Octant.E_NE);
				octantBuilder.AddOctant(range, DiscreteShadowCaster.Octant.E_SE);
				break;
			case UnitOrientation.Orientation.DownRight:
				octantBuilder.AddOctant(range, DiscreteShadowCaster.Octant.E_SE);
				octantBuilder.AddOctant(range, DiscreteShadowCaster.Octant.S_SE);
				break;
			default:
				octantBuilder.AddOctant(range, DiscreteShadowCaster.Octant.S_SE);
				octantBuilder.AddOctant(range, DiscreteShadowCaster.Octant.S_SW);
				break;
			case UnitOrientation.Orientation.DownLeft:
				octantBuilder.AddOctant(range, DiscreteShadowCaster.Octant.S_SW);
				octantBuilder.AddOctant(range, DiscreteShadowCaster.Octant.W_SW);
				break;
			}
		}

		private static void CastSmoothCircle(IDictionary<int, float> brightness, int range, int sourceCell)
		{
			if (Grid.IsValidCell(sourceCell))
			{
				OctantBuilder octantBuilder = new OctantBuilder(brightness, sourceCell)
				{
					Falloff = 0.5f,
					SmoothLight = true
				};
				octantBuilder.AddOctant(range, DiscreteShadowCaster.Octant.E_NE);
				octantBuilder.AddOctant(range, DiscreteShadowCaster.Octant.E_SE);
				octantBuilder.AddOctant(range, DiscreteShadowCaster.Octant.N_NE);
				octantBuilder.AddOctant(range, DiscreteShadowCaster.Octant.N_NW);
				octantBuilder.AddOctant(range, DiscreteShadowCaster.Octant.S_SE);
				octantBuilder.AddOctant(range, DiscreteShadowCaster.Octant.S_SW);
				octantBuilder.AddOctant(range, DiscreteShadowCaster.Octant.W_NW);
				octantBuilder.AddOctant(range, DiscreteShadowCaster.Octant.W_SW);
			}
		}

		private static void MultiplyBrightness(IDictionary<int, float> brightness, float factor)
		{
			foreach (int item in new List<int>(brightness.Keys))
			{
				brightness[item] *= factor;
			}
		}
	}
}
