using Newtonsoft.Json;
using UnityEngine;

namespace DarknessNotIncluded
{
	public class LightConfig
	{
		public static LightConfig None = new LightConfig(enabled: false, 0, 0, 0, LightShape.SmoothCircle, new Color(0f, 0f, 0f, 0f));

		public bool enabled { get; set; }

		public int lux { get; set; }

		public int range { get; set; }

		public int reveal { get; set; }

		public LightShape shape { get; set; }

		[JsonConverter(typeof(ColorJsonConverter))]
		public Color color { get; set; }

		public LightConfig(bool enabled, int lux, int range, int reveal, LightShape shape, Color color)
		{
			this.enabled = enabled;
			this.lux = lux;
			this.range = range;
			this.reveal = reveal;
			this.shape = shape;
			this.color = color;
		}

		public void ConfigureLight(Light2D light)
		{
			if (light == null)
			{
				Log.Warn("LightConfig.ConfigureLight() called with a null light");
				return;
			}
			light.enabled = enabled;
			light.shape = shape.LightShape();
			light.Lux = lux;
			light.Range = range;
			light.Color = color;
			light.FullRefresh();
		}

		public LightConfig DeepClone()
		{
			return new LightConfig(enabled, lux, range, reveal, shape, color);
		}
	}
}
