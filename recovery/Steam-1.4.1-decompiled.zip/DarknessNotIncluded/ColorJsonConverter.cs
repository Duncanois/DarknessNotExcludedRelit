using System;
using Newtonsoft.Json;
using UnityEngine;

namespace DarknessNotIncluded
{
	public class ColorJsonConverter : JsonConverter
	{
		public override bool CanConvert(Type objectType)
		{
			return objectType == typeof(Color);
		}

		public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
		{
			object value = reader.Value;
			if (value is string colorString && ColorSerializer.FromString(colorString, out var outColor))
			{
				return outColor;
			}
			throw new JsonException($"received invalid JSON when parsing Color: {value} ({value.GetType()})");
		}

		public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
		{
			if (value is Color color)
			{
				writer.WriteValue(ColorSerializer.ToString(color));
				return;
			}
			throw new JsonException($"expected to receive an instance of Color; instead got: {value}");
		}
	}
}
