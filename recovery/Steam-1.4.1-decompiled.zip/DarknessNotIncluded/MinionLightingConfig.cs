using System.Collections.Generic;
using TUNING;
using UnityEngine;

namespace DarknessNotIncluded
{
	public class MinionLightingConfig : Dictionary<MinionLightType, LightConfig>
	{
		public MinionLightingConfig()
		{
			Add(MinionLightType.Intrinsic, new LightConfig(enabled: true, 200, 2, 0, LightShape.Pill, Color.white));
			Add(MinionLightType.Mining1, new LightConfig(enabled: true, 800, 3, 6, LightShape.DirectedCone, LIGHT2D.LIGHT_YELLOW));
			Add(MinionLightType.Mining2, new LightConfig(enabled: true, 1000, 4, 7, LightShape.DirectedCone, LIGHT2D.LIGHT_YELLOW));
			Add(MinionLightType.Mining3, new LightConfig(enabled: true, 1200, 5, 8, LightShape.DirectedCone, Color.white));
			Add(MinionLightType.Mining4, new LightConfig(enabled: true, 1400, 6, 9, LightShape.DirectedCone, Color.white));
			Add(MinionLightType.Science, new LightConfig(enabled: true, 800, 3, 0, LightShape.Pill, Color.white));
			Add(MinionLightType.Rocketry, new LightConfig(enabled: true, 800, 4, 0, LightShape.DirectedCone, Color.white));
			Add(MinionLightType.AtmoSuit, new LightConfig(enabled: true, 600, 3, 0, LightShape.Pill, LIGHT2D.LIGHT_YELLOW));
			Add(MinionLightType.JetSuit, new LightConfig(enabled: true, 800, 5, 0, LightShape.Pill, LIGHT2D.LIGHT_YELLOW));
			Add(MinionLightType.LeadSuit, new LightConfig(enabled: true, 400, 3, 0, LightShape.Pill, LIGHT2D.LIGHT_YELLOW));
			Add(MinionLightType.Rover, new LightConfig(enabled: true, 1400, 6, 9, LightShape.DirectedCone, Color.white));
			Add(MinionLightType.Bionic, new LightConfig(enabled: true, 400, 4, 0, LightShape.Pill, Color.cyan));
		}

		public MinionLightingConfig DeepClone()
		{
			MinionLightingConfig minionLightingConfig = new MinionLightingConfig();
			using (Enumerator enumerator = GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					KeyValuePair<MinionLightType, LightConfig> current = enumerator.Current;
					minionLightingConfig[current.Key] = current.Value.DeepClone();
				}
			}
			return minionLightingConfig;
		}

		public LightConfig Get(MinionLightType lightType)
		{
			return ContainsKey(lightType) ? base[lightType] : LightConfig.None;
		}
	}
}
