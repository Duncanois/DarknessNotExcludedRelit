namespace DarknessNotIncluded
{
	public static class MinionExtensions
	{
		public static bool IsSleeping(this MinionIdentity minionIdentity)
		{
			if (minionIdentity == null)
			{
				return false;
			}
			if (minionIdentity.gameObject == null)
			{
				return false;
			}
			return minionIdentity.GetSMI<StaminaMonitor.Instance>()?.IsSleeping() ?? false;
		}
	}
}
