namespace DarknessNotIncluded
{
	public enum MinionEffectType
	{
		Dim,
		Dark
	}
}
