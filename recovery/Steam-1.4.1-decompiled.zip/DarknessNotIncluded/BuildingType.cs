namespace DarknessNotIncluded
{
	public enum BuildingType
	{
		None,
		PrintingPod,
		MicrobeMusher,
		HydrogenGenerator
	}
}
