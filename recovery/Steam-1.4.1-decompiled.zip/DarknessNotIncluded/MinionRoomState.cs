using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;

namespace DarknessNotIncluded
{
	public static class MinionRoomState
	{
		[HarmonyPatch(typeof(MinionConfig))]
		[HarmonyPatch("CreatePrefab")]
		private static class Patched_MinionConfig_CreatePrefab
		{
			private static void Postfix(GameObject __result)
			{
				__result.AddOrGet<Observer>();
			}
		}

		public class Observer : KMonoBehaviour, ISim33ms
		{
			[MyCmpGet]
			private MinionIdentity _minionIdentity;

			private int currentCavityIndex = -1;

			public void Sim33ms(float dt)
			{
				int cell = Grid.PosToCell(_minionIdentity);
				CavityInfo cavityForCell = Game.Instance.roomProber.GetCavityForCell(cell);
				int num = ((cavityForCell == null || cavityForCell.room == null) ? (-1) : cavityForCell.handle.index);
				if (num == currentCavityIndex)
				{
					return;
				}
				if (byCavityIndex.ContainsKey(currentCavityIndex))
				{
					byCavityIndex[currentCavityIndex].Remove(_minionIdentity);
					if (byCavityIndex[currentCavityIndex].Count == 0)
					{
						byCavityIndex.Remove(currentCavityIndex);
					}
				}
				if (num != -1)
				{
					if (!byCavityIndex.ContainsKey(num))
					{
						byCavityIndex.Add(num, new HashSet<MinionIdentity>());
					}
					byCavityIndex[num].Add(_minionIdentity);
				}
			}
		}

		public static HashSet<MinionIdentity> EMPTY_HASH_SET = new HashSet<MinionIdentity>();

		public static Dictionary<int, HashSet<MinionIdentity>> byCavityIndex = new Dictionary<int, HashSet<MinionIdentity>>();

		public static bool SleepersInSameRoom(GameObject gameObject)
		{
			int cell = Grid.PosToCell(gameObject);
			CavityInfo cavityForCell = Game.Instance.roomProber.GetCavityForCell(cell);
			if (cavityForCell == null || cavityForCell.cells == null || cavityForCell.cells.Count > 120)
			{
				return false;
			}
			foreach (MinionIdentity item in MinionsInRoom(cavityForCell))
			{
				if (item.IsSleeping())
				{
					return true;
				}
			}
			return false;
		}

		public static HashSet<MinionIdentity> MinionsInRoom(CavityInfo cavity)
		{
			if (cavity != null && byCavityIndex.ContainsKey(cavity.handle.index))
			{
				return byCavityIndex[cavity.handle.index];
			}
			return EMPTY_HASH_SET;
		}
	}
}
