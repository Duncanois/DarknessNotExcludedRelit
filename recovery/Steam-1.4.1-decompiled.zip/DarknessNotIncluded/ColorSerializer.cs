using System.Globalization;
using UnityEngine;

namespace DarknessNotIncluded
{
	public static class ColorSerializer
	{
		public static bool FromString(string colorString, out Color outColor)
		{
			bool flag = true;
			if (colorString.Length == 8)
			{
				flag |= int.TryParse(colorString.Substring(0, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out var result);
				flag |= int.TryParse(colorString.Substring(2, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out var result2);
				flag |= int.TryParse(colorString.Substring(4, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out var result3);
				if (flag | int.TryParse(colorString.Substring(6, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out var result4))
				{
					outColor = new Color(result, result2, result3, result4);
					return true;
				}
			}
			outColor = Color.clear;
			return false;
		}

		public static string ToString(Color color)
		{
			string text = "";
			text += ((int)color.r).ToString("X2");
			text += ((int)color.g).ToString("X2");
			text += ((int)color.b).ToString("X2");
			return text + ((int)color.a).ToString("X2");
		}
	}
}
