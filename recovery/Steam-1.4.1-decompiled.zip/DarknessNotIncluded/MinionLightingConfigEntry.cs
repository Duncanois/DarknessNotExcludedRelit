using System;
using System.Collections.Generic;
using PeterHan.PLib.Options;
using PeterHan.PLib.UI;
using STRINGS;
using UnityEngine;

namespace DarknessNotIncluded
{
	public class MinionLightingConfigEntry : OptionsEntry
	{
		private static Dictionary<MinionLightType, string> LABELS = new Dictionary<MinionLightType, string>
		{
			{
				MinionLightType.Intrinsic,
				"Base Glow"
			},
			{
				MinionLightType.Mining1,
				DUPLICANTS.ROLES.JUNIOR_MINER.NAME
			},
			{
				MinionLightType.Mining2,
				DUPLICANTS.ROLES.MINER.NAME
			},
			{
				MinionLightType.Mining3,
				DUPLICANTS.ROLES.SENIOR_MINER.NAME
			},
			{
				MinionLightType.Mining4,
				DUPLICANTS.ROLES.MASTER_MINER.NAME
			},
			{
				MinionLightType.Science,
				"Science"
			},
			{
				MinionLightType.Rocketry,
				"Rocketry"
			},
			{
				MinionLightType.AtmoSuit,
				"Atmo Suit"
			},
			{
				MinionLightType.JetSuit,
				"Jet Suit"
			},
			{
				MinionLightType.LeadSuit,
				"Lead Suit"
			},
			{
				MinionLightType.Rover,
				"Rover"
			},
			{
				MinionLightType.Bionic,
				"Bionic Base Glow"
			}
		};

		private static Dictionary<MinionLightType, string> TOOLTIPS = new Dictionary<MinionLightType, string>
		{
			{
				MinionLightType.Intrinsic,
				"Light that is emitted around Duplicants, when no other light sources are present."
			},
			{
				MinionLightType.Mining1,
				$"Light emitted by Duplicants wearing a {DUPLICANTS.ROLES.JUNIOR_MINER.NAME} mining hat."
			},
			{
				MinionLightType.Mining2,
				$"Light emitted by Duplicants wearing a {DUPLICANTS.ROLES.MINER.NAME} mining hat."
			},
			{
				MinionLightType.Mining3,
				$"Light emitted by Duplicants wearing a {DUPLICANTS.ROLES.SENIOR_MINER.NAME} mining hat."
			},
			{
				MinionLightType.Mining4,
				$"Light emitted by Duplicants wearing a {DUPLICANTS.ROLES.MASTER_MINER.NAME} mining hat."
			},
			{
				MinionLightType.Science,
				"Light emitted by Duplicants wearing a science hat."
			},
			{
				MinionLightType.Rocketry,
				"Light emitted by Duplicants wearing a rocketry helmet."
			},
			{
				MinionLightType.AtmoSuit,
				"Light emitted by Duplicants wearing an Atmo Suit"
			},
			{
				MinionLightType.JetSuit,
				"Light emitted by Duplicants wearing a Jet Suit"
			},
			{
				MinionLightType.Bionic,
				"Light emitted by Bionic Duplicants."
			},
			{
				MinionLightType.Rover,
				"Light emitted by Rovers"
			}
		};

		private Dictionary<MinionLightType, GameObject> enabledComponents;

		private Dictionary<MinionLightType, GameObject> luxComponents;

		private Dictionary<MinionLightType, GameObject> rangeComponents;

		private Dictionary<MinionLightType, GameObject> revealComponents;

		private MinionLightingConfig value;

		public override object Value
		{
			get
			{
				return value;
			}
			set
			{
				if (value is MinionLightingConfig minionLightingConfig)
				{
					this.value = minionLightingConfig.DeepClone();
					UpdateComponents();
					return;
				}
				throw new ArgumentException("Expected a MinionLightingConfig");
			}
		}

		public MinionLightingConfigEntry(string field, IOptionSpec spec)
			: base(field, spec)
		{
		}

		public override void CreateUIEntry(PGridPanel parent, ref int parentRow)
		{
			PGridPanel pGridPanel = new PGridPanel("MinionLightingConfig")
			{
				FlexSize = Vector2.right
			};
			enabledComponents = new Dictionary<MinionLightType, GameObject>();
			luxComponents = new Dictionary<MinionLightType, GameObject>();
			rangeComponents = new Dictionary<MinionLightType, GameObject>();
			revealComponents = new Dictionary<MinionLightType, GameObject>();
			pGridPanel.AddColumn(new GridColumnSpec());
			pGridPanel.AddColumn(new GridColumnSpec(0f, 1f));
			pGridPanel.AddColumn(new GridColumnSpec());
			pGridPanel.AddColumn(new GridColumnSpec());
			pGridPanel.AddColumn(new GridColumnSpec());
			pGridPanel.AddRow(new GridRowSpec(0f, 1f));
			pGridPanel.AddChild(new PLabel
			{
				Text = "lux",
				TextStyle = PUITuning.Fonts.TextLightStyle
			}, new GridComponentSpec(0, 2));
			pGridPanel.AddChild(new PLabel
			{
				Text = "range",
				TextStyle = PUITuning.Fonts.TextLightStyle
			}, new GridComponentSpec(0, 3));
			pGridPanel.AddChild(new PLabel
			{
				Text = "reveal",
				TextStyle = PUITuning.Fonts.TextLightStyle
			}, new GridComponentSpec(0, 4));
			int num = 1;
			foreach (MinionLightType type in Enum.GetValues(typeof(MinionLightType)))
			{
				if (type == MinionLightType.None)
				{
					continue;
				}
				string name = Enum.GetName(typeof(MinionLightType), type);
				pGridPanel.AddRow(new GridRowSpec(0f, 1f));
				PCheckBox pCheckBox = new PCheckBox(name + ".enabled")
				{
					OnChecked = (GameObject o, int state) =>
					{
						value[type].enabled = state != 1;
						UpdateComponents();
					}
				};
				pCheckBox.SetKleiBlueStyle();
				pCheckBox.AddOnRealize((GameObject o) =>
				{
					enabledComponents.Add(type, o);
				});
				pGridPanel.AddChild(pCheckBox, new GridComponentSpec(num, 0)
				{
					Margin = OptionsEntry.LABEL_MARGIN
				});
				PLabel child = new PLabel(name + ".label")
				{
					Text = (LABELS.ContainsKey(type) ? LABELS[type] : $"{type}"),
					ToolTip = (TOOLTIPS.ContainsKey(type) ? TOOLTIPS[type] : ""),
					TextStyle = PUITuning.Fonts.TextLightStyle
				};
				pGridPanel.AddChild(child, new GridComponentSpec(num, 1)
				{
					Margin = OptionsEntry.LABEL_MARGIN,
					Alignment = TextAnchor.MiddleLeft
				});
				PTextField pTextField = new PTextField(name + ".lux")
				{
					Type = PTextField.FieldType.Integer,
					MinWidth = 48,
					OnTextChanged = (GameObject o, string text) =>
					{
						if (int.TryParse(text, out var result))
						{
							value[type].lux = result;
							UpdateComponents();
						}
					}
				};
				pTextField.AddOnRealize((GameObject o) =>
				{
					luxComponents.Add(type, o);
				});
				pGridPanel.AddChild(pTextField, new GridComponentSpec(num, 2)
				{
					Margin = OptionsEntry.LABEL_MARGIN
				});
				PTextField pTextField2 = new PTextField(name + ".range")
				{
					Type = PTextField.FieldType.Integer,
					MinWidth = 48,
					OnTextChanged = (GameObject o, string text) =>
					{
						if (int.TryParse(text, out var result))
						{
							value[type].range = result;
							UpdateComponents();
						}
					}
				};
				pTextField2.AddOnRealize((GameObject o) =>
				{
					rangeComponents.Add(type, o);
				});
				pGridPanel.AddChild(pTextField2, new GridComponentSpec(num, 3)
				{
					Margin = OptionsEntry.LABEL_MARGIN
				});
				PTextField pTextField3 = new PTextField(name + ".reveal")
				{
					Type = PTextField.FieldType.Integer,
					MinWidth = 48,
					OnTextChanged = (GameObject o, string text) =>
					{
						if (int.TryParse(text, out var result))
						{
							value[type].reveal = result;
							UpdateComponents();
						}
					}
				};
				pTextField3.AddOnRealize((GameObject o) =>
				{
					revealComponents.Add(type, o);
				});
				pGridPanel.AddChild(pTextField3, new GridComponentSpec(num, 4)
				{
					Margin = OptionsEntry.LABEL_MARGIN
				});
				num++;
			}
			parent.AddChild(pGridPanel, new GridComponentSpec(parentRow, 0)
			{
				ColumnSpan = 2
			});
			UpdateComponents();
		}

		private void UpdateComponents()
		{
			if (value == null)
			{
				return;
			}
			foreach (KeyValuePair<MinionLightType, LightConfig> item in value)
			{
				if (enabledComponents.ContainsKey(item.Key))
				{
					PCheckBox.SetCheckState(enabledComponents[item.Key], item.Value.enabled ? 1 : 0);
					PLibUtils.SetFieldText(luxComponents[item.Key], item.Value.lux.ToString());
					PLibUtils.SetFieldText(rangeComponents[item.Key], item.Value.range.ToString());
					PLibUtils.SetFieldText(revealComponents[item.Key], item.Value.reveal.ToString());
				}
			}
		}

		public override GameObject GetUIComponent()
		{
			throw new NotImplementedException();
		}
	}
}
