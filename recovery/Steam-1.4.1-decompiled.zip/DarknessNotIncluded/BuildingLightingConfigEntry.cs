using System;
using System.Collections.Generic;
using PeterHan.PLib.Options;
using PeterHan.PLib.UI;
using UnityEngine;

namespace DarknessNotIncluded
{
	public class BuildingLightingConfigEntry : OptionsEntry
	{
		private static Dictionary<BuildingType, string> LABELS = new Dictionary<BuildingType, string>
		{
			{
				BuildingType.PrintingPod,
				"Printing Pod"
			},
			{
				BuildingType.MicrobeMusher,
				"Microbe Musher"
			},
			{
				BuildingType.HydrogenGenerator,
				"Hydrogen Generator"
			}
		};

		private static Dictionary<BuildingType, string> TOOLTIPS = new Dictionary<BuildingType, string>
		{
			{
				BuildingType.PrintingPod,
				"Light that is emitted by the Printing Pod."
			},
			{
				BuildingType.MicrobeMusher,
				"Light that is emitted by the Microbe Musher while it is operating."
			},
			{
				BuildingType.HydrogenGenerator,
				"Light that is emitted by the Hydrogen Generator while it is operating."
			}
		};

		private Dictionary<BuildingType, GameObject> enabledComponents;

		private Dictionary<BuildingType, GameObject> luxComponents;

		private Dictionary<BuildingType, GameObject> rangeComponents;

		private Dictionary<BuildingType, GameObject> revealComponents;

		private BuildingLightingConfig value;

		public override object Value
		{
			get
			{
				return value;
			}
			set
			{
				if (value is BuildingLightingConfig buildingLightingConfig)
				{
					this.value = buildingLightingConfig.DeepClone();
					UpdateComponents();
					return;
				}
				throw new ArgumentException("Expected a BuildingLightingConfig");
			}
		}

		public BuildingLightingConfigEntry(string field, IOptionSpec spec)
			: base(field, spec)
		{
		}

		public override void CreateUIEntry(PGridPanel parent, ref int parentRow)
		{
			PGridPanel pGridPanel = new PGridPanel("BuildingLightingConfig")
			{
				FlexSize = Vector2.right
			};
			enabledComponents = new Dictionary<BuildingType, GameObject>();
			luxComponents = new Dictionary<BuildingType, GameObject>();
			rangeComponents = new Dictionary<BuildingType, GameObject>();
			revealComponents = new Dictionary<BuildingType, GameObject>();
			pGridPanel.AddColumn(new GridColumnSpec());
			pGridPanel.AddColumn(new GridColumnSpec(0f, 1f));
			pGridPanel.AddColumn(new GridColumnSpec());
			pGridPanel.AddColumn(new GridColumnSpec());
			pGridPanel.AddColumn(new GridColumnSpec());
			pGridPanel.AddRow(new GridRowSpec(0f, 1f));
			pGridPanel.AddChild(new PLabel
			{
				Text = "lux",
				TextStyle = PUITuning.Fonts.TextLightStyle
			}, new GridComponentSpec(0, 2));
			pGridPanel.AddChild(new PLabel
			{
				Text = "range",
				TextStyle = PUITuning.Fonts.TextLightStyle
			}, new GridComponentSpec(0, 3));
			pGridPanel.AddChild(new PLabel
			{
				Text = "reveal",
				TextStyle = PUITuning.Fonts.TextLightStyle
			}, new GridComponentSpec(0, 4));
			int num = 1;
			foreach (BuildingType type in Enum.GetValues(typeof(BuildingType)))
			{
				if (type == BuildingType.None)
				{
					continue;
				}
				string name = Enum.GetName(typeof(BuildingType), type);
				pGridPanel.AddRow(new GridRowSpec(0f, 1f));
				PCheckBox pCheckBox = new PCheckBox(name + ".enabled")
				{
					OnChecked = (GameObject o, int state) =>
					{
						value[type].enabled = state != 1;
						UpdateComponents();
					}
				};
				pCheckBox.SetKleiBlueStyle();
				pCheckBox.AddOnRealize((GameObject o) =>
				{
					enabledComponents.Add(type, o);
				});
				pGridPanel.AddChild(pCheckBox, new GridComponentSpec(num, 0)
				{
					Margin = OptionsEntry.LABEL_MARGIN
				});
				PLabel child = new PLabel(name + ".label")
				{
					Text = (LABELS.ContainsKey(type) ? LABELS[type] : $"{type}"),
					ToolTip = (TOOLTIPS.ContainsKey(type) ? TOOLTIPS[type] : ""),
					TextStyle = PUITuning.Fonts.TextLightStyle
				};
				pGridPanel.AddChild(child, new GridComponentSpec(num, 1)
				{
					Margin = OptionsEntry.LABEL_MARGIN,
					Alignment = TextAnchor.MiddleLeft
				});
				PTextField pTextField = new PTextField(name + ".lux")
				{
					Type = PTextField.FieldType.Integer,
					MinWidth = 48,
					OnTextChanged = (GameObject o, string text) =>
					{
						if (int.TryParse(text, out var result))
						{
							value[type].lux = result;
							UpdateComponents();
						}
					}
				};
				pTextField.AddOnRealize((GameObject o) =>
				{
					luxComponents.Add(type, o);
				});
				pGridPanel.AddChild(pTextField, new GridComponentSpec(num, 2)
				{
					Margin = OptionsEntry.LABEL_MARGIN
				});
				PTextField pTextField2 = new PTextField(name + ".range")
				{
					Type = PTextField.FieldType.Integer,
					MinWidth = 48,
					OnTextChanged = (GameObject o, string text) =>
					{
						if (int.TryParse(text, out var result))
						{
							value[type].range = result;
							UpdateComponents();
						}
					}
				};
				pTextField2.AddOnRealize((GameObject o) =>
				{
					rangeComponents.Add(type, o);
				});
				pGridPanel.AddChild(pTextField2, new GridComponentSpec(num, 3)
				{
					Margin = OptionsEntry.LABEL_MARGIN
				});
				PTextField pTextField3 = new PTextField(name + ".reveal")
				{
					Type = PTextField.FieldType.Integer,
					MinWidth = 48,
					OnTextChanged = (GameObject o, string text) =>
					{
						if (int.TryParse(text, out var result))
						{
							value[type].reveal = result;
							UpdateComponents();
						}
					}
				};
				pTextField3.AddOnRealize((GameObject o) =>
				{
					revealComponents.Add(type, o);
				});
				pGridPanel.AddChild(pTextField3, new GridComponentSpec(num, 4)
				{
					Margin = OptionsEntry.LABEL_MARGIN
				});
				num++;
			}
			parent.AddChild(pGridPanel, new GridComponentSpec(parentRow, 0)
			{
				ColumnSpan = 2
			});
			UpdateComponents();
		}

		private void UpdateComponents()
		{
			if (value == null)
			{
				return;
			}
			foreach (KeyValuePair<BuildingType, LightConfig> item in value)
			{
				if (enabledComponents.ContainsKey(item.Key))
				{
					PCheckBox.SetCheckState(enabledComponents[item.Key], item.Value.enabled ? 1 : 0);
					PLibUtils.SetFieldText(luxComponents[item.Key], item.Value.lux.ToString());
					PLibUtils.SetFieldText(rangeComponents[item.Key], item.Value.range.ToString());
					PLibUtils.SetFieldText(revealComponents[item.Key], item.Value.reveal.ToString());
				}
			}
		}

		public override GameObject GetUIComponent()
		{
			throw new NotImplementedException();
		}
	}
}
