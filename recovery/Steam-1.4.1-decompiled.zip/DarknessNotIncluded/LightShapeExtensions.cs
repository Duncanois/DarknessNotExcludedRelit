namespace DarknessNotIncluded
{
	public static class LightShapeExtensions
	{
		public static global::LightShape LightShape(this LightShape shape)
		{
			if (!CustomLightShapes.Enabled)
			{
				return global::LightShape.Circle;
			}
			switch (shape)
			{
			case DarknessNotIncluded.LightShape.Circle:
				return global::LightShape.Circle;
			case DarknessNotIncluded.LightShape.SmoothCircle:
				return CustomLightShapes.SmoothCircle?.KleiLightShape ?? global::LightShape.Circle;
			case DarknessNotIncluded.LightShape.Pill:
				return CustomLightShapes.Pill?.KleiLightShape ?? global::LightShape.Circle;
			case DarknessNotIncluded.LightShape.DirectedCone:
				return CustomLightShapes.DirectedCone?.KleiLightShape ?? global::LightShape.Circle;
			default:
				return global::LightShape.Circle;
			}
		}
	}
}
