using System;
using HarmonyLib;
using KMod;
using PeterHan.PLib.Core;
using PeterHan.PLib.Options;

namespace DarknessNotIncluded
{
	public class Mod : UserMod2
	{
		public static Version Version = typeof(Mod).Assembly.GetName().Version;

		public override void OnLoad(Harmony harmony)
		{
			base.OnLoad(harmony);
			try
			{
				PUtil.InitLibrary();
			}
			catch (Exception ex)
			{
				Log.Error("Failed to initialize PLib", ex);
			}
			Log.Info("Bundled PLib version: 4.19.0.0");
			Log.Info(" Active PLib version: " + PLibUtils.ActiveVersion() + " (via assembly: " + PLibUtils.ActiveAssembly().FullName + ")");
			CompatibilityProbe.Run();
			Config.Initialize(this);
			try
			{
				Config config = POptions.ReadSettings<Config>();
				if (config != null)
				{
					Config.instance = config;
				}
				else if (Config.instance == null)
				{
					Config.instance = new Config();
				}
			}
			catch (Exception ex2)
			{
				Log.Warn("Failed to read settings; using defaults", ex2);
				if (Config.instance == null)
				{
					Config.instance = new Config();
				}
			}
			if (Config.instance.enableCustomLightShapes)
			{
				CustomLightShapes.Initialize();
				Log.Info("Custom light shapes enabled.");
			}
			else
			{
				CustomLightShapes.Enabled = false;
				Log.Info("Custom light shapes disabled by configuration.");
			}
		}
	}
}
