using System;
using System.Collections.Generic;
using DarknessNotIncluded.OptionsEnhancements;
using HarmonyLib;
using KMod;
using Newtonsoft.Json;
using PeterHan.PLib;
using PeterHan.PLib.Options;
using UnityEngine;

namespace DarknessNotIncluded
{
	[JsonObject(MemberSerialization.OptOut)]
	[ModInfo("https://github.com/nevir/oni-darkness-not-excluded", "preview.png", false)]
	[ConfigFile("config.json", false, true)]
	[RestartRequired]
	public class Config
	{
		public class Observer
		{
			public Observer(Action<Config> observer)
			{
				observers.Add(observer);
				observer(Get());
			}
		}

		[HarmonyPatch(typeof(Game))]
		[HarmonyPatch("OnPrefabInit")]
		private static class Patched_Game_OnPrefabInit
		{
			private static void Prefix()
			{
				instance = POptions.ReadSettings<Config>();
			}
		}

		private static List<Action<Config>> observers = new List<Action<Config>>();

		public static Config instance;

		[Option("Lux threshold", "At what lux should a tile be fully visible?", "Darkness")]
		public int fullyVisibleLuxThreshold { get; set; }

		[Option("Unlit tiles hide details", "Whether unlit tiles should only show basic details when hovered", "Darkness")]
		public bool selectToolBlockedByDarkness { get; set; }

		[Option("Darkness in sandbox mode", "Whether darkness is enabled while in sandbox mode", "Darkness")]
		public bool darknessInSandboxMode { get; set; }

		[Option("Darkness grace period (cycles)", "How many cycles should it take to go from initial darkness to maximum darkness?", "Darkness")]
		public float gracePeriodCycles { get; set; }

		[Option("Initial darkness level", "How dark should 0 lux tiles be at the start of the game?\n0 = pitch black, 255 = fully visible", "Darkness")]
		[Limit(0.0, 255.0)]
		public int initialFogLevel { get; set; }

		[Option("Maximum darkness level", "How dark should 0 lux tiles be after the initial grace period?\n0 = pitch black, 255 = fully visible", "Darkness")]
		[Limit(0.0, 255.0)]
		public int minimumFogLevel { get; set; }

		[Option("Block visibility through walls", "Hides tiles/cells from line of sight when blocked by solid tiles.", "Darkness")]
		public bool occludeVisibilityByWalls { get; set; }

		[Option("Perform actions on unexplored cells", "Whether you are able to drag actions (like dig) on unexplored cells", "Exploration")]
		public bool dragToolIgnoresVisibility { get; set; }

		[Option("Printing Pod reveal (radius)", "How many tiles should be revealed around the starting point?", "Exploration")]
		public int telepadRevealRadius { get; set; }

		[DynamicOption(typeof(BuildingLightingConfigEntry), "Building Lights")]
		[Option("Configuration for building lights", "Configuration for building lights", "Building Lights")]
		public BuildingLightingConfig buildingLightingConfig { get; set; }

		[Option("Max lux tolerated by Dusk Caps", "How much light Dusk Caps can handle before having stunted growth.", "Plants")]
		public int duskCapPlantMaxLux { get; set; }

		[Option("Max lux tolerated by Bog Buckets", "How much light Bog Buckets can handle before having stunted growth.", "Plants")]
		public int bogBucketPlantMaxLux { get; set; }

		[Option("Decor bonus threshold (lux)", "At what lux should decor get a bonus for being well lit?", "Light Bonuses")]
		public int decorBonusThresholdLux { get; set; }

		[Option("Lux required for Lit Workspace bonus", "The minimum amount of lux before a Duplicant will receive the Lit Workspace speed bonus", "Light Bonuses")]
		public int litWorkspaceLux { get; set; }

		[Option("Maximum lux tolerated while sleeping", "The maximum lux that a dupe can handle before being rudely woken up.", "Darkness Penalties")]
		public int maxSleepingLux { get; set; }

		[Option("Game ticks before sleep is disturbed", "The number of game ticks required before a Duplicant will be rudely woken up.", "Darkness Penalties")]
		public int sleepingDisturbedTicks { get; set; }

		[Option("Penalize Strength", "Whether to penalize the Duplicant's Strength attribute due to darkness.", "Darkness Penalties")]
		public bool penalizeStrength { get; set; }

		[DynamicOption(typeof(MinionEffectsConfigEntry), "Darkness Penalties")]
		[Option("Configuration for dupe effects", "Configuration for dupe effects", "Darkness Penalties")]
		public MinionEffectsConfig minionEffectsConfig { get; set; }

		[Option("Disable lights around sleeping dupes", "Whether dupes should turn their lights off when entering a bedroom.", "Duplicant Lights")]
		public bool disableDupeLightsInBedrooms { get; set; }

		[Option("Disable lights in lit areas", "Whether dupes should turn their lights off when entering an area with level of brightness sufficient for the Lit Workspace bonus.", "Duplicant Lights")]
		public bool disableDupeLightsInLitAreas { get; set; }

		[DynamicOption(typeof(MinionLightingConfigEntry), "Duplicant Lights")]
		[Option("Configuration for dupe lights", "Configuration for dupe lights", "Duplicant Lights")]
		public MinionLightingConfig minionLightingConfig { get; set; }

		[Option("Enable Custom Light Shapes", "If disabled, only vanilla light shapes will be used. Disable if encountering issues with other lighting mods.", "Lighting")]
		public bool enableCustomLightShapes { get; set; } = true;

		[OptionPreset("The Deep Dark")]
		public static Config TheDeepDark()
		{
			return new Config
			{
				gracePeriodCycles = 0f,
				initialFogLevel = 0,
				minimumFogLevel = 0,
				sleepingDisturbedTicks = 0,
				penalizeStrength = true,
				occludeVisibilityByWalls = true
			};
		}

		[OptionPreset("Visuals Only")]
		public static Config VisualsOnly()
		{
			return new Config(disableMinionEffects: true, defaultMinionReveal: true)
			{
				selectToolBlockedByDarkness = false,
				darknessInSandboxMode = true,
				dragToolIgnoresVisibility = false,
				telepadRevealRadius = 18,
				occludeVisibilityByWalls = false
			};
		}

		public Config()
			: this(disableMinionEffects: false, defaultMinionReveal: false)
		{
		}

		public Config(bool disableMinionEffects, bool defaultMinionReveal)
		{
			fullyVisibleLuxThreshold = 1000;
			selectToolBlockedByDarkness = true;
			darknessInSandboxMode = false;
			gracePeriodCycles = 3f;
			initialFogLevel = 200;
			minimumFogLevel = 35;
			occludeVisibilityByWalls = false;
			dragToolIgnoresVisibility = true;
			telepadRevealRadius = 0;
			buildingLightingConfig = new BuildingLightingConfig();
			duskCapPlantMaxLux = 500;
			bogBucketPlantMaxLux = 500;
			decorBonusThresholdLux = 1000;
			litWorkspaceLux = 1000;
			maxSleepingLux = 500;
			sleepingDisturbedTicks = 25;
			penalizeStrength = false;
			minionEffectsConfig = new MinionEffectsConfig();
			if (disableMinionEffects)
			{
				foreach (KeyValuePair<MinionEffectType, MinionEffectsConfig.EffectConfig> item in minionEffectsConfig)
				{
					item.Value.enabled = false;
					item.Value.agilityModifier = 0;
					item.Value.statsModifier = 0;
				}
			}
			disableDupeLightsInLitAreas = true;
			disableDupeLightsInBedrooms = true;
			minionLightingConfig = new MinionLightingConfig();
			if (!defaultMinionReveal)
			{
				return;
			}
			foreach (KeyValuePair<MinionLightType, LightConfig> item2 in minionLightingConfig)
			{
				item2.Value.reveal = 30;
			}
		}

		public static void ObserveFor(object target, Action<Config> observer)
		{
			WeakReference targetRef = new WeakReference(target);
			Action<Config> wrappedObserver = null;
			wrappedObserver = (Config config) =>
			{
				if (targetRef.Target == null)
				{
					observers.Remove(wrappedObserver);
				}
				else
				{
					observer(config);
				}
			};
			observers.Add(wrappedObserver);
			observer(Get());
		}

		private static Config Get()
		{
			if (instance == null)
			{
				instance = POptions.ReadSettings<Config>() ?? new Config();
			}
			return instance;
		}

		public static void Set(Config newConfig)
		{
			instance = newConfig;
			foreach (Action<Config> observer in observers)
			{
				observer(newConfig);
			}
		}

		public static void Initialize(UserMod2 mod)
		{
			new POptions().RegisterOptions(mod, typeof(Config));
		}

		public static void ShowRestartPrompt()
		{
			try
			{
				GameObject gameObject = ((!(Global.Instance != null)) ? null : Global.Instance.globalCanvas?.gameObject);
				if (gameObject != null)
				{
					Manager.Dialog(gameObject, "Restart Required", "Some changes will only take effect after restarting the game.");
				}
				else
				{
					Debug.Log("[Darkness Not Excluded] Restart Required: Some changes will only take effect after restarting the game.");
				}
			}
			catch (Exception arg)
			{
				Debug.Log($"[Darkness Not Excluded] Failed to open dialog. {arg}");
				Debug.Log("[Darkness Not Excluded] Restart Required: Some changes will only take effect after restarting the game.");
			}
		}
	}
}
