using System.Collections.Generic;

namespace PeterHan.PLib.Options
{
	internal interface IOptions
	{
		IEnumerable<IOptionsEntry> CreateOptions();

		void OnOptionsChanged();
	}
}
