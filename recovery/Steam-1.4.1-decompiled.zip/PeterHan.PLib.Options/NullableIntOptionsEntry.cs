using PeterHan.PLib.UI;
using TMPro;
using UnityEngine;

namespace PeterHan.PLib.Options
{
	internal class NullableIntOptionsEntry : SlidingBaseOptionsEntry
	{
		private GameObject textField;

		private int? value;

		protected virtual string FieldText => value?.ToString(Format ?? "D") ?? string.Empty;

		public override object Value
		{
			get
			{
				return value;
			}
			set
			{
				if (value == null)
				{
					this.value = null;
					Update();
				}
				else if (value is int num)
				{
					this.value = num;
					Update();
				}
			}
		}

		public NullableIntOptionsEntry(string field, IOptionSpec spec, LimitAttribute limit = null)
			: base(field, spec, limit)
		{
			textField = null;
			value = null;
		}

		protected override PSliderSingle GetSlider()
		{
			float num = (float)limits.Minimum;
			float maxValue = (float)limits.Maximum;
			return new PSliderSingle
			{
				OnValueChanged = OnSliderChanged,
				ToolTip = OptionsEntry.LookInStrings(Tooltip),
				MinValue = num,
				MaxValue = maxValue,
				InitialValue = num,
				IntegersOnly = true
			};
		}

		public override GameObject GetUIComponent()
		{
			textField = new PTextField
			{
				OnTextChanged = OnTextChanged,
				ToolTip = OptionsEntry.LookInStrings(Tooltip),
				Text = FieldText,
				MinWidth = 64,
				MaxLength = 10,
				Type = PTextField.FieldType.Integer
			}.Build();
			Update();
			return textField;
		}

		private void OnSliderChanged(GameObject _, float newValue)
		{
			int num = Mathf.RoundToInt(newValue);
			if (limits != null)
			{
				num = limits.ClampToRange(num);
			}
			value = num;
			Update();
		}

		private void OnTextChanged(GameObject _, string text)
		{
			int result;
			if (string.IsNullOrWhiteSpace(text))
			{
				value = null;
			}
			else if (int.TryParse(text, out result))
			{
				if (limits != null)
				{
					result = limits.ClampToRange(result);
				}
				value = result;
			}
			Update();
		}

		protected override void Update()
		{
			TMP_InputField tMP_InputField = textField?.GetComponentInChildren<TMP_InputField>();
			if (tMP_InputField != null)
			{
				tMP_InputField.text = FieldText;
			}
			if (slider != null && value.HasValue)
			{
				PSliderSingle.SetCurrentValue(slider, value.Value);
			}
		}
	}
}
