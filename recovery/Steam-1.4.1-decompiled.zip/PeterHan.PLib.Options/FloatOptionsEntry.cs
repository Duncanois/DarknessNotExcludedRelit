using PeterHan.PLib.UI;
using TMPro;
using UnityEngine;

namespace PeterHan.PLib.Options
{
	internal class FloatOptionsEntry : SlidingBaseOptionsEntry
	{
		public const string DEFAULT_FORMAT = "F2";

		private GameObject textField;

		private float value;

		public override object Value
		{
			get
			{
				return value;
			}
			set
			{
				if (value is float num)
				{
					this.value = num;
					Update();
				}
			}
		}

		public FloatOptionsEntry(string field, IOptionSpec spec, LimitAttribute limit = null)
			: base(field, spec, limit)
		{
			textField = null;
			value = 0f;
		}

		protected override PSliderSingle GetSlider()
		{
			return new PSliderSingle
			{
				OnValueChanged = OnSliderChanged,
				ToolTip = OptionsEntry.LookInStrings(Tooltip),
				MinValue = (float)limits.Minimum,
				MaxValue = (float)limits.Maximum,
				InitialValue = value
			};
		}

		public override GameObject GetUIComponent()
		{
			textField = new PTextField
			{
				OnTextChanged = OnTextChanged,
				ToolTip = OptionsEntry.LookInStrings(Tooltip),
				Text = value.ToString(Format ?? "F2"),
				MinWidth = 64,
				MaxLength = 16,
				Type = PTextField.FieldType.Float
			}.Build();
			Update();
			return textField;
		}

		private void OnSliderChanged(GameObject _, float newValue)
		{
			if (limits != null)
			{
				value = limits.ClampToRange(newValue);
			}
			else
			{
				value = newValue;
			}
			Update();
		}

		private void OnTextChanged(GameObject _, string text)
		{
			if (float.TryParse(text, out var result))
			{
				if (Format != null && Format.ToUpperInvariant().IndexOf('P') >= 0)
				{
					result *= 0.01f;
				}
				if (limits != null)
				{
					result = limits.ClampToRange(result);
				}
				value = result;
			}
			Update();
		}

		protected override void Update()
		{
			TMP_InputField tMP_InputField = textField?.GetComponentInChildren<TMP_InputField>();
			if (tMP_InputField != null)
			{
				tMP_InputField.text = value.ToString(Format ?? "F2");
			}
			if (slider != null)
			{
				PSliderSingle.SetCurrentValue(slider, value);
			}
		}
	}
}
