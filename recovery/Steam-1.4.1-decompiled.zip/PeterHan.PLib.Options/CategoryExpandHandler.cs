using PeterHan.PLib.UI;
using UnityEngine;
using UnityEngine.UI;

namespace PeterHan.PLib.Options
{
	internal sealed class CategoryExpandHandler
	{
		private GameObject contents;

		private readonly bool initialState;

		private GameObject toggle;

		public CategoryExpandHandler(bool initialState = true)
		{
			this.initialState = initialState;
		}

		public void OnExpandContract(GameObject _, bool on)
		{
			Vector3 localScale = (on ? Vector3.one : Vector3.zero);
			if (contents != null)
			{
				RectTransform rectTransform = contents.rectTransform();
				rectTransform.localScale = localScale;
				if (rectTransform != null)
				{
					LayoutRebuilder.MarkLayoutForRebuild(rectTransform);
				}
			}
		}

		private void OnHeaderClicked()
		{
			if (toggle != null)
			{
				bool toggleState = PToggle.GetToggleState(toggle);
				PToggle.SetToggleState(toggle, !toggleState);
			}
		}

		public void OnRealizeHeader(GameObject header)
		{
			Button button = header.AddComponent<Button>();
			button.onClick.AddListener(OnHeaderClicked);
			button.interactable = true;
		}

		public void OnRealizePanel(GameObject panel)
		{
			contents = panel;
			OnExpandContract(null, initialState);
		}

		public void OnRealizeToggle(GameObject toggle)
		{
			this.toggle = toggle;
		}
	}
}
