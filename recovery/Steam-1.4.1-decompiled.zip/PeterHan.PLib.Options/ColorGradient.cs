using System;
using UnityEngine;
using UnityEngine.UI;

namespace PeterHan.PLib.Options
{
	internal sealed class ColorGradient : Image
	{
		private Color current;

		private bool dirty;

		private Vector2 hue;

		private float position;

		private Texture2D preview;

		private Vector2 sat;

		private Vector2 val;

		public float Position
		{
			get
			{
				return position;
			}
			set
			{
				position = Mathf.Clamp01(value);
				SetPosition();
			}
		}

		public Color SelectedColor
		{
			get
			{
				return current;
			}
			set
			{
				current = value;
				EstimatePosition();
			}
		}

		public ColorGradient()
		{
			current = Color.black;
			position = 0f;
			preview = null;
			dirty = true;
			hue = Vector2.right;
			sat = Vector2.right;
			val = Vector2.right;
		}

		internal void EstimatePosition()
		{
			Color.RGBToHSV(current, out var H, out var S, out var V);
			float num = 0f;
			float num2 = 0f;
			if (!Mathf.Approximately(hue.x, hue.y))
			{
				num += Mathf.Clamp01(Mathf.InverseLerp(hue.x, hue.y, H));
				num2++;
			}
			if (!Mathf.Approximately(sat.x, sat.y))
			{
				num += Mathf.Clamp01(Mathf.InverseLerp(sat.x, sat.y, S));
				num2++;
			}
			if (!Mathf.Approximately(val.x, val.y))
			{
				num += Mathf.Clamp01(Mathf.InverseLerp(val.x, val.y, V));
				num2++;
			}
			if (num2 > 0f)
			{
				position = num / num2;
				SetPosition();
			}
		}

		protected override void OnDestroy()
		{
			if (preview != null)
			{
				UnityEngine.Object.Destroy(preview);
				preview = null;
			}
			if (sprite != null)
			{
				UnityEngine.Object.Destroy(sprite);
				sprite = null;
			}
			base.OnDestroy();
		}

		protected override void OnRectTransformDimensionsChange()
		{
			base.OnRectTransformDimensionsChange();
			dirty = true;
		}

		internal void SetPosition()
		{
			float h = Mathf.Clamp01(Mathf.Lerp(hue.x, hue.y, position));
			float s = Mathf.Clamp01(Mathf.Lerp(sat.x, sat.y, position));
			float v = Mathf.Clamp01(Mathf.Lerp(val.x, val.y, position));
			current = Color.HSVToRGB(h, s, v);
		}

		public void SetRange(float hMin, float hMax, float sMin, float sMax, float vMin, float vMax)
		{
			if (hMin > hMax)
			{
				hue.x = hMax;
				hue.y = hMin;
			}
			else
			{
				hue.x = hMin;
				hue.y = hMax;
			}
			if (sMin > sMax)
			{
				sat.x = sMax;
				sat.y = sMin;
			}
			else
			{
				sat.x = sMin;
				sat.y = sMax;
			}
			if (vMin > vMax)
			{
				val.x = vMax;
				val.y = vMin;
			}
			else
			{
				val.x = vMin;
				val.y = vMax;
			}
			EstimatePosition();
			dirty = true;
		}

		protected override void Start()
		{
			base.Start();
			dirty = true;
		}

		internal void Update()
		{
			if (!dirty && !(preview == null) && !(base.sprite == null))
			{
				return;
			}
			Rect rect = rectTransform.rect;
			int num = Mathf.RoundToInt(rect.width);
			int num2 = Mathf.RoundToInt(rect.height);
			if (num > 0 && num2 > 0)
			{
				Color[] array = new Color[num * num2];
				float x = hue.x;
				float y = hue.y;
				float x2 = sat.x;
				float y2 = sat.y;
				float x3 = val.x;
				float y3 = val.y;
				Sprite sprite = base.sprite;
				bool flag = preview == null || sprite == null || preview.width != num || preview.height != num2;
				if (flag)
				{
					if (preview != null)
					{
						UnityEngine.Object.Destroy(preview);
					}
					if (sprite != null)
					{
						UnityEngine.Object.Destroy(sprite);
					}
					preview = new Texture2D(num, num2);
				}
				for (int i = 0; i < num; i++)
				{
					float t = (float)i / (float)num;
					array[i] = Color.HSVToRGB(Mathf.Lerp(x, y, t), Mathf.Lerp(x2, y2, t), Mathf.Lerp(x3, y3, t));
				}
				for (int j = 1; j < num2; j++)
				{
					Array.Copy(array, 0, array, j * num, num);
				}
				preview.SetPixels(array);
				preview.Apply();
				if (flag)
				{
					base.sprite = Sprite.Create(preview, new Rect(0f, 0f, num, num2), new Vector2(0.5f, 0.5f));
				}
			}
			dirty = false;
		}
	}
}
