using UnityEngine;

namespace PeterHan.PLib.Options
{
	internal class ColorOptionsEntry : ColorBaseOptionsEntry
	{
		public override object Value
		{
			get
			{
				return value;
			}
			set
			{
				if (value is Color color)
				{
					base.value = color;
					UpdateAll();
				}
			}
		}

		public ColorOptionsEntry(string field, IOptionSpec spec)
			: base(field, spec)
		{
		}
	}
}
