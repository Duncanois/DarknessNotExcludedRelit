using PeterHan.PLib.Core;
using PeterHan.PLib.UI;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace PeterHan.PLib.Options
{
	internal abstract class ColorBaseOptionsEntry : OptionsEntry
	{
		protected static readonly RectOffset ENTRY_MARGIN = new RectOffset(10, 10, 2, 5);

		protected static readonly RectOffset SLIDER_MARGIN = new RectOffset(10, 0, 2, 2);

		protected const float SWATCH_SIZE = 32f;

		protected ColorGradient hueGradient;

		protected KSlider hueSlider;

		protected TMP_InputField blue;

		protected TMP_InputField green;

		protected TMP_InputField red;

		protected ColorGradient satGradient;

		protected KSlider satSlider;

		protected Image swatch;

		protected ColorGradient valGradient;

		protected KSlider valSlider;

		protected Color value;

		protected ColorBaseOptionsEntry(string field, IOptionSpec spec)
			: base(field, spec)
		{
			value = Color.white;
			blue = null;
			green = null;
			red = null;
			hueGradient = null;
			hueSlider = null;
			satGradient = null;
			satSlider = null;
			valGradient = null;
			valSlider = null;
			swatch = null;
		}

		public override void CreateUIEntry(PGridPanel parent, ref int row)
		{
			base.CreateUIEntry(parent, ref row);
			parent.AddRow(new GridRowSpec());
			PSliderSingle pSliderSingle = new PSliderSingle("Hue")
			{
				ToolTip = PLibStrings.TOOLTIP_HUE,
				MinValue = 0f,
				MaxValue = 1f,
				CustomTrack = true,
				FlexSize = Vector2.right,
				OnValueChanged = OnHueChanged
			}.AddOnRealize(OnHueRealized);
			PSliderSingle pSliderSingle2 = new PSliderSingle("Saturation")
			{
				ToolTip = PLibStrings.TOOLTIP_SATURATION,
				MinValue = 0f,
				MaxValue = 1f,
				CustomTrack = true,
				FlexSize = Vector2.right,
				OnValueChanged = OnSatChanged
			}.AddOnRealize(OnSatRealized);
			PSliderSingle pSliderSingle3 = new PSliderSingle("Value")
			{
				ToolTip = PLibStrings.TOOLTIP_VALUE,
				MinValue = 0f,
				MaxValue = 1f,
				CustomTrack = true,
				FlexSize = Vector2.right,
				OnValueChanged = OnValChanged
			}.AddOnRealize(OnValRealized);
			PLabel pLabel = new PLabel("Swatch")
			{
				ToolTip = OptionsEntry.LookInStrings(Tooltip),
				DynamicSize = false,
				Sprite = PUITuning.Images.BoxBorder,
				SpriteMode = Image.Type.Sliced,
				SpriteSize = new Vector2(32f, 32f)
			}.AddOnRealize(OnSwatchRealized);
			PRelativePanel child = new PRelativePanel("ColorPicker")
			{
				FlexSize = Vector2.right,
				DynamicSize = false
			}.AddChild(pSliderSingle).AddChild(pSliderSingle2).AddChild(pSliderSingle3)
				.AddChild(pLabel)
				.SetRightEdge(pSliderSingle, 1f)
				.SetRightEdge(pSliderSingle2, 1f)
				.SetRightEdge(pSliderSingle3, 1f)
				.SetLeftEdge(pLabel, 0f)
				.SetMargin(pSliderSingle, SLIDER_MARGIN)
				.SetMargin(pSliderSingle2, SLIDER_MARGIN)
				.SetMargin(pSliderSingle3, SLIDER_MARGIN)
				.AnchorYAxis(pLabel)
				.SetLeftEdge(pSliderSingle, -1f, pLabel)
				.SetLeftEdge(pSliderSingle2, -1f, pLabel)
				.SetLeftEdge(pSliderSingle3, -1f, pLabel)
				.SetTopEdge(pSliderSingle, 1f)
				.SetBottomEdge(pSliderSingle3, 0f)
				.SetTopEdge(pSliderSingle2, -1f, pSliderSingle)
				.SetTopEdge(pSliderSingle3, -1f, pSliderSingle2);
			parent.AddChild(child, new GridComponentSpec(++row, 0)
			{
				ColumnSpan = 2,
				Margin = ENTRY_MARGIN
			});
		}

		public override GameObject GetUIComponent()
		{
			Color32 color = value;
			GameObject result = new PPanel("RGB")
			{
				DynamicSize = false,
				Alignment = TextAnchor.MiddleRight,
				Spacing = 5,
				Direction = PanelDirection.Horizontal
			}.AddChild(new PLabel("Red")
			{
				TextStyle = PUITuning.Fonts.TextLightStyle,
				Text = PLibStrings.LABEL_R
			}).AddChild(new PTextField("RedValue")
			{
				OnTextChanged = OnRGBChanged,
				ToolTip = PLibStrings.TOOLTIP_RED,
				Text = color.r.ToString(),
				MinWidth = 32,
				MaxLength = 3,
				Type = PTextField.FieldType.Integer
			}.AddOnRealize(OnRedRealized)).AddChild(new PLabel("Green")
			{
				TextStyle = PUITuning.Fonts.TextLightStyle,
				Text = PLibStrings.LABEL_G
			})
				.AddChild(new PTextField("GreenValue")
				{
					OnTextChanged = OnRGBChanged,
					ToolTip = PLibStrings.TOOLTIP_GREEN,
					Text = color.g.ToString(),
					MinWidth = 32,
					MaxLength = 3,
					Type = PTextField.FieldType.Integer
				}.AddOnRealize(OnGreenRealized))
				.AddChild(new PLabel("Blue")
				{
					TextStyle = PUITuning.Fonts.TextLightStyle,
					Text = PLibStrings.LABEL_B
				})
				.AddChild(new PTextField("BlueValue")
				{
					OnTextChanged = OnRGBChanged,
					ToolTip = PLibStrings.TOOLTIP_BLUE,
					Text = color.b.ToString(),
					MinWidth = 32,
					MaxLength = 3,
					Type = PTextField.FieldType.Integer
				}.AddOnRealize(OnBlueRealized))
				.Build();
			UpdateAll();
			return result;
		}

		private void OnBlueRealized(GameObject realized)
		{
			blue = realized.GetComponentInChildren<TMP_InputField>();
		}

		private void OnGreenRealized(GameObject realized)
		{
			green = realized.GetComponentInChildren<TMP_InputField>();
		}

		private void OnHueChanged(GameObject _, float newHue)
		{
			if (hueGradient != null && hueSlider != null)
			{
				float a = value.a;
				hueGradient.Position = hueSlider.value;
				value = hueGradient.SelectedColor;
				value.a = a;
				UpdateRGB();
				UpdateSat(moveSlider: false);
				UpdateVal(moveSlider: false);
			}
		}

		private void OnHueRealized(GameObject realized)
		{
			hueGradient = realized.AddOrGet<ColorGradient>();
			realized.TryGetComponent<KSlider>(out hueSlider);
		}

		private void OnRedRealized(GameObject realized)
		{
			red = realized.GetComponentInChildren<TMP_InputField>();
		}

		protected void OnRGBChanged(GameObject _, string text)
		{
			Color32 color = value;
			if (byte.TryParse(red.text, out var result))
			{
				color.r = result;
			}
			if (byte.TryParse(green.text, out var result2))
			{
				color.g = result2;
			}
			if (byte.TryParse(blue.text, out var result3))
			{
				color.b = result3;
			}
			value = color;
			UpdateAll();
		}

		private void OnSatChanged(GameObject _, float newSat)
		{
			if (satGradient != null && satSlider != null)
			{
				float a = value.a;
				satGradient.Position = satSlider.value;
				value = satGradient.SelectedColor;
				value.a = a;
				UpdateRGB();
				UpdateHue(moveSlider: false);
				UpdateVal(moveSlider: false);
			}
		}

		private void OnSatRealized(GameObject realized)
		{
			satGradient = realized.AddOrGet<ColorGradient>();
			realized.TryGetComponent<KSlider>(out satSlider);
		}

		private void OnSwatchRealized(GameObject realized)
		{
			swatch = realized.GetComponentInChildren<Image>();
		}

		private void OnValChanged(GameObject _, float newValue)
		{
			if (valGradient != null && valSlider != null)
			{
				float a = value.a;
				valGradient.Position = valSlider.value;
				value = valGradient.SelectedColor;
				value.a = a;
				UpdateRGB();
				UpdateHue(moveSlider: false);
				UpdateSat(moveSlider: false);
			}
		}

		private void OnValRealized(GameObject realized)
		{
			valGradient = realized.AddOrGet<ColorGradient>();
			realized.TryGetComponent<KSlider>(out valSlider);
		}

		protected void UpdateAll()
		{
			UpdateRGB();
			UpdateHue(moveSlider: true);
			UpdateSat(moveSlider: true);
			UpdateVal(moveSlider: true);
		}

		protected void UpdateHue(bool moveSlider)
		{
			if (hueGradient != null && hueSlider != null)
			{
				Color.RGBToHSV(value, out var _, out var S, out var V);
				hueGradient.SetRange(0f, 1f, S, S, V, V);
				hueGradient.SelectedColor = value;
				if (moveSlider)
				{
					hueSlider.value = hueGradient.Position;
				}
			}
		}

		protected void UpdateRGB()
		{
			Color32 color = value;
			if (red != null)
			{
				red.text = color.r.ToString();
			}
			if (green != null)
			{
				green.text = color.g.ToString();
			}
			if (blue != null)
			{
				blue.text = color.b.ToString();
			}
			if (swatch != null)
			{
				swatch.color = value;
			}
		}

		protected void UpdateSat(bool moveSlider)
		{
			if (satGradient != null && satSlider != null)
			{
				Color.RGBToHSV(value, out var H, out var _, out var V);
				satGradient.SetRange(H, H, 0f, 1f, V, V);
				satGradient.SelectedColor = value;
				if (moveSlider)
				{
					satSlider.value = satGradient.Position;
				}
			}
		}

		protected void UpdateVal(bool moveSlider)
		{
			if (valGradient != null && valSlider != null)
			{
				Color.RGBToHSV(value, out var H, out var S, out var _);
				valGradient.SetRange(H, H, S, S, 0f, 1f);
				valGradient.SelectedColor = value;
				if (moveSlider)
				{
					valSlider.value = valGradient.Position;
				}
			}
		}
	}
}
