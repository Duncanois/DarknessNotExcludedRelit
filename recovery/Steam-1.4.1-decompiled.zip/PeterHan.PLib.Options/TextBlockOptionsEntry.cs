using PeterHan.PLib.UI;
using UnityEngine;

namespace PeterHan.PLib.Options
{
	internal class TextBlockOptionsEntry : OptionsEntry
	{
		private static readonly TextStyleSetting WRAP_TEXT_STYLE;

		private LocText ignore;

		public override object Value
		{
			get
			{
				return ignore;
			}
			set
			{
				if (value is LocText locText)
				{
					ignore = locText;
				}
			}
		}

		static TextBlockOptionsEntry()
		{
			WRAP_TEXT_STYLE = PUITuning.Fonts.TextLightStyle.DeriveStyle();
			WRAP_TEXT_STYLE.enableWordWrapping = true;
		}

		public TextBlockOptionsEntry(string field, IOptionSpec spec)
			: base(field, spec)
		{
		}

		public override void CreateUIEntry(PGridPanel parent, ref int row)
		{
			parent.AddChild(new PLabel(Field)
			{
				Text = OptionsEntry.LookInStrings(Title),
				ToolTip = OptionsEntry.LookInStrings(Tooltip),
				TextStyle = WRAP_TEXT_STYLE
			}, new GridComponentSpec(row, 0)
			{
				Margin = OptionsEntry.CONTROL_MARGIN,
				Alignment = TextAnchor.MiddleCenter,
				ColumnSpan = 2
			});
		}

		public override GameObject GetUIComponent()
		{
			return new GameObject("Empty");
		}
	}
}
