using UnityEngine;

namespace PeterHan.PLib.Options
{
	internal class Color32OptionsEntry : ColorBaseOptionsEntry
	{
		public override object Value
		{
			get
			{
				return (Color32)value;
			}
			set
			{
				if (value is Color32 color)
				{
					base.value = color;
					UpdateAll();
				}
			}
		}

		public Color32OptionsEntry(string field, IOptionSpec spec)
			: base(field, spec)
		{
		}
	}
}
