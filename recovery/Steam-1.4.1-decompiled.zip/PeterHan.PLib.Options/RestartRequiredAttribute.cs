using System;

namespace PeterHan.PLib.Options
{
	[AttributeUsage(AttributeTargets.Class | AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false, Inherited = true)]
	internal sealed class RestartRequiredAttribute : Attribute
	{
	}
}
