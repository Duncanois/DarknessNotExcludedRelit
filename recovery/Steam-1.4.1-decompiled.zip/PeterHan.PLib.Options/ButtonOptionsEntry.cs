using System;
using PeterHan.PLib.UI;
using UnityEngine;

namespace PeterHan.PLib.Options
{
	internal class ButtonOptionsEntry : OptionsEntry
	{
		private Action<object> value;

		public override object Value
		{
			get
			{
				return value;
			}
			set
			{
				if (value is Action<object> action)
				{
					this.value = action;
				}
			}
		}

		public ButtonOptionsEntry(string field, IOptionSpec spec)
			: base(field, spec)
		{
		}

		public override void CreateUIEntry(PGridPanel parent, ref int row)
		{
			parent.AddChild(new PButton(Field)
			{
				Text = OptionsEntry.LookInStrings(Title),
				ToolTip = OptionsEntry.LookInStrings(Tooltip),
				OnClick = OnButtonClicked
			}.SetKleiPinkStyle(), new GridComponentSpec(row, 0)
			{
				Margin = OptionsEntry.CONTROL_MARGIN,
				Alignment = TextAnchor.MiddleCenter,
				ColumnSpan = 2
			});
		}

		private void OnButtonClicked(GameObject _)
		{
			value?.Invoke(null);
		}

		public override GameObject GetUIComponent()
		{
			return new GameObject("Empty");
		}
	}
}
