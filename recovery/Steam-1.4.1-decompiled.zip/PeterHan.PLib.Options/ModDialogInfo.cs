using System;
using System.Reflection;
using KMod;
using PeterHan.PLib.Core;

namespace PeterHan.PLib.Options
{
	internal sealed class ModDialogInfo
	{
		public string Image { get; }

		public string Title { get; }

		public string URL { get; }

		public string Version { get; }

		private static string GetModVersionText(Type optionsType)
		{
			Assembly assembly = optionsType.Assembly;
			string fileVersion = assembly.GetFileVersion();
			if (string.IsNullOrEmpty(fileVersion))
			{
				return string.Format(PLibStrings.MOD_ASSEMBLY_VERSION, assembly.GetName().Version);
			}
			return string.Format(PLibStrings.MOD_VERSION, fileVersion);
		}

		internal ModDialogInfo(Type type, string url, string image)
		{
			Mod modFromType = POptions.GetModFromType(type);
			Image = image ?? "";
			string text2;
			string text3;
			if (modFromType != null)
			{
				string text = modFromType.packagedModInfo?.version;
				text2 = modFromType.title;
				if (Strings.TryGet(text2, out var result))
				{
					text2 = result.String;
				}
				if (string.IsNullOrEmpty(url) && modFromType.label.distribution_platform == Label.DistributionPlatform.Steam)
				{
					url = "https://steamcommunity.com/sharedfiles/filedetails/?id=" + modFromType.label.id;
				}
				text3 = (string.IsNullOrEmpty(text) ? GetModVersionText(type) : string.Format(PLibStrings.MOD_VERSION, text));
			}
			else
			{
				text2 = type.Assembly.GetNameSafe();
				text3 = GetModVersionText(type);
			}
			Title = text2 ?? "";
			URL = url ?? "";
			Version = text3;
		}

		public override string ToString()
		{
			return base.ToString();
		}
	}
}
