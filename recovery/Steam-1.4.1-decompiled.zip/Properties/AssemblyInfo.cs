using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: AssemblyCompany("DarknessNotExcluded.mod")]
[assembly: AssemblyConfiguration("Debug")]
[assembly: AssemblyFileVersion("1.4.1.0")]
[assembly: AssemblyInformationalVersion("1.4.1+b83df126e939c7d7c75e1963ae9f90994b48fc97")]
[assembly: AssemblyProduct("DarknessNotExcluded.mod")]
[assembly: AssemblyTitle("DarknessNotExcluded.mod")]
[assembly: AssemblyVersion("1.4.1.0")]
