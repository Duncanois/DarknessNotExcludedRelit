using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using HarmonyLib;
using PeterHan.PLib.Core;

namespace PeterHan.PLib.Database
{
	internal sealed class PLocalization : PForwardedComponent
	{
		public const string TRANSLATIONS_DIR = "translations";

		internal static readonly Version VERSION = new Version("4.19.0.0");

		private readonly ICollection<Assembly> toLocalize;

		public override Version Version => VERSION;

		private static void Localize(Assembly modAssembly, Localization.Locale locale)
		{
			string modPath = PUtil.GetModPath(modAssembly);
			string text = locale.Code;
			if (string.IsNullOrEmpty(text))
			{
				text = Localization.GetCurrentLanguageCode();
			}
			string path = Path.Combine(Path.Combine(modPath, "translations"), text + ".po");
			try
			{
				Localization.OverloadStrings(Localization.LoadStringsFile(path, isTemplate: false));
				RewriteStrings(modAssembly);
			}
			catch (FileNotFoundException)
			{
			}
			catch (DirectoryNotFoundException)
			{
			}
			catch (IOException thrown)
			{
				PDatabaseUtils.LogDatabaseWarning("Failed to load {0} localization for mod {1}:".F(text, modAssembly.GetNameSafe() ?? "?"));
				PUtil.LogExcWarn(thrown);
			}
		}

		internal static void RewriteStrings(Assembly assembly)
		{
			Type[] types = assembly.GetTypes();
			for (int i = 0; i < types.Length; i++)
			{
				FieldInfo[] fields = types[i].GetFields(BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy);
				foreach (FieldInfo fieldInfo in fields)
				{
					if (fieldInfo.FieldType == typeof(LocString) && fieldInfo.GetValue(null) is LocString locString)
					{
						Strings.Add(locString.key.String, locString.text);
					}
				}
			}
		}

		public PLocalization()
		{
			toLocalize = new List<Assembly>(4);
			InstanceData = toLocalize;
		}

		internal void DumpAll()
		{
			IEnumerable<PForwardedComponent> allComponents = PRegistry.Instance.GetAllComponents(ID);
			if (allComponents == null)
			{
				return;
			}
			foreach (PForwardedComponent item in allComponents)
			{
				ICollection<Assembly> instanceData = item.GetInstanceData<ICollection<Assembly>>();
				if (instanceData == null)
				{
					continue;
				}
				foreach (Assembly item2 in instanceData)
				{
					ModUtil.RegisterForTranslation(item2.GetTypes()[0]);
				}
			}
		}

		public override void Initialize(Harmony plibInstance)
		{
		}

		public override void Process(uint operation, object _)
		{
			Localization.Locale locale = Localization.GetLocale();
			if (locale == null || operation != 0)
			{
				return;
			}
			foreach (Assembly item in toLocalize)
			{
				Localize(item, locale);
			}
		}

		public void Register(Assembly assembly = null)
		{
			if (assembly == null)
			{
				assembly = Assembly.GetCallingAssembly();
			}
			Type[] types = assembly.GetTypes();
			if (types == null || types.Length == 0)
			{
				PDatabaseUtils.LogDatabaseWarning("Registered assembly " + assembly.GetNameSafe() + " that had no types for localization!");
				return;
			}
			RegisterForForwarding();
			toLocalize.Add(assembly);
			Localization.RegisterForTranslation(types[0]);
		}
	}
}
