using HarmonyLib;

namespace DarknessNotIncluded.DarknessPenalties
{
	public static class MinionMaxSleepLux
	{
		[HarmonyPatch(typeof(SleepChore))]
		[HarmonyPatch("IsDarkAtCell")]
		private static class Patched_SleepChore_IsDarkAtCell
		{
			private static void Postfix(int cell, ref bool __result)
			{
				__result = Grid.LightIntensity[cell] <= maxSleepingLux;
			}
		}

		private static int maxSleepingLux;

		private static Config.Observer configObserver = new Config.Observer((Config config) =>
		{
			maxSleepingLux = config.maxSleepingLux;
		});
	}
}
