using System.Collections.Generic;
using HarmonyLib;
using Klei.AI;
using TUNING;

namespace DarknessNotIncluded.DarknessPenalties
{
	public static class MinionEffects
	{
		[HarmonyPatch(typeof(ModifierSet))]
		[HarmonyPatch("Initialize")]
		private static class Patched_ModifierSet_Initialize
		{
			private static List<AttributeModifier> BuildModifiers(MinionEffectsConfig.EffectConfig effectConfig)
			{
				List<AttributeModifier> list = new List<AttributeModifier>();
				string[] aLL_ATTRIBUTES = DUPLICANTSTATS.ALL_ATTRIBUTES;
				foreach (string text in aLL_ATTRIBUTES)
				{
					if (penalizeStrength || !(text == "Strength"))
					{
						int num = ((text == "Athletics") ? effectConfig.agilityModifier : effectConfig.statsModifier);
						list.Add(new AttributeModifier(text, num));
					}
				}
				return list;
			}

			private static void Postfix(ModifierSet __instance)
			{
				DimEffect = new Effect("Dim", "Dim", "The poor lighting conditions are causing this Duplicant to exhibit poorer coordination than usual.", 0f, show_in_ui: true, trigger_floating_text: false, is_bad: true)
				{
					SelfModifiers = BuildModifiers(dimConfig)
				};
				__instance.effects.Add(DimEffect);
				DarkEffect = new Effect("Dark", "Dark", "This Duplicant can't see past its nose, and is struggling to perform even basic tasks.", 0f, show_in_ui: true, trigger_floating_text: false, is_bad: true)
				{
					SelfModifiers = BuildModifiers(darkConfig)
				};
				__instance.effects.Add(DarkEffect);
				new Config.Observer((Config config) =>
				{
					DimEffect.SelfModifiers = BuildModifiers(dimConfig);
					DarkEffect.SelfModifiers = BuildModifiers(darkConfig);
				});
			}
		}

		[HarmonyPatch(typeof(RationalAi))]
		[HarmonyPatch("InitializeStates")]
		private static class Patched_RationalAi_InitializeStates
		{
			private static void Postfix(RationalAi __instance)
			{
				__instance.alive.ToggleStateMachine((RationalAi.Instance smi) => new LightMonitor.Instance(smi.master));
			}
		}

		public class LightMonitor : GameStateMachine<LightMonitor, LightMonitor.Instance>
		{
			public class LightStates : State
			{
				public State lit;

				public State dim;

				public State dark;
			}

			public new class Instance : GameInstance
			{
				public Effects effects;

				public Instance(IStateMachineTarget master)
					: base(master)
				{
					effects = GetComponent<Effects>();
				}
			}

			public State inactive;

			public LightStates active;

			public BoolParameter isActive;

			public FloatParameter lightLevel;

			public override void InitializeStates(out BaseState default_state)
			{
				default_state = inactive;
				root.Update(CheckActive, UpdateRate.SIM_1000ms);
				inactive.ParamTransition(isActive, active, (Instance smi, bool p) => p);
				active.DefaultState(active.lit).Update(CheckLightLevel, UpdateRate.SIM_1000ms).ParamTransition(isActive, inactive, (Instance smi, bool p) => !p);
				active.lit.ParamTransition(lightLevel, active.dim, (Instance smi, float p) => p > (float)darkConfig.luxThreshold && p <= (float)dimConfig.luxThreshold).ParamTransition(lightLevel, active.dark, (Instance smi, float p) => p <= (float)darkConfig.luxThreshold);
				active.dim.ParamTransition(lightLevel, active.lit, (Instance smi, float p) => p > (float)dimConfig.luxThreshold).ParamTransition(lightLevel, active.dark, (Instance smi, float p) => p <= (float)darkConfig.luxThreshold).Enter((Instance smi) =>
				{
					if (dimConfig.enabled)
					{
						smi.effects.Add(DimEffect.Id, should_save: false);
					}
				})
					.Exit((Instance smi) =>
					{
						smi.effects.Remove(DimEffect.Id);
					});
				active.dark.ParamTransition(lightLevel, active.dim, (Instance smi, float p) => p > (float)darkConfig.luxThreshold && p <= (float)dimConfig.luxThreshold).ParamTransition(lightLevel, active.lit, (Instance smi, float p) => p > (float)dimConfig.luxThreshold).Enter((Instance smi) =>
				{
					if (darkConfig.enabled)
					{
						smi.effects.Add(DarkEffect.Id, should_save: false);
					}
				})
					.Exit((Instance smi) =>
					{
						smi.effects.Remove(DarkEffect.Id);
					});
			}

			private static void CheckActive(Instance smi, float dt)
			{
				MinionIdentity component = smi.GetComponent<MinionIdentity>();
				bool flag = component.IsSleeping() || GameClock.Instance.GetTimeInCycles() < gracePeriodCycles;
				smi.sm.isActive.Set(!flag, smi);
			}

			private static void CheckLightLevel(Instance smi, float dt)
			{
				int num = Grid.PosToCell(smi.gameObject);
				if (Grid.IsValidCell(num))
				{
					smi.sm.lightLevel.Set(Grid.LightIntensity[num], smi);
				}
			}
		}

		private static MinionEffectsConfig.EffectConfig dimConfig;

		private static MinionEffectsConfig.EffectConfig darkConfig;

		private static float gracePeriodCycles;

		private static bool penalizeStrength;

		private static Config.Observer configObserver = new Config.Observer((Config config) =>
		{
			dimConfig = config.minionEffectsConfig[MinionEffectType.Dim];
			darkConfig = config.minionEffectsConfig[MinionEffectType.Dark];
			gracePeriodCycles = config.gracePeriodCycles;
			penalizeStrength = config.penalizeStrength;
		});

		public static Effect DarkEffect;

		public static Effect DimEffect;
	}
}
