using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;

namespace DarknessNotIncluded.DarknessPenalties
{
	public static class MinionSleepDisturbanceTime
	{
		[HarmonyPatch(typeof(SleepChore.States))]
		[HarmonyPatch("InitializeStates")]
		private static class Patched_SleepChore_States_InitializeStates
		{
			private static void Prefix(SleepChore.States __instance)
			{
				__instance.sleep.normal.Enter((SleepChore.StatesInstance smi) =>
				{
					int instanceID = __instance.sleeper.Get(smi).GetInstanceID();
					DISTURBED_TICKS[instanceID] = 0;
				});
			}
		}

		[HarmonyPatch(typeof(SleepChore.StatesInstance))]
		[HarmonyPatch("CheckLightLevel")]
		private static class Patched_SleepChore_StatesInstance_CheckLightLevel
		{
			private static bool Prefix(SleepChore.StatesInstance __instance)
			{
				SleepChore.StatesInstance value = Traverse.Create(__instance).Property("smi").GetValue<SleepChore.StatesInstance>();
				GameObject gameObject = __instance.sm.sleeper.Get(value);
				int cell = Grid.PosToCell(gameObject);
				if (!Grid.IsValidCell(cell))
				{
					return false;
				}
				int instanceID = gameObject.GetInstanceID();
				bool flag = SleepChore.IsDarkAtCell(cell);
				bool flag2 = __instance.sm.needsNightLight.Get(value);
				if (flag == flag2)
				{
					DISTURBED_TICKS[instanceID]++;
				}
				else if (DISTURBED_TICKS[instanceID] > 0)
				{
					DISTURBED_TICKS[instanceID]--;
				}
				if (DISTURBED_TICKS[instanceID] <= sleepingDisturbedTicks)
				{
					return false;
				}
				if (flag2)
				{
					gameObject.Trigger(-1307593733);
				}
				else if (!__instance.IsLoudSleeper() && !__instance.IsGlowStick())
				{
					gameObject.Trigger(-1063113160);
				}
				return false;
			}
		}

		private static Dictionary<int, int> DISTURBED_TICKS = new Dictionary<int, int>();

		private static int sleepingDisturbedTicks;

		private static Config.Observer configObserver = new Config.Observer((Config config) =>
		{
			sleepingDisturbedTicks = config.sleepingDisturbedTicks;
		});
	}
}
