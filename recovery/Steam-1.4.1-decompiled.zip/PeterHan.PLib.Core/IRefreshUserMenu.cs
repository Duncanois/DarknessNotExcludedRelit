namespace PeterHan.PLib.Core
{
	internal interface IRefreshUserMenu
	{
		void OnRefreshUserMenu();
	}
}
