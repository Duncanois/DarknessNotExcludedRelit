using System;

namespace PeterHan.PLib.Core
{
	internal static class AutoUnbox<T> where T : struct
	{
		private delegate object BoxData(T raw);

		private delegate T UnboxData(object boxed);

		private static readonly BoxData DATA_BOX;

		private static readonly UnboxData DATA_UNBOX;

		static AutoUnbox()
		{
			Type type;
			try
			{
				type = typeof(Tag).Assembly.GetType("Boxed`1");
			}
			catch
			{
				type = null;
			}
			if (type != null && type.ContainsGenericParameters)
			{
				Type type2 = type.MakeGenericType(typeof(T));
				DATA_UNBOX = type2.CreateStaticDelegate<UnboxData>("Unbox", new Type[1] { typeof(object) });
				DATA_BOX = type2.CreateStaticDelegate<BoxData>("Get", new Type[1] { typeof(T) });
			}
			else
			{
				DATA_BOX = null;
				DATA_UNBOX = null;
			}
		}

		public static object Box(T data)
		{
			if (DATA_BOX != null)
			{
				return DATA_BOX(data);
			}
			return data;
		}

		public static bool Unbox(object data, out T result)
		{
			bool result2 = true;
			if (DATA_UNBOX != null)
			{
				result = DATA_UNBOX(data);
			}
			else if (data is T val)
			{
				result = val;
			}
			else
			{
				result = default;
				result2 = false;
			}
			return result2;
		}
	}
}
