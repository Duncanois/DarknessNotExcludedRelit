using System;

namespace PeterHan.PLib.Core
{
	internal static class PStateMachines
	{
		public static GameStateMachine<T, I, IStateMachineTarget, object>.State CreateState<T, I>(this GameStateMachine<T, I> sm, string name) where T : GameStateMachine<T, I, IStateMachineTarget, object> where I : GameStateMachine<T, I, IStateMachineTarget, object>.GameInstance
		{
			GameStateMachine<T, I, IStateMachineTarget, object>.State state = new GameStateMachine<T, I, IStateMachineTarget, object>.State();
			if (string.IsNullOrEmpty(name))
			{
				name = "State";
			}
			if (sm == null)
			{
				throw new ArgumentNullException("sm");
			}
			state.defaultState = sm.GetDefaultState();
			sm.CreateStates(state);
			sm.BindState(sm.root, state, name);
			return state;
		}

		public static GameStateMachine<T, I, M, object>.State CreateState<T, I, M>(this GameStateMachine<T, I, M> sm, string name) where T : GameStateMachine<T, I, M, object> where I : GameStateMachine<T, I, M, object>.GameInstance where M : IStateMachineTarget
		{
			GameStateMachine<T, I, M, object>.State state = new GameStateMachine<T, I, M, object>.State();
			if (string.IsNullOrEmpty(name))
			{
				name = "State";
			}
			if (sm == null)
			{
				throw new ArgumentNullException("sm");
			}
			state.defaultState = sm.GetDefaultState();
			sm.CreateStates(state);
			sm.BindState(sm.root, state, name);
			return state;
		}

		public static void ClearEnterActions(this StateMachine.BaseState state)
		{
			state?.enterActions.Clear();
		}

		public static void ClearExitActions(this StateMachine.BaseState state)
		{
			state?.exitActions.Clear();
		}

		public static void ClearTransitions(this StateMachine.BaseState state)
		{
			state?.transitions.Clear();
		}
	}
}
