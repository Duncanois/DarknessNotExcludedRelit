using STRINGS;

namespace PeterHan.PLib.Core
{
	internal static class PLibStrings
	{
		public static LocString BUTTON_MANUAL = "MANUAL CONFIG";

		public static LocString BUTTON_RESET = "RESET TO DEFAULT";

		public static LocString BUTTON_OK = STRINGS.UI.FRONTEND.OPTIONS_SCREEN.BACK;

		public static LocString BUTTON_OPTIONS = STRINGS.UI.FRONTEND.MAINMENU.OPTIONS;

		public static LocString DIALOG_TITLE = "Options for {0}";

		public static LocString KEY_HOME = "Home";

		public static LocString KEY_END = "End";

		public static LocString KEY_DELETE = "Delete";

		public static LocString KEY_PAGEUP = "Page Up";

		public static LocString KEY_PAGEDOWN = "Page Down";

		public static LocString KEY_SYSRQ = "SysRq";

		public static LocString KEY_PRTSCREEN = "Print Screen";

		public static LocString KEY_PAUSE = "Pause";

		public static LocString KEY_ARROWLEFT = "Left Arrow";

		public static LocString KEY_ARROWUP = "Up Arrow";

		public static LocString KEY_ARROWRIGHT = "Right Arrow";

		public static LocString KEY_ARROWDOWN = "Down Arrow";

		public static LocString KEY_CATEGORY_TITLE = "Mods";

		public static LocString LABEL_B = "B";

		public static LocString LABEL_G = "G";

		public static LocString LABEL_R = "R";

		public static LocString MOD_ASSEMBLY_VERSION = "Assembly Version: {0}";

		public static LocString MOD_HOMEPAGE = "Mod Homepage";

		public static LocString MOD_VERSION = "Mod Version: {0}";

		public static LocString RESTART_CANCEL = STRINGS.UI.FRONTEND.MOD_DIALOGS.RESTART.CANCEL;

		public static LocString RESTART_OK = STRINGS.UI.FRONTEND.MOD_DIALOGS.RESTART.OK;

		public static LocString MAINMENU_UPDATE = "\n\n<color=#FFCC00>{0:D} mods may be out of date</color>";

		public static LocString MAINMENU_UPDATE_1 = "\n\n<color=#FFCC00>1 mod may be out of date</color>";

		public static LocString OUTDATED_TOOLTIP = "This mod is out of date!\nNew version: <b>{0}</b>\n\nUpdate local mods manually, or use <b>Mod Updater</b> to force update Steam mods";

		public static LocString OUTDATED_WARNING = "<b><style=\"logic_off\">Outdated!</style></b>";

		public static LocString RESTART_REQUIRED = "Oxygen Not Included must be restarted for these options to take effect.";

		public static LocString TOOLTIP_BLUE = "Blue";

		public static LocString TOOLTIP_CANCEL = "Discard changes.";

		public static LocString TOOLTIP_GREEN = "Green";

		public static LocString TOOLTIP_HOMEPAGE = "Visit the mod's website.";

		public static LocString TOOLTIP_HUE = "Hue";

		public static LocString TOOLTIP_MANUAL = "Opens the folder containing the full mod configuration.";

		public static LocString TOOLTIP_NEXT = "Next";

		public static LocString TOOLTIP_OK = "Save these options. Some mods may require a restart for the options to take effect.";

		public static LocString TOOLTIP_PREVIOUS = "Previous";

		public static LocString TOOLTIP_RED = "Red";

		public static LocString TOOLTIP_RESET = "Resets the mod configuration to default values.";

		public static LocString TOOLTIP_SATURATION = "Saturation";

		public static LocString TOOLTIP_TOGGLE = "Show or hide this options category";

		public static LocString TOOLTIP_VALUE = "Value";

		public static LocString TOOLTIP_VERSION = "The currently installed version of this mod.\n\nCompare this version with the mod's Release Notes to see if it is outdated.";
	}
}
