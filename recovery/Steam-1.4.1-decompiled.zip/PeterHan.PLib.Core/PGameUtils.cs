using System;
using PeterHan.PLib.Detours;
using UnityEngine;

namespace PeterHan.PLib.Core
{
	internal static class PGameUtils
	{
		private delegate void CreateSoundDelegate(AudioSheets instance, string file_name, string anim_name, string type, float min_interval, string sound_name, int frame, string dlcId);

		private delegate void InfoRefreshFunction(SimpleInfoScreen instance, bool force);

		private delegate bool IsDLCEnabledFunction(string name);

		private static readonly DetouredMethod<CreateSoundDelegate> CREATE_SOUND = typeof(AudioSheets).DetourLazy<CreateSoundDelegate>("CreateSound");

		private static readonly DetouredMethod<InfoRefreshFunction> REFRESH_INFO_SCREEN = typeof(SimpleInfoScreen).DetourLazy<InfoRefreshFunction>("Refresh");

		private static readonly DetouredMethod<IsDLCEnabledFunction> CHECK_SUBSCRIPTION = typeof(DlcManager).DetourLazy<IsDLCEnabledFunction>("CheckPlatformSubscription");

		private static readonly DetouredMethod<IsDLCEnabledFunction> IS_CONTENT_ENABLED = typeof(DlcManager).DetourLazy<IsDLCEnabledFunction>("IsContentSettingEnabled");

		public static void CenterAndSelect(KMonoBehaviour entity)
		{
			if (entity != null && entity.TryGetComponent<KSelectable>(out var component))
			{
				SelectTool.Instance.SelectAndFocus(entity.transform.position, component, Vector3.zero);
			}
		}

		public static void CopySoundsToAnim(string dstAnim, string srcAnim)
		{
			if (string.IsNullOrEmpty(dstAnim))
			{
				throw new ArgumentNullException("dstAnim");
			}
			if (string.IsNullOrEmpty(srcAnim))
			{
				throw new ArgumentNullException("srcAnim");
			}
			if (Assets.GetAnim(dstAnim) != null)
			{
				GameAudioSheets gameAudioSheets = GameAudioSheets.Get();
				try
				{
					foreach (AudioSheet sheet in gameAudioSheets.sheets)
					{
						AudioSheet.SoundInfo[] soundInfos = sheet.soundInfos;
						int num = soundInfos.Length;
						for (int i = 0; i < num; i++)
						{
							AudioSheet.SoundInfo soundInfo = soundInfos[i];
							if (IsDLCOwned(soundInfo.RequiredDlcId) && soundInfo.File == srcAnim)
							{
								CreateAllSounds(gameAudioSheets, dstAnim, soundInfo, sheet.defaultType);
							}
						}
					}
					return;
				}
				catch (Exception thrown)
				{
					PUtil.LogWarning("Unable to copy sound files from {0} to {1}:".F(srcAnim, dstAnim));
					PUtil.LogExcWarn(thrown);
					return;
				}
			}
			PUtil.LogWarning("Destination animation \"{0}\" not found!".F(dstAnim));
		}

		private static int CreateSound(AudioSheets sheet, string file, string type, AudioSheet.SoundInfo info, string sound, int frame)
		{
			int result = 0;
			if (!string.IsNullOrEmpty(sound) && CREATE_SOUND != null)
			{
				CREATE_SOUND.Invoke(sheet, file, info.Anim, type, info.MinInterval, sound, frame, info.RequiredDlcId);
				result = 1;
			}
			return result;
		}

		private static void CreateAllSounds(AudioSheets sheet, string animFile, AudioSheet.SoundInfo info, string defaultType)
		{
			string text = info.Type;
			if (string.IsNullOrEmpty(text))
			{
				text = defaultType;
			}
			_ = CreateSound(sheet, animFile, text, info, info.Name0, info.Frame0) + CreateSound(sheet, animFile, text, info, info.Name1, info.Frame1) + CreateSound(sheet, animFile, text, info, info.Name2, info.Frame2) + CreateSound(sheet, animFile, text, info, info.Name3, info.Frame3) + CreateSound(sheet, animFile, text, info, info.Name4, info.Frame4) + CreateSound(sheet, animFile, text, info, info.Name5, info.Frame5) + CreateSound(sheet, animFile, text, info, info.Name6, info.Frame6) + CreateSound(sheet, animFile, text, info, info.Name7, info.Frame7) + CreateSound(sheet, animFile, text, info, info.Name8, info.Frame8) + CreateSound(sheet, animFile, text, info, info.Name9, info.Frame9) + CreateSound(sheet, animFile, text, info, info.Name10, info.Frame10);
			CreateSound(sheet, animFile, text, info, info.Name11, info.Frame11);
		}

		public static void CreatePopup(Sprite image, string text, int cell)
		{
			CreatePopup(image, text, Grid.CellToPosCBC(cell, Grid.SceneLayer.Move));
		}

		public static void CreatePopup(Sprite image, string text, Vector3 position)
		{
			PopFXManager.Instance.SpawnFX(image, text, null, position);
		}

		public static EventSystem.IntraObjectHandler<T> CreateUserMenuHandler<T>() where T : Component, IRefreshUserMenu
		{
			return (Action<T, object>)((T target, object ignore) =>
			{
				target.OnRefreshUserMenu();
			});
		}

		public static ObjectLayer GetObjectLayer(string name, ObjectLayer defValue)
		{
			if (!Enum.TryParse<ObjectLayer>(name, out var result))
			{
				return defValue;
			}
			return result;
		}

		public static void HighlightEntity(Component entity, Color highlightColor)
		{
			if (entity != null && entity.TryGetComponent<KAnimControllerBase>(out var component))
			{
				component.HighlightColour = highlightColor;
			}
		}

		public static bool IsDLCOwned(string name)
		{
			if (!string.IsNullOrEmpty(name))
			{
				if (CHECK_SUBSCRIPTION.Invoke(name))
				{
					return IS_CONTENT_ENABLED.Invoke(name);
				}
				return false;
			}
			return true;
		}

		public static void PlaySound(string name, Vector3 position)
		{
			SoundEvent.PlayOneShot(GlobalAssets.GetSound(name), position);
		}

		public static void RefreshInfoScreen(this SimpleInfoScreen screen, bool force = false)
		{
			if (screen != null)
			{
				REFRESH_INFO_SCREEN.Invoke(screen, force);
			}
		}

		public static void SaveMods()
		{
			Global.Instance.modManager.Save();
		}
	}
}
