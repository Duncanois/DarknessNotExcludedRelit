using HarmonyLib;
using TUNING;

namespace DarknessNotIncluded.LightBonuses
{
	public static class DecorBonusThreshold
	{
		[HarmonyPatch(typeof(DecorProvider))]
		[HarmonyPatch("GetLightDecorBonus")]
		private static class Patched_DecorProvider_GetLightDecorBonus
		{
			private static void Postfix(int cell, ref int __result)
			{
				__result = ((Grid.LightIntensity[cell] >= decorBonusThresholdLux) ? DECOR.LIT_BONUS : 0);
			}
		}

		private static int decorBonusThresholdLux;

		private static Config.Observer configObserver = new Config.Observer((Config config) =>
		{
			decorBonusThresholdLux = config.decorBonusThresholdLux;
		});
	}
}
