using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;
using TUNING;

namespace DarknessNotIncluded.LightBonuses
{
	public static class MinionLitEfficiencyMultiplier
	{
		[HarmonyPatch(typeof(Workable))]
		[HarmonyPatch("GetEfficiencyMultiplier")]
		private static class Workable_GetEfficiencyMultiplier_Patch
		{
			private static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
			{
				MethodInfo method = typeof(Grid.LightIntensityIndexer).GetMethod("get_Item");
				List<CodeInstruction> list = new List<CodeInstruction>(instructions);
				for (int i = 1; i < list.Count - 1; i++)
				{
					CodeInstruction codeInstruction = list[i];
					CodeInstruction codeInstruction2 = list[i + 1];
					if (codeInstruction.opcode == OpCodes.Ldfld && codeInstruction.operand.ToString() == "System.Int32 NO_LIGHT" && codeInstruction2.opcode == OpCodes.Ble_S)
					{
						list[i] = CodeInstruction.Call(typeof(Workable_GetEfficiencyMultiplier_Patch), "GetLitWorkspaceLuxForPatch");
						return list;
					}
				}
				Debug.LogError("DarknessNotExcluded: Failed to patch Workable.GetEfficiencyMultiplier()");
				return list;
			}

			private static int GetLitWorkspaceLuxForPatch(DUPLICANTSTATS.LIGHT dummy)
			{
				return litWorkspaceLux - 1;
			}
		}

		private static int litWorkspaceLux;

		private static Config.Observer configObserver = new Config.Observer((Config config) =>
		{
			litWorkspaceLux = config.litWorkspaceLux;
		});
	}
}
