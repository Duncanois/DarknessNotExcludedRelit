using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;

namespace DarknessNotIncluded.DuplicantLights
{
	public static class MinionLighting
	{
		[HarmonyPatch(typeof(MinionConfig))]
		[HarmonyPatch("CreatePrefab")]
		private static class Patched_MinionConfig_CreatePrefab
		{
			private static void Postfix(GameObject __result)
			{
				__result.AddOrGet<MinionLights>();
			}
		}

		[HarmonyPatch(typeof(MinionIdentity), "OnPrefabInit")]
		private static class Patched_MinionIdentity_OnPrefabInit
		{
			private static void Postfix(MinionIdentity __instance)
			{
				__instance.gameObject.AddOrGet<MinionLights>();
			}
		}

		[HarmonyPatch(typeof(BionicMinionConfig), "CreatePrefab")]
		private static class Patched_BionicMinionConfig_CreatePrefab
		{
			private static void Postfix(GameObject __result)
			{
				__result.AddOrGet<MinionLights>();
			}
		}

		public class MinionLights : Behavior.UnitLights
		{
			[MyCmpGet]
			private MinionIdentity minion;

			[MyCmpGet]
			private MinionResume resume;

			private static readonly Tag MINION_SELECT_PREVIEW_TAG = new Tag("MinionSelectPreview");

			protected override MinionLightType GetActiveLightType(MinionLightingConfig minionLightingConfig)
			{
				minionLightingConfig = EnsureLightingConfig(minionLightingConfig);
				if (minionLightingConfig == null)
				{
					return MinionLightType.None;
				}
				MinionLightType minionLightType = GetLightTypeForCurrentState(minionLightingConfig);
				if (minionLightType == MinionLightType.None)
				{
					return minionLightType;
				}
				LightConfig lightConfig = minionLightingConfig.Get(minionLightType);
				if (lightConfig == null || !lightConfig.enabled)
				{
					minionLightType = MinionLightType.Intrinsic;
				}
				lightConfig = minionLightingConfig.Get(minionLightType);
				if (lightConfig == null || !lightConfig.enabled)
				{
					minionLightType = MinionLightType.None;
				}
				return minionLightType;
			}

			private MinionLightingConfig EnsureLightingConfig(MinionLightingConfig cfg)
			{
				if (cfg != null)
				{
					return cfg;
				}
				Config instance = Config.instance;
				if (instance != null && instance.minionLightingConfig != null)
				{
					return instance.minionLightingConfig;
				}
				return new MinionLightingConfig();
			}

			private Equipment SafeGetEquipment()
			{
				if (minion == null)
				{
					return null;
				}
				try
				{
					return minion.GetEquipment();
				}
				catch
				{
					return null;
				}
			}

			private MinionLightType GetLightTypeForCurrentState(MinionLightingConfig minionLightingConfig)
			{
				if (gameObject != null && gameObject.HasTag(MINION_SELECT_PREVIEW_TAG))
				{
					return MinionLightType.Intrinsic;
				}
				if (minionLightingConfig == null)
				{
					return MinionLightType.None;
				}
				if (minion == null)
				{
					return MinionLightType.None;
				}
				if (!minion.isSpawned)
				{
					return MinionLightType.None;
				}
				if (minion.IsSleeping())
				{
					return MinionLightType.None;
				}
				string text = ((resume != null) ? resume.CurrentHat : null);
				Equipment equipment = SafeGetEquipment();
				Equippable equippable = null;
				if (equipment != null)
				{
					AssignableSlotInstance slot = equipment.GetSlot(Db.Get().AssignableSlots.Suit);
					equippable = ((slot != null) ? (slot.assignable as Equippable) : null);
				}
				KPrefabID kPrefabID = ((equippable != null) ? equippable.GetComponent<KPrefabID>() : null);
				List<MinionLightType> list = new List<MinionLightType>();
				if (kPrefabID != null && equippable.isEquipped)
				{
					if (kPrefabID.HasTag(GameTags.AtmoSuit))
					{
						list.Add(MinionLightType.AtmoSuit);
					}
					if (kPrefabID.HasTag(GameTags.JetSuit))
					{
						list.Add(MinionLightType.JetSuit);
					}
					if (kPrefabID.HasTag(GameTags.LeadSuit))
					{
						list.Add(MinionLightType.LeadSuit);
					}
				}
				KPrefabID component = minion.GetComponent<KPrefabID>();
				if (component != null && (component.HasTag(new Tag("BionicDuplicant")) || component.HasTag(new Tag("BionicMinion")) || component.HasTag(new Tag("Bionic"))))
				{
					list.Add(MinionLightType.Bionic);
				}
				if (!string.IsNullOrEmpty(text))
				{
					if (text.StartsWith("hat_role_mining"))
					{
						switch (text)
						{
						case "hat_role_mining1":
							list.Add(MinionLightType.Mining1);
							break;
						case "hat_role_mining2":
							list.Add(MinionLightType.Mining2);
							break;
						case "hat_role_mining3":
							list.Add(MinionLightType.Mining3);
							break;
						case "hat_role_mining4":
							list.Add(MinionLightType.Mining4);
							break;
						default:
							list.Add(MinionLightType.Mining4);
							break;
						}
					}
					else if (text.StartsWith("hat_role_research"))
					{
						list.Add(MinionLightType.Science);
					}
					else if (text.StartsWith("hat_role_astronaut"))
					{
						list.Add(MinionLightType.Rocketry);
					}
				}
				list = list.FindAll((MinionLightType type) => minionLightingConfig.Get(type)?.enabled ?? false);
				list.Sort((MinionLightType a, MinionLightType b) =>
				{
					LightConfig lightConfig2 = minionLightingConfig.Get(a);
					LightConfig lightConfig3 = minionLightingConfig.Get(b);
					int value = lightConfig2?.lux ?? 0;
					return (lightConfig3?.lux ?? 0).CompareTo(value);
				});
				LightConfig lightConfig = minionLightingConfig.Get(MinionLightType.Intrinsic);
				if (list.Count > 0)
				{
					return list[0];
				}
				if (lightConfig != null && lightConfig.enabled)
				{
					return MinionLightType.Intrinsic;
				}
				return MinionLightType.None;
			}
		}
	}
}
