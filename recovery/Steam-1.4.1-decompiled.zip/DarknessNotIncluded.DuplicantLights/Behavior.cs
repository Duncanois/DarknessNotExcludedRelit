using System;
using DarknessNotIncluded.Exploration;

namespace DarknessNotIncluded.DuplicantLights
{
	public static class Behavior
	{
		public abstract class UnitLights : KMonoBehaviour, ISim33ms
		{
			private static bool disableLightsInBedrooms;

			private static bool disableLightsInLitAreas;

			private static int litWorkspaceLux;

			private static MinionLightingConfig minionLightingConfig;

			private static bool occludeVisibilityByWalls;

			private static Config.Observer configObserver = new Config.Observer((Config config) =>
			{
				disableLightsInBedrooms = config.disableDupeLightsInBedrooms;
				disableLightsInLitAreas = config.disableDupeLightsInLitAreas;
				litWorkspaceLux = config.litWorkspaceLux;
				minionLightingConfig = config.minionLightingConfig;
				occludeVisibilityByWalls = config.occludeVisibilityByWalls;
			});

			[MyCmpGet]
			private GridVisibility gridVisibility;

			private MinionLightType currentLightType = MinionLightType.None;

			public Light2D Light { get; set; }

			protected override void OnPrefabInit()
			{
				base.OnPrefabInit();
				Light = gameObject.AddComponent<Light2D>();
				gridVisibility = gameObject.AddOrGet<GridVisibility>();
				Config.ObserveFor(this, (Config config) =>
				{
					UpdateLights(force: true);
				});
			}

			protected override void OnSpawn()
			{
				base.OnSpawn();
				UpdateLights();
			}

			public void Sim33ms(float dt)
			{
				UpdateLights();
			}

			private void UpdateLights(bool force = false)
			{
				if (gameObject == null)
				{
					return;
				}
				MinionLightType minionLightType;
				try
				{
					minionLightType = GetActiveLightType(UnitLights.minionLightingConfig);
				}
				catch (Exception arg)
				{
					Debug.LogWarning($"[DarknessNotIncluded] UnitLights.GetActiveLightType threw: {arg}");
					return;
				}
				MinionLightingConfig minionLightingConfig = UnitLights.minionLightingConfig;
				if (minionLightingConfig == null)
				{
					return;
				}
				LightConfig lightConfig = minionLightingConfig.Get(minionLightType);
				if (lightConfig == null)
				{
					return;
				}
				if (gridVisibility != null)
				{
					try
					{
						gridVisibility.SetRadius(lightConfig.reveal);
						int originCell = Grid.PosToCell(gameObject);
						VisibilityUtils.RevealArea(originCell, gridVisibility.radius, gridVisibility.innerRadius);
					}
					catch (Exception arg2)
					{
						Debug.LogWarning($"[DarknessNotIncluded] UnitLights reveal threw for '{gameObject.name}': {arg2}");
					}
				}
				if (disableLightsInBedrooms && minionLightType != MinionLightType.None)
				{
					try
					{
						if (MinionRoomState.SleepersInSameRoom(gameObject))
						{
							minionLightType = MinionLightType.None;
						}
					}
					catch (Exception arg3)
					{
						Debug.LogWarning($"[DarknessNotIncluded] UnitLights bedroom check threw: {arg3}");
					}
				}
				if (disableLightsInLitAreas && minionLightType != MinionLightType.None)
				{
					try
					{
						int num = Grid.PosToCell(gameObject);
						int num2 = (Grid.IsValidCell(num) ? Grid.LightIntensity[num] : 0);
						int num3 = ((Light != null && Light.enabled) ? Light.Lux : 0);
						int num4 = Math.Max(0, num2 - num3);
						int num5 = litWorkspaceLux;
						if (num4 >= num5)
						{
							minionLightType = MinionLightType.None;
						}
					}
					catch (Exception arg4)
					{
						Debug.LogWarning($"[DarknessNotIncluded] UnitLights lit-area check threw: {arg4}");
					}
				}
				SetLightType(minionLightType, force);
			}

			private void SetLightType(MinionLightType lightType, bool force)
			{
				if (lightType == currentLightType && !force)
				{
					return;
				}
				MinionLightingConfig minionLightingConfig = UnitLights.minionLightingConfig;
				if (minionLightingConfig == null)
				{
					return;
				}
				LightConfig lightConfig = minionLightingConfig.Get(lightType);
				if (lightConfig == null)
				{
					return;
				}
				currentLightType = lightType;
				try
				{
					lightConfig.ConfigureLight(Light);
				}
				catch (Exception arg)
				{
					Debug.LogWarning($"[DarknessNotIncluded] ConfigureLight threw for '{gameObject.name}': {arg}");
				}
			}

			protected abstract MinionLightType GetActiveLightType(MinionLightingConfig minionLightingConfig);
		}
	}
}
