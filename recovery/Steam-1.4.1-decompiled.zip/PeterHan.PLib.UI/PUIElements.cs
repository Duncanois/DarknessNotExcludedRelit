using System;
using PeterHan.PLib.Core;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace PeterHan.PLib.UI
{
	internal sealed class PUIElements
	{
		internal static LocText AddLocText(GameObject parent, TextStyleSetting setting = null)
		{
			if (parent == null)
			{
				throw new ArgumentNullException("parent");
			}
			bool activeSelf = parent.activeSelf;
			parent.SetActive(value: false);
			LocText locText = parent.AddComponent<LocText>();
			UIDetours.LOCTEXT_KEY.Set(locText, string.Empty);
			UIDetours.LOCTEXT_STYLE.Set(locText, setting ?? PUITuning.Fonts.UIDarkStyle);
			parent.SetActive(activeSelf);
			return locText;
		}

		public static GameObject AddSizeFitter(GameObject uiElement, bool dynamic = false, ContentSizeFitter.FitMode modeHoriz = ContentSizeFitter.FitMode.PreferredSize, ContentSizeFitter.FitMode modeVert = ContentSizeFitter.FitMode.PreferredSize)
		{
			if (uiElement == null)
			{
				throw new ArgumentNullException("uiElement");
			}
			if (dynamic)
			{
				ContentSizeFitter contentSizeFitter = uiElement.AddOrGet<ContentSizeFitter>();
				contentSizeFitter.horizontalFit = modeHoriz;
				contentSizeFitter.verticalFit = modeVert;
				contentSizeFitter.enabled = true;
			}
			else
			{
				FitSizeNow(uiElement, modeHoriz, modeVert);
			}
			return uiElement;
		}

		public static GameObject CreateUI(GameObject parent, string name, bool canvas = true, PUIAnchoring horizAnchor = PUIAnchoring.Stretch, PUIAnchoring vertAnchor = PUIAnchoring.Stretch)
		{
			GameObject gameObject = new GameObject(name);
			if (parent != null)
			{
				gameObject.SetParent(parent);
			}
			gameObject.AddOrGet<RectTransform>().localScale = Vector3.one;
			SetAnchors(gameObject, horizAnchor, vertAnchor);
			if (canvas)
			{
				gameObject.AddComponent<CanvasRenderer>();
			}
			gameObject.layer = LayerMask.NameToLayer("UI");
			return gameObject;
		}

		private static void DoNothing()
		{
		}

		private static void FitSizeNow(GameObject uiElement, ContentSizeFitter.FitMode modeHoriz, ContentSizeFitter.FitMode modeVert)
		{
			float val = 0f;
			float val2 = 0f;
			if (uiElement == null)
			{
				throw new ArgumentNullException("uiElement");
			}
			ILayoutElement[] components = uiElement.GetComponents<ILayoutElement>();
			LayoutElement layoutElement = uiElement.AddOrGet<LayoutElement>();
			RectTransform rectTransform = uiElement.AddOrGet<RectTransform>();
			ILayoutElement[] array = components;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].CalculateLayoutInputHorizontal();
			}
			if (modeHoriz != ContentSizeFitter.FitMode.Unconstrained)
			{
				array = components;
				foreach (ILayoutElement layoutElement2 in array)
				{
					switch (modeHoriz)
					{
					case ContentSizeFitter.FitMode.MinSize:
						val = Math.Max(val, layoutElement2.minWidth);
						break;
					case ContentSizeFitter.FitMode.PreferredSize:
						val = Math.Max(val, layoutElement2.preferredWidth);
						break;
					}
				}
				val = Math.Max(val, layoutElement.minWidth);
				rectTransform.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, val);
				layoutElement.minWidth = val;
				layoutElement.flexibleWidth = 0f;
			}
			array = components;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].CalculateLayoutInputVertical();
			}
			if (modeVert == ContentSizeFitter.FitMode.Unconstrained)
			{
				return;
			}
			array = components;
			foreach (ILayoutElement layoutElement3 in array)
			{
				switch (modeVert)
				{
				case ContentSizeFitter.FitMode.MinSize:
					val2 = Math.Max(val2, layoutElement3.minHeight);
					break;
				case ContentSizeFitter.FitMode.PreferredSize:
					val2 = Math.Max(val2, layoutElement3.preferredHeight);
					break;
				}
			}
			val2 = Math.Max(val2, layoutElement.minHeight);
			rectTransform.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, val2);
			layoutElement.minHeight = val2;
			layoutElement.flexibleHeight = 0f;
		}

		public static GameObject SetAnchors(GameObject uiElement, PUIAnchoring horizAnchor, PUIAnchoring vertAnchor)
		{
			Vector2 anchorMax = default;
			Vector2 anchorMin = default;
			Vector2 pivot = default;
			if (uiElement == null)
			{
				throw new ArgumentNullException("uiElement");
			}
			RectTransform rectTransform = uiElement.rectTransform();
			switch (horizAnchor)
			{
			case PUIAnchoring.Center:
				anchorMin.x = 0.5f;
				anchorMax.x = 0.5f;
				pivot.x = 0.5f;
				break;
			case PUIAnchoring.End:
				anchorMin.x = 1f;
				anchorMax.x = 1f;
				pivot.x = 1f;
				break;
			case PUIAnchoring.Stretch:
				anchorMin.x = 0f;
				anchorMax.x = 1f;
				pivot.x = 0.5f;
				break;
			default:
				anchorMin.x = 0f;
				anchorMax.x = 0f;
				pivot.x = 0f;
				break;
			}
			switch (vertAnchor)
			{
			case PUIAnchoring.Center:
				anchorMin.y = 0.5f;
				anchorMax.y = 0.5f;
				pivot.y = 0.5f;
				break;
			case PUIAnchoring.End:
				anchorMin.y = 1f;
				anchorMax.y = 1f;
				pivot.y = 1f;
				break;
			case PUIAnchoring.Stretch:
				anchorMin.y = 0f;
				anchorMax.y = 1f;
				pivot.y = 0.5f;
				break;
			default:
				anchorMin.y = 0f;
				anchorMax.y = 0f;
				pivot.y = 0f;
				break;
			}
			rectTransform.anchorMax = anchorMax;
			rectTransform.anchorMin = anchorMin;
			rectTransform.pivot = pivot;
			rectTransform.anchoredPosition = Vector2.zero;
			rectTransform.offsetMax = Vector2.zero;
			rectTransform.offsetMin = Vector2.zero;
			return uiElement;
		}

		public static GameObject SetAnchorOffsets(GameObject uiElement, RectOffset border)
		{
			return SetAnchorOffsets(uiElement, border.left, border.right, border.top, border.bottom);
		}

		public static GameObject SetAnchorOffsets(GameObject uiElement, float left, float right, float top, float bottom)
		{
			if (uiElement == null)
			{
				throw new ArgumentNullException("uiElement");
			}
			RectTransform rectTransform = uiElement.rectTransform();
			rectTransform.offsetMin = new Vector2(left, bottom);
			rectTransform.offsetMax = new Vector2(0f - right, 0f - top);
			return uiElement;
		}

		public static GameObject SetText(GameObject uiElement, string text)
		{
			if (uiElement == null)
			{
				throw new ArgumentNullException("uiElement");
			}
			TextMeshProUGUI componentInChildren = uiElement.GetComponentInChildren<TextMeshProUGUI>();
			if (componentInChildren != null)
			{
				componentInChildren.SetText(text ?? string.Empty);
			}
			return uiElement;
		}

		public static GameObject SetToolTip(GameObject uiElement, string tooltip)
		{
			if (uiElement == null)
			{
				throw new ArgumentNullException("uiElement");
			}
			if (!string.IsNullOrEmpty(tooltip))
			{
				uiElement.AddOrGet<ToolTip>().toolTip = tooltip;
			}
			return uiElement;
		}

		public static ConfirmDialogScreen ShowConfirmDialog(GameObject parent, string message, System.Action onConfirm, System.Action onCancel = null, string confirmText = null, string cancelText = null)
		{
			if (parent == null)
			{
				parent = PDialog.GetParentObject();
			}
			GameObject gameObject = Util.KInstantiateUI(ScreenPrefabs.Instance.ConfirmDialogScreen.gameObject, parent);
			if (gameObject.TryGetComponent<ConfirmDialogScreen>(out var component))
			{
				UIDetours.POPUP_CONFIRM.Invoke(component, message, onConfirm, onCancel ?? new System.Action(DoNothing), null, null, null, confirmText, cancelText);
				gameObject.SetActive(value: true);
				return component;
			}
			return null;
		}

		public static ConfirmDialogScreen ShowMessageDialog(GameObject parent, string message)
		{
			return ShowConfirmDialog(parent, message, DoNothing);
		}

		private PUIElements()
		{
		}
	}
}
