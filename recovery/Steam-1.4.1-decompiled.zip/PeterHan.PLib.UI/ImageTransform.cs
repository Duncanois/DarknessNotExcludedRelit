using System;

namespace PeterHan.PLib.UI
{
	[Flags]
	internal enum ImageTransform : uint
	{
		None = 0u,
		FlipHorizontal = 1u,
		FlipVertical = 2u,
		Rotate90 = 4u,
		Rotate180 = 8u,
		Rotate270 = Rotate90 | Rotate180
	}
}
