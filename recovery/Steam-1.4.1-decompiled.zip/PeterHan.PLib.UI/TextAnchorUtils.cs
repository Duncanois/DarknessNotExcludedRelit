using UnityEngine;

namespace PeterHan.PLib.UI
{
	internal static class TextAnchorUtils
	{
		public static bool IsLeft(this TextAnchor anchor)
		{
			if (anchor != TextAnchor.UpperLeft && anchor != TextAnchor.MiddleLeft)
			{
				return anchor == TextAnchor.LowerLeft;
			}
			return true;
		}

		public static bool IsLower(this TextAnchor anchor)
		{
			if (anchor != TextAnchor.LowerCenter && anchor != TextAnchor.LowerLeft)
			{
				return anchor == TextAnchor.LowerRight;
			}
			return true;
		}

		public static bool IsRight(this TextAnchor anchor)
		{
			if (anchor != TextAnchor.UpperRight && anchor != TextAnchor.MiddleRight)
			{
				return anchor == TextAnchor.LowerRight;
			}
			return true;
		}

		public static bool IsUpper(this TextAnchor anchor)
		{
			if (anchor != TextAnchor.UpperCenter && anchor != TextAnchor.UpperLeft)
			{
				return anchor == TextAnchor.UpperRight;
			}
			return true;
		}

		public static TextAnchor MirrorHorizontal(this TextAnchor anchor)
		{
			return (TextAnchor)(3 * ((int)anchor / 3) + 2 - (int)anchor % 3);
		}

		public static TextAnchor MirrorVertical(this TextAnchor anchor)
		{
			return (TextAnchor)(6 - 3 * ((int)anchor / 3) + (int)anchor % 3);
		}
	}
}
