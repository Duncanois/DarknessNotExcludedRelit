using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using PeterHan.PLib.Core;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace PeterHan.PLib.UI
{
	internal static class PUIUtils
	{
		private static void AddComponentText(StringBuilder result, Component component)
		{
			FieldInfo[] fields = component.GetType().GetFields(BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
			if (component is TMP_Text tMP_Text)
			{
				result.AppendFormat(", Text={0}, Color={1}, Font={2}", tMP_Text.text, tMP_Text.color, tMP_Text.font);
			}
			else if (component is Image image)
			{
				result.AppendFormat(", Color={0}", image.color);
				if (image.sprite != null)
				{
					result.AppendFormat(", Sprite={0}", image.sprite);
				}
			}
			else if (component is HorizontalOrVerticalLayoutGroup horizontalOrVerticalLayoutGroup)
			{
				result.AppendFormat(", Child Align={0}, Control W={1}, Control H={2}", horizontalOrVerticalLayoutGroup.childAlignment, horizontalOrVerticalLayoutGroup.childControlWidth, horizontalOrVerticalLayoutGroup.childControlHeight);
			}
			FieldInfo[] array = fields;
			foreach (FieldInfo fieldInfo in array)
			{
				object obj = fieldInfo.GetValue(component) ?? "null";
				if (obj is LayerMask layerMask)
				{
					obj = "Layer #" + layerMask.value;
				}
				else if (obj is ICollection values)
				{
					obj = "[" + values.Join() + "]";
				}
				result.AppendFormat(", {0}={1}", fieldInfo.Name, obj);
			}
		}

		public static void AddPinkOverlay(GameObject parent)
		{
			PUIElements.CreateUI(parent, "Overlay").AddComponent<Image>().color = new Color(1f, 0f, 1f, 0.2f);
		}

		public static void AddSideScreenContent<T>(GameObject uiPrefab = null) where T : SideScreenContent
		{
			AddSideScreenContentWithOrdering<T>(null, insertBefore: true, uiPrefab);
		}

		public static void AddSideScreenContentWithOrdering<T>(string targetClassName, bool insertBefore = true, GameObject uiPrefab = null) where T : SideScreenContent
		{
			DetailsScreen instance = DetailsScreen.Instance;
			if (instance == null)
			{
				LogUIWarning("DetailsScreen is not yet initialized, try a postfix on DetailsScreen.OnPrefabInit");
				return;
			}
			List<DetailsScreen.SideScreenRef> list = UIDetours.SIDE_SCREENS.Get(instance);
			GameObject sideScreenContent = GetSideScreenContent(instance);
			string name = typeof(T).Name;
			if (sideScreenContent != null && list != null)
			{
				DetailsScreen.SideScreenRef sideScreenRef = new DetailsScreen.SideScreenRef();
				GameObject gameObject = PUIElements.CreateUI(sideScreenContent, name);
				gameObject.AddComponent<BoxLayoutGroup>().Params = new BoxLayoutParams
				{
					Direction = PanelDirection.Vertical,
					Alignment = TextAnchor.UpperCenter,
					Margin = new RectOffset(1, 1, 0, 1)
				};
				T val = gameObject.AddComponent<T>();
				if (uiPrefab != null)
				{
					UIDetours.SS_CONTENT_CONTAINER.Set(val, uiPrefab);
					uiPrefab.transform.SetParent(gameObject.transform);
				}
				sideScreenRef.name = name;
				UIDetours.SS_OFFSET.Set(sideScreenRef, Vector2.zero);
				UIDetours.SS_PREFAB.Set(sideScreenRef, val);
				UIDetours.SS_INSTANCE.Set(sideScreenRef, val);
				InsertSideScreenContent(list, sideScreenRef, targetClassName, insertBefore);
			}
		}

		public static GameObject AddTo(this IUIComponent component, GameObject parent, int index = -2)
		{
			if (component == null)
			{
				throw new ArgumentNullException("component");
			}
			if (parent == null)
			{
				throw new ArgumentNullException("parent");
			}
			GameObject gameObject = component.Build();
			gameObject.SetParent(parent);
			if (index == -1)
			{
				gameObject.transform.SetAsLastSibling();
			}
			else if (index >= 0)
			{
				gameObject.transform.SetSiblingIndex(index);
			}
			return gameObject;
		}

		internal static LayoutSizes CalcSizes(GameObject obj, PanelDirection direction, IEnumerable<Component> components)
		{
			float value = 0f;
			float value2 = 0f;
			float value3 = 0f;
			int pri = int.MinValue;
			int pri2 = int.MinValue;
			int pri3 = int.MinValue;
			Vector3 localScale = obj.transform.localScale;
			float num = Math.Abs((direction == PanelDirection.Horizontal) ? localScale.x : localScale.y);
			bool ignore = false;
			foreach (Component component in components)
			{
				ILayoutIgnorer obj2 = component as ILayoutIgnorer;
				if (obj2 != null && obj2.ignoreLayout)
				{
					ignore = true;
					break;
				}
				Behaviour obj3 = component as Behaviour;
				if (((object)obj3 == null || obj3.isActiveAndEnabled) && component is ILayoutElement layoutElement)
				{
					int layoutPriority = layoutElement.layoutPriority;
					if (direction == PanelDirection.Horizontal)
					{
						layoutElement.CalculateLayoutInputHorizontal();
						PriValue(ref value, layoutElement.minWidth, layoutPriority, ref pri);
						PriValue(ref value2, layoutElement.preferredWidth, layoutPriority, ref pri2);
						PriValue(ref value3, layoutElement.flexibleWidth, layoutPriority, ref pri3);
					}
					else
					{
						layoutElement.CalculateLayoutInputVertical();
						PriValue(ref value, layoutElement.minHeight, layoutPriority, ref pri);
						PriValue(ref value2, layoutElement.preferredHeight, layoutPriority, ref pri2);
						PriValue(ref value3, layoutElement.flexibleHeight, layoutPriority, ref pri3);
					}
				}
			}
			LayoutSizes result = new LayoutSizes(obj, value * num, Math.Max(value, value2) * num, value3);
			result.ignore = ignore;
			return result;
		}

		public static void DebugObjectHierarchy(this GameObject item)
		{
			string text = "null";
			if (item != null)
			{
				StringBuilder stringBuilder = new StringBuilder(256);
				do
				{
					Transform parent = item.transform.parent;
					stringBuilder.Append("- ");
					stringBuilder.Append(item.name);
					if (parent != null)
					{
						item = parent.gameObject;
						if (item != null)
						{
							stringBuilder.AppendLine();
						}
					}
					else
					{
						item = null;
					}
				}
				while (item != null);
				text = stringBuilder.ToString();
			}
			LogUIDebug("Object Tree:" + Environment.NewLine + text);
		}

		public static void DebugObjectTree(this GameObject root)
		{
			string text = "null";
			if (root != null)
			{
				text = GetObjectTree(root, 0);
			}
			LogUIDebug("Object Dump:" + Environment.NewLine + text);
		}

		public static TextStyleSetting DeriveStyle(this TextStyleSetting root, int size = 0, Color? newColor = null, FontStyles? style = null)
		{
			if (root == null)
			{
				throw new ArgumentNullException("root");
			}
			TextStyleSetting textStyleSetting = ScriptableObject.CreateInstance<TextStyleSetting>();
			textStyleSetting.enableWordWrapping = root.enableWordWrapping;
			textStyleSetting.style = ((!style.HasValue) ? root.style : style.Value);
			textStyleSetting.fontSize = ((size > 0) ? size : root.fontSize);
			textStyleSetting.sdfFont = root.sdfFont;
			textStyleSetting.textColor = newColor ?? root.textColor;
			return textStyleSetting;
		}

		public static GameObject ForceLayoutRebuild(GameObject uiElement)
		{
			if (uiElement == null)
			{
				throw new ArgumentNullException("uiElement");
			}
			RectTransform rectTransform = uiElement.rectTransform();
			if (rectTransform != null)
			{
				LayoutRebuilder.ForceRebuildLayoutImmediate(rectTransform);
			}
			return uiElement;
		}

		public static float GetEmWidth(TextStyleSetting style)
		{
			float result = 0f;
			if (style == null)
			{
				throw new ArgumentNullException("style");
			}
			TMP_FontAsset sdfFont = style.sdfFont;
			if (sdfFont != null && sdfFont.characterDictionary.TryGetValue(109, out var value))
			{
				FaceInfo fontInfo = sdfFont.fontInfo;
				float num = (float)style.fontSize / (fontInfo.PointSize * fontInfo.Scale);
				result = ((TMP_TextElement)(object)value).width * num + (float)style.fontSize * 0.01f * sdfFont.normalSpacingOffset;
			}
			return result;
		}

		public static float GetLineHeight(TextStyleSetting style)
		{
			float result = 0f;
			if (style == null)
			{
				throw new ArgumentNullException("style");
			}
			TMP_FontAsset sdfFont = style.sdfFont;
			if (sdfFont != null)
			{
				FaceInfo fontInfo = sdfFont.fontInfo;
				result = fontInfo.LineHeight * (float)style.fontSize / (fontInfo.Scale * fontInfo.PointSize);
			}
			return result;
		}

		private static string GetObjectTree(GameObject root, int indent)
		{
			StringBuilder stringBuilder = new StringBuilder(1024);
			StringBuilder stringBuilder2 = new StringBuilder(indent);
			for (int i = 0; i < indent; i++)
			{
				stringBuilder2.Append(' ');
			}
			string value = stringBuilder2.ToString();
			Transform transform = root.transform;
			int childCount = transform.childCount;
			stringBuilder.Append(value).AppendFormat("GameObject[{0}, {1:D} child(ren), Layer {2:D}, Active={3}]", root.name, childCount, root.layer, root.activeInHierarchy).AppendLine();
			stringBuilder.Append(value).AppendFormat(" Translation={0} [{3}] Rotation={1} [{4}] Scale={2}", transform.position, transform.rotation, transform.localScale, transform.localPosition, transform.localRotation).AppendLine();
			Component[] components = root.GetComponents<Component>();
			foreach (Component component in components)
			{
				if (component is RectTransform rectTransform)
				{
					Vector2 size = rectTransform.rect.size;
					Vector2 anchorMin = rectTransform.anchorMin;
					Vector2 anchorMax = rectTransform.anchorMax;
					Vector2 offsetMin = rectTransform.offsetMin;
					Vector2 offsetMax = rectTransform.offsetMax;
					Vector2 pivot = rectTransform.pivot;
					stringBuilder.Append(value).AppendFormat(" Rect[Size=({0:F2},{1:F2}) Min=({2:F2},{3:F2}) ", size.x, size.y, LayoutUtility.GetMinWidth(rectTransform), LayoutUtility.GetMinHeight(rectTransform));
					stringBuilder.AppendFormat("Preferred=({0:F2},{1:F2}) Flexible=({2:F2},{3:F2}) ", LayoutUtility.GetPreferredWidth(rectTransform), LayoutUtility.GetPreferredHeight(rectTransform), LayoutUtility.GetFlexibleWidth(rectTransform), LayoutUtility.GetFlexibleHeight(rectTransform));
					stringBuilder.AppendFormat("Pivot=({4:F2},{5:F2}) AnchorMin=({0:F2},{1:F2}) AnchorMax=({2:F2},{3:F2}) ", anchorMin.x, anchorMin.y, anchorMax.x, anchorMax.y, pivot.x, pivot.y);
					stringBuilder.AppendFormat("OffsetMin=({0:F2},{1:F2}) OffsetMax=({2:F2},{3:F2})]", offsetMin.x, offsetMin.y, offsetMax.x, offsetMax.y).AppendLine();
				}
				else if (component != null && !(component is Transform))
				{
					stringBuilder.Append(value).Append(" Component[").Append(component.GetType().FullName);
					AddComponentText(stringBuilder, component);
					stringBuilder.AppendLine("]");
				}
			}
			if (childCount > 0)
			{
				stringBuilder.Append(value).AppendLine(" Children:");
			}
			for (int k = 0; k < childCount; k++)
			{
				GameObject gameObject = transform.GetChild(k).gameObject;
				if (gameObject != null)
				{
					stringBuilder.AppendLine(GetObjectTree(gameObject, indent + 2));
				}
			}
			return stringBuilder.ToString().TrimEnd(Array.Empty<char>());
		}

		internal static float GetProperSize(LayoutSizes sizes, float allocated)
		{
			float num = sizes.min;
			float num2 = Math.Max(sizes.preferred, num);
			if (allocated > num)
			{
				num = Math.Min(num2, allocated);
			}
			if (allocated > num2 && sizes.flexible > 0f)
			{
				num = allocated;
			}
			return num;
		}

		internal static float GetOffset(TextAnchor alignment, PanelDirection direction, float delta)
		{
			float result = 0f;
			if (direction == PanelDirection.Horizontal)
			{
				switch (alignment)
				{
				case TextAnchor.UpperCenter:
				case TextAnchor.MiddleCenter:
				case TextAnchor.LowerCenter:
					result = delta * 0.5f;
					break;
				case TextAnchor.UpperRight:
				case TextAnchor.MiddleRight:
				case TextAnchor.LowerRight:
					result = delta;
					break;
				}
			}
			else
			{
				switch (alignment)
				{
				case TextAnchor.MiddleLeft:
				case TextAnchor.MiddleCenter:
				case TextAnchor.MiddleRight:
					result = delta * 0.5f;
					break;
				case TextAnchor.LowerLeft:
				case TextAnchor.LowerCenter:
				case TextAnchor.LowerRight:
					result = delta;
					break;
				}
			}
			return result;
		}

		public static GameObject GetParent(this GameObject child)
		{
			GameObject result = null;
			if (child != null)
			{
				Transform parent = child.transform.parent;
				GameObject gameObject;
				if (parent != null && (gameObject = parent.gameObject) != null)
				{
					result = gameObject;
				}
			}
			return result;
		}

		public static GameObject GetSideScreenContent(DetailsScreen screen)
		{
			GameObject result = null;
			if (screen != null)
			{
				DetailsScreen.SidescreenTab sidescreenTab = UIDetours.SS_GET_TAB.Invoke(screen, DetailsScreen.SidescreenTabTypes.Config);
				if (sidescreenTab != null)
				{
					result = UIDetours.SS_BODY_INSTANCE.Get(sidescreenTab);
				}
			}
			return result;
		}

		internal static GameObject InsetChild(GameObject parent, GameObject child, Vector2 insets, Vector2 prefSize = default(Vector2))
		{
			RectTransform rectTransform = child.rectTransform();
			float x = insets.x;
			float y = insets.y;
			float x2 = prefSize.x;
			float y2 = prefSize.y;
			rectTransform.offsetMax = new Vector2(0f - x, 0f - y);
			rectTransform.offsetMin = insets;
			LayoutElement layoutElement = parent.AddOrGet<LayoutElement>();
			float minWidth = (layoutElement.preferredWidth = ((x2 <= 0f) ? LayoutUtility.GetPreferredWidth(rectTransform) : x2) + x * 2f);
			layoutElement.minWidth = minWidth;
			minWidth = (layoutElement.preferredHeight = ((y2 <= 0f) ? LayoutUtility.GetPreferredHeight(rectTransform) : y2) + y * 2f);
			layoutElement.minHeight = minWidth;
			return parent;
		}

		private static void InsertSideScreenContent(IList<DetailsScreen.SideScreenRef> screens, DetailsScreen.SideScreenRef newScreen, string targetClassName, bool insertBefore)
		{
			if (screens == null)
			{
				throw new ArgumentNullException("screens");
			}
			if (newScreen == null)
			{
				throw new ArgumentNullException("newScreen");
			}
			if (string.IsNullOrEmpty(targetClassName))
			{
				screens.Add(newScreen);
				return;
			}
			int count = screens.Count;
			bool flag = false;
			for (int i = 0; i < count; i++)
			{
				DetailsScreen.SideScreenRef sideScreenRef = screens[i];
				SideScreenContent sideScreenContent = UIDetours.SS_PREFAB.Get(sideScreenRef);
				if (!(sideScreenContent != null))
				{
					continue;
				}
				SideScreenContent[] componentsInChildren = sideScreenContent.GetComponentsInChildren<SideScreenContent>();
				if (componentsInChildren == null || componentsInChildren.Length < 1)
				{
					LogUIWarning("Could not find SideScreenContent on side screen: " + sideScreenRef.name);
				}
				else if (componentsInChildren[0].GetType().FullName == targetClassName)
				{
					if (insertBefore)
					{
						screens.Insert(i, newScreen);
					}
					else if (i >= count - 1)
					{
						screens.Add(newScreen);
					}
					else
					{
						screens.Insert(i + 1, newScreen);
					}
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				LogUIWarning("No side screen with class name {0} found!".F(targetClassName));
				screens.Add(newScreen);
			}
		}

		public static Sprite LoadSprite(string path, Vector4 border = default(Vector4), bool log = true)
		{
			return LoadSprite(Assembly.GetCallingAssembly(), path, border, log);
		}

		internal static Sprite LoadSprite(Assembly assembly, string path, Vector4 border = default(Vector4), bool log = false)
		{
			try
			{
				using (Stream stream = assembly.GetManifestResourceStream(path))
				{
					if (stream == null)
					{
						throw new ArgumentException("Could not load image: " + path);
					}
					int num = (int)stream.Length;
					byte[] data = new byte[num];
					Texture2D texture2D = new Texture2D(2, 2);
					num = ReadAllBytes(stream, data);
					texture2D.LoadImage(data, markNonReadable: false);
					int width = texture2D.width;
					int height = texture2D.height;
					if (log)
					{
						LogUIDebug("Loaded sprite: {0} ({1:D}x{2:D}, {3:D} bytes)".F(path, width, height, num));
					}
					return Sprite.Create(texture2D, new Rect(0f, 0f, width, height), new Vector2(0.5f, 0.5f), 100f, 0u, SpriteMeshType.FullRect, border);
				}
			}
			catch (IOException innerException)
			{
				throw new ArgumentException("Could not load image: " + path, innerException);
			}
		}

		public static Sprite LoadSpriteFile(string path, Vector4 border = default(Vector4))
		{
			Sprite result = null;
			try
			{
				using (FileStream fileStream = new FileStream(path, FileMode.Open))
				{
					byte[] data = new byte[(int)fileStream.Length];
					Texture2D texture2D = new Texture2D(2, 2);
					ReadAllBytes(fileStream, data);
					texture2D.LoadImage(data, markNonReadable: false);
					int width = texture2D.width;
					int height = texture2D.height;
					result = Sprite.Create(texture2D, new Rect(0f, 0f, width, height), new Vector2(0.5f, 0.5f), 100f, 0u, SpriteMeshType.FullRect, border);
				}
			}
			catch (IOException)
			{
			}
			return result;
		}

		internal static Sprite LoadSpriteLegacy(Assembly assembly, string path, int width, int height, Vector4 border = default(Vector4))
		{
			try
			{
				using (Stream stream = assembly.GetManifestResourceStream(path))
				{
					if (stream == null)
					{
						throw new ArgumentException("Could not load image: " + path);
					}
					int num = (int)stream.Length - 128;
					if (num < 0)
					{
						throw new ArgumentException("Image is too small: " + path);
					}
					byte[] data = new byte[num];
					stream.Seek(128L, SeekOrigin.Begin);
					num = ReadAllBytes(stream, data);
					Texture2D texture2D = new Texture2D(width, height, TextureFormat.DXT5, mipChain: false);
					texture2D.LoadRawTextureData(data);
					texture2D.Apply(updateMipmaps: true, makeNoLongerReadable: true);
					LogUIDebug("Loaded sprite: {0} ({1:D}x{2:D}, {3:D} bytes)".F(path, width, height, num));
					return Sprite.Create(texture2D, new Rect(0f, 0f, width, height), new Vector2(0.5f, 0.5f), 100f, 0u, SpriteMeshType.FullRect, border);
				}
			}
			catch (IOException innerException)
			{
				throw new ArgumentException("Could not load image: " + path, innerException);
			}
		}

		private static int ReadAllBytes(Stream stream, byte[] data)
		{
			int num = 0;
			int num2 = data.Length;
			int num3;
			do
			{
				num3 = stream.Read(data, num, num2 - num);
				num += num3;
			}
			while (num3 > 0 && num < num2);
			return num;
		}

		internal static void LogUIDebug(string message)
		{
			Debug.LogFormat("[PLib/UI/{0}] {1}", Assembly.GetCallingAssembly().GetName().Name ?? "?", message);
		}

		internal static void LogUIWarning(string message)
		{
			Debug.LogWarningFormat("[PLib/UI/{0}] {1}", Assembly.GetCallingAssembly().GetName().Name ?? "?", message);
		}

		private static void PriValue(ref float value, float newValue, int newPri, ref int pri)
		{
			int num = pri;
			if (newValue >= 0f)
			{
				if (newPri > num)
				{
					pri = newPri;
					value = newValue;
				}
				else if (newValue > value && newPri == num)
				{
					value = newValue;
				}
			}
		}

		public static GameObject SetFlexUISize(this GameObject uiElement, Vector2 flexSize)
		{
			if (uiElement == null)
			{
				throw new ArgumentNullException("uiElement");
			}
			if (uiElement.TryGetComponent<ISettableFlexSize>(out var component))
			{
				component.flexibleWidth = flexSize.x;
				component.flexibleHeight = flexSize.y;
			}
			else
			{
				LayoutElement layoutElement = uiElement.AddOrGet<LayoutElement>();
				layoutElement.flexibleWidth = flexSize.x;
				layoutElement.flexibleHeight = flexSize.y;
			}
			return uiElement;
		}

		public static GameObject SetMinUISize(this GameObject uiElement, Vector2 minSize)
		{
			if (uiElement == null)
			{
				throw new ArgumentNullException("uiElement");
			}
			float x = minSize.x;
			float y = minSize.y;
			if (x > 0f || y > 0f)
			{
				LayoutElement layoutElement = uiElement.AddOrGet<LayoutElement>();
				if (x > 0f)
				{
					layoutElement.minWidth = x;
				}
				if (y > 0f)
				{
					layoutElement.minHeight = y;
				}
			}
			return uiElement;
		}

		public static GameObject SetUISize(this GameObject uiElement, Vector2 size, bool addLayout = false)
		{
			if (uiElement == null)
			{
				throw new ArgumentNullException("uiElement");
			}
			RectTransform rectTransform = uiElement.rectTransform();
			float x = size.x;
			float y = size.y;
			if (rectTransform != null)
			{
				if (x >= 0f)
				{
					rectTransform.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, x);
				}
				if (y >= 0f)
				{
					rectTransform.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, y);
				}
			}
			if (addLayout)
			{
				LayoutElement layoutElement = uiElement.AddOrGet<LayoutElement>();
				layoutElement.minWidth = x;
				layoutElement.minHeight = y;
				layoutElement.preferredWidth = x;
				layoutElement.preferredHeight = y;
				layoutElement.flexibleHeight = 0f;
				layoutElement.flexibleWidth = 0f;
			}
			return uiElement;
		}
	}
}
