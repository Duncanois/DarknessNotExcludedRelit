using System;
using System.Collections.Generic;
using PeterHan.PLib.Core;
using UnityEngine;

namespace PeterHan.PLib.UI
{
	public class PPanel : PContainer, IDynamicSizable, IUIComponent
	{
		protected readonly ICollection<IUIComponent> children;

		public TextAnchor Alignment { get; set; }

		public PanelDirection Direction { get; set; }

		public bool DynamicSize { get; set; }

		public int Spacing { get; set; }

		public PPanel()
			: this(null)
		{
		}

		public PPanel(string name)
			: base(name ?? "Panel")
		{
			Alignment = TextAnchor.MiddleCenter;
			children = new List<IUIComponent>();
			Direction = PanelDirection.Vertical;
			DynamicSize = true;
			Spacing = 0;
		}

		public PPanel AddChild(IUIComponent child)
		{
			if (child == null)
			{
				throw new ArgumentNullException("child");
			}
			children.Add(child);
			return this;
		}

		public PPanel AddOnRealize(PUIDelegates.OnRealize onRealize)
		{
			OnRealize += onRealize;
			return this;
		}

		public override GameObject Build()
		{
			return Build(default, DynamicSize);
		}

		private GameObject Build(Vector2 size, bool dynamic)
		{
			GameObject gameObject = PUIElements.CreateUI(null, Name);
			SetImage(gameObject);
			foreach (IUIComponent child in children)
			{
				GameObject gameObject2 = child.Build();
				gameObject2.SetParent(gameObject);
				PUIElements.SetAnchors(gameObject2, PUIAnchoring.Stretch, PUIAnchoring.Stretch);
			}
			BoxLayoutGroup boxLayoutGroup = gameObject.AddComponent<BoxLayoutGroup>();
			boxLayoutGroup.Params = new BoxLayoutParams
			{
				Direction = Direction,
				Alignment = Alignment,
				Spacing = Spacing,
				Margin = Margin
			};
			if (!dynamic)
			{
				boxLayoutGroup.LockLayout();
				gameObject.SetMinUISize(size);
			}
			boxLayoutGroup.flexibleWidth = FlexSize.x;
			boxLayoutGroup.flexibleHeight = FlexSize.y;
			InvokeRealize(gameObject);
			return gameObject;
		}

		public GameObject BuildWithFixedSize(Vector2 size)
		{
			return Build(size, dynamic: false);
		}

		public PPanel RemoveChild(IUIComponent child)
		{
			if (child == null)
			{
				throw new ArgumentNullException("child");
			}
			children.Remove(child);
			return this;
		}

		public PPanel SetKleiBlueColor()
		{
			BackColor = PUITuning.Colors.ButtonBlueStyle.inactiveColor;
			return this;
		}

		public PPanel SetKleiPinkColor()
		{
			BackColor = PUITuning.Colors.ButtonPinkStyle.inactiveColor;
			return this;
		}

		public override string ToString()
		{
			return $"PPanel[Name={Name},Direction={Direction}]";
		}
	}
}
