using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace PeterHan.PLib.UI
{
	internal sealed class PTextField : IUIComponent
	{
		public enum FieldType
		{
			Text,
			Integer,
			Float
		}

		public Color BackColor { get; set; }

		private TMP_InputField.ContentType ContentType
		{
			get
			{
				switch (Type)
				{
				case FieldType.Float:
					return TMP_InputField.ContentType.DecimalNumber;
				case FieldType.Integer:
					return TMP_InputField.ContentType.IntegerNumber;
				default:
					return TMP_InputField.ContentType.Standard;
				}
			}
		}

		public Vector2 FlexSize { get; set; }

		public int MaxLength { get; set; }

		public int MinWidth { get; set; }

		public TextStyleSetting PlaceholderStyle { get; set; }

		public string PlaceholderText { get; set; }

		public string Name { get; }

		public TextAlignmentOptions TextAlignment { get; set; }

		public string Text { get; set; }

		public TextStyleSetting TextStyle { get; set; }

		public string ToolTip { get; set; }

		public FieldType Type { get; set; }

		public PUIDelegates.OnTextChanged OnTextChanged { get; set; }

		public TMP_InputField.OnValidateInput OnValidate { get; set; }

		public event PUIDelegates.OnRealize OnRealize;

		internal static TextMeshProUGUI ConfigureField(TextMeshProUGUI component, TextStyleSetting style, TextAlignmentOptions alignment)
		{
			component.alignment = alignment;
			component.autoSizeTextContainer = false;
			component.enabled = true;
			component.color = style.textColor;
			component.font = style.sdfFont;
			component.fontSize = style.fontSize;
			component.fontStyle = style.style;
			component.overflowMode = TextOverflowModes.Overflow;
			return component;
		}

		public static string GetText(GameObject textField)
		{
			if (textField == null)
			{
				throw new ArgumentNullException("textField");
			}
			if (!textField.TryGetComponent<TMP_InputField>(out var component))
			{
				return "";
			}
			return component.text;
		}

		public PTextField()
			: this(null)
		{
		}

		public PTextField(string name)
		{
			BackColor = PUITuning.Colors.BackgroundLight;
			FlexSize = Vector2.zero;
			MaxLength = 256;
			MinWidth = 32;
			Name = name ?? "TextField";
			PlaceholderText = null;
			Text = null;
			TextAlignment = TextAlignmentOptions.Center;
			TextStyle = PUITuning.Fonts.TextDarkStyle;
			PlaceholderStyle = TextStyle;
			ToolTip = "";
			Type = FieldType.Text;
		}

		public PTextField AddOnRealize(PUIDelegates.OnRealize onRealize)
		{
			OnRealize += onRealize;
			return this;
		}

		public GameObject Build()
		{
			GameObject gameObject = PUIElements.CreateUI(null, Name);
			TextStyleSetting textStyleSetting = TextStyle ?? PUITuning.Fonts.TextLightStyle;
			Image image = gameObject.AddComponent<Image>();
			image.sprite = PUITuning.Images.BoxBorderWhite;
			image.type = Image.Type.Sliced;
			image.color = textStyleSetting.textColor;
			GameObject gameObject2 = PUIElements.CreateUI(gameObject, "Text Area", canvas: false);
			gameObject2.AddComponent<Image>().color = BackColor;
			RectMask2D rectMask2D = gameObject2.AddComponent<RectMask2D>();
			GameObject gameObject3 = PUIElements.CreateUI(gameObject2, "Text");
			TextMeshProUGUI textMeshProUGUI = ConfigureField(gameObject3.AddComponent<TextMeshProUGUI>(), textStyleSetting, TextAlignment);
			textMeshProUGUI.enableWordWrapping = false;
			textMeshProUGUI.maxVisibleLines = 1;
			textMeshProUGUI.raycastTarget = true;
			gameObject.SetActive(value: false);
			TMP_InputField tMP_InputField = gameObject.AddComponent<TMP_InputField>();
			tMP_InputField.textComponent = textMeshProUGUI;
			tMP_InputField.textViewport = gameObject2.rectTransform();
			tMP_InputField.text = Text ?? "";
			textMeshProUGUI.text = Text ?? "";
			if (PlaceholderText != null)
			{
				TextMeshProUGUI textMeshProUGUI2 = ConfigureField(PUIElements.CreateUI(gameObject2, "Placeholder Text").AddComponent<TextMeshProUGUI>(), PlaceholderStyle ?? textStyleSetting, TextAlignment);
				textMeshProUGUI2.maxVisibleLines = 1;
				textMeshProUGUI2.text = PlaceholderText;
				tMP_InputField.placeholder = textMeshProUGUI2;
			}
			ConfigureTextEntry(tMP_InputField);
			PTextFieldEvents pTextFieldEvents = gameObject.AddComponent<PTextFieldEvents>();
			pTextFieldEvents.OnTextChanged = OnTextChanged;
			pTextFieldEvents.OnValidate = OnValidate;
			pTextFieldEvents.TextObject = gameObject3;
			PUIElements.SetToolTip(gameObject, ToolTip);
			rectMask2D.enabled = true;
			PUIElements.SetAnchorOffsets(gameObject3, new RectOffset());
			gameObject.SetActive(value: true);
			RectTransform rectTransform = gameObject3.rectTransform();
			LayoutRebuilder.ForceRebuildLayoutImmediate(rectTransform);
			LayoutElement layoutElement = PUIUtils.InsetChild(gameObject, gameObject2, Vector2.one, new Vector2(MinWidth, LayoutUtility.GetPreferredHeight(rectTransform))).AddOrGet<LayoutElement>();
			layoutElement.flexibleWidth = FlexSize.x;
			layoutElement.flexibleHeight = FlexSize.y;
			OnRealize?.Invoke(gameObject);
			return gameObject;
		}

		private void ConfigureTextEntry(TMP_InputField textEntry)
		{
			textEntry.characterLimit = Math.Max(1, MaxLength);
			textEntry.contentType = ContentType;
			textEntry.enabled = true;
			textEntry.inputType = TMP_InputField.InputType.Standard;
			textEntry.interactable = true;
			textEntry.isRichTextEditingAllowed = false;
			textEntry.keyboardType = TouchScreenKeyboardType.Default;
			textEntry.lineType = TMP_InputField.LineType.SingleLine;
			textEntry.navigation = Navigation.defaultNavigation;
			textEntry.richText = false;
			textEntry.selectionColor = PUITuning.Colors.SelectionBackground;
			textEntry.transition = Selectable.Transition.None;
			textEntry.restoreOriginalTextOnEscape = true;
		}

		public PTextField SetKleiPinkStyle()
		{
			TextStyle = PUITuning.Fonts.UILightStyle;
			BackColor = PUITuning.Colors.ButtonPinkStyle.inactiveColor;
			return this;
		}

		public PTextField SetKleiBlueStyle()
		{
			TextStyle = PUITuning.Fonts.UILightStyle;
			BackColor = PUITuning.Colors.ButtonBlueStyle.inactiveColor;
			return this;
		}

		public PTextField SetMinWidthInCharacters(int chars)
		{
			int num = Mathf.RoundToInt((float)chars * PUIUtils.GetEmWidth(TextStyle));
			if (num > 0)
			{
				MinWidth = num;
			}
			return this;
		}

		public override string ToString()
		{
			return $"PTextField[Name={Name},Type={Type}]";
		}
	}
}
