using System;
using System.Collections.Generic;
using UnityEngine;

namespace PeterHan.PLib.UI
{
	public class PGridPanel : PContainer, IDynamicSizable, IUIComponent
	{
		private readonly ICollection<GridComponent<IUIComponent>> children;

		private readonly IList<GridColumnSpec> columns;

		private readonly IList<GridRowSpec> rows;

		public int Columns => columns.Count;

		public bool DynamicSize { get; set; }

		public int Rows => rows.Count;

		public PGridPanel()
			: this(null)
		{
		}

		public PGridPanel(string name)
			: base(name ?? "GridPanel")
		{
			children = new List<GridComponent<IUIComponent>>(16);
			columns = new List<GridColumnSpec>(16);
			rows = new List<GridRowSpec>(16);
			DynamicSize = true;
			Margin = null;
		}

		public PGridPanel AddChild(IUIComponent child, GridComponentSpec spec)
		{
			if (child == null)
			{
				throw new ArgumentNullException("child");
			}
			if (spec == null)
			{
				throw new ArgumentNullException("spec");
			}
			children.Add(new GridComponent<IUIComponent>(spec, child));
			return this;
		}

		public PGridPanel AddColumn(GridColumnSpec column)
		{
			if (column == null)
			{
				throw new ArgumentNullException("column");
			}
			columns.Add(column);
			return this;
		}

		public PGridPanel AddOnRealize(PUIDelegates.OnRealize onRealize)
		{
			OnRealize += onRealize;
			return this;
		}

		public PGridPanel AddRow(GridRowSpec row)
		{
			if (row == null)
			{
				throw new ArgumentNullException("row");
			}
			rows.Add(row);
			return this;
		}

		public override GameObject Build()
		{
			if (Columns < 1)
			{
				throw new InvalidOperationException("At least one column must be defined");
			}
			if (Rows < 1)
			{
				throw new InvalidOperationException("At least one row must be defined");
			}
			GameObject gameObject = PUIElements.CreateUI(null, Name);
			SetImage(gameObject);
			PGridLayoutGroup pGridLayoutGroup = gameObject.AddComponent<PGridLayoutGroup>();
			pGridLayoutGroup.Margin = Margin;
			foreach (GridColumnSpec column in columns)
			{
				pGridLayoutGroup.AddColumn(column);
			}
			foreach (GridRowSpec row in rows)
			{
				pGridLayoutGroup.AddRow(row);
			}
			foreach (GridComponent<IUIComponent> child in children)
			{
				pGridLayoutGroup.AddComponent(child.Item.Build(), child);
			}
			if (!DynamicSize)
			{
				pGridLayoutGroup.LockLayout();
			}
			pGridLayoutGroup.flexibleWidth = FlexSize.x;
			pGridLayoutGroup.flexibleHeight = FlexSize.y;
			InvokeRealize(gameObject);
			return gameObject;
		}

		public override string ToString()
		{
			return $"PGridPanel[Name={Name},Rows={Rows:D},Columns={Columns:D}]";
		}
	}
}
