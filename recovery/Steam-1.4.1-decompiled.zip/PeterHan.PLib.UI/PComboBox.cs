using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace PeterHan.PLib.UI
{
	internal sealed class PComboBox<T> : IUIComponent, IDynamicSizable where T : class, IListableOption
	{
		private static readonly RectOffset DEFAULT_ITEM_MARGIN = new RectOffset(3, 3, 3, 3);

		public Vector2 ArrowSize { get; set; }

		public ColorStyleSetting BackColor { get; set; }

		public Vector2 CheckSize { get; set; }

		public IEnumerable<T> Content { get; set; }

		public bool DynamicSize { get; set; }

		public ColorStyleSetting EntryColor { get; set; }

		public Vector2 FlexSize { get; set; }

		public T InitialItem { get; set; }

		public RectOffset ItemMargin { get; set; }

		public RectOffset Margin { get; set; }

		public int MaxRowsShown { get; set; }

		public int MinWidth { get; set; }

		public string Name { get; }

		public PUIDelegates.OnDropdownChanged<T> OnOptionSelected { get; set; }

		public TextAnchor TextAlignment { get; set; }

		public TextStyleSetting TextStyle { get; set; }

		public string ToolTip { get; set; }

		public event PUIDelegates.OnRealize OnRealize;

		public static void SetSelectedItem(GameObject realized, IListableOption option, bool fireListener = false)
		{
			if (option != null && realized != null && realized.TryGetComponent<PComboBoxComponent>(out var component))
			{
				component.SetSelectedItem(option, fireListener);
			}
		}

		public PComboBox()
			: this("Dropdown")
		{
		}

		public PComboBox(string name)
		{
			ArrowSize = new Vector2(8f, 8f);
			BackColor = null;
			CheckSize = new Vector2(12f, 12f);
			Content = null;
			DynamicSize = false;
			FlexSize = Vector2.zero;
			InitialItem = null;
			ItemMargin = DEFAULT_ITEM_MARGIN;
			Margin = PButton.BUTTON_MARGIN;
			MaxRowsShown = 6;
			MinWidth = 0;
			Name = name;
			TextAlignment = TextAnchor.MiddleLeft;
			TextStyle = null;
			ToolTip = null;
		}

		public PComboBox<T> AddOnRealize(PUIDelegates.OnRealize onRealize)
		{
			OnRealize += onRealize;
			return this;
		}

		public GameObject Build()
		{
			GameObject gameObject = PUIElements.CreateUI(null, Name);
			TextStyleSetting textStyleSetting = TextStyle ?? PUITuning.Fonts.UILightStyle;
			ColorStyleSetting colorStyleSetting = EntryColor ?? PUITuning.Colors.ButtonBlueStyle;
			RectOffset margin = Margin;
			RectOffset itemMargin = ItemMargin;
			KImage kImage = gameObject.AddComponent<KImage>();
			ColorStyleSetting arg = BackColor ?? PUITuning.Colors.ButtonBlueStyle;
			UIDetours.COLOR_STYLE_SETTING.Set(kImage, arg);
			PButton.SetupButtonBackground(kImage);
			GameObject gameObject2 = PUIElements.CreateUI(gameObject, "SelectedItem");
			if (MinWidth > 0)
			{
				gameObject2.SetMinUISize(new Vector2(MinWidth, 0f));
			}
			LocText selectedLabel = PUIElements.AddLocText(gameObject2, textStyleSetting);
			GameObject gameObject3 = PUIElements.CreateUI(null, "Content");
			gameObject3.AddComponent<VerticalLayoutGroup>().childForceExpandWidth = true;
			GameObject gameObject4 = new PScrollPane("PullDown")
			{
				ScrollHorizontal = false,
				ScrollVertical = true,
				AlwaysShowVertical = true,
				FlexSize = Vector2.right,
				TrackSize = 8f,
				BackColor = colorStyleSetting.inactiveColor
			}.BuildScrollPane(gameObject, gameObject3);
			gameObject4.rectTransform().pivot = new Vector2(0.5f, 1f);
			PComboBoxComponent pComboBoxComponent = gameObject.AddComponent<PComboBoxComponent>();
			pComboBoxComponent.CheckColor = textStyleSetting.textColor;
			pComboBoxComponent.ContentContainer = gameObject3.rectTransform();
			pComboBoxComponent.EntryPrefab = BuildRowPrefab(textStyleSetting, colorStyleSetting);
			pComboBoxComponent.MaxRowsShown = MaxRowsShown;
			pComboBoxComponent.Pulldown = gameObject4;
			pComboBoxComponent.SelectedLabel = selectedLabel;
			pComboBoxComponent.SetItems(Content);
			pComboBoxComponent.SetSelectedItem(InitialItem);
			pComboBoxComponent.OnSelectionChanged = (PComboBoxComponent obj, IListableOption item) =>
			{
				OnOptionSelected?.Invoke(obj.gameObject, item as T);
			};
			GameObject gameObject5 = PUIElements.CreateUI(gameObject, "OpenImage");
			Image image = gameObject5.AddComponent<Image>();
			image.sprite = PUITuning.Images.Contract;
			image.color = textStyleSetting.textColor;
			KButton kButton = gameObject.AddComponent<KButton>();
			PButton.SetupButton(kButton, kImage);
			UIDetours.FG_IMAGE.Set(kButton, image);
			kButton.onClick += pComboBoxComponent.OnClick;
			PUIElements.SetToolTip(gameObject2, ToolTip);
			gameObject.SetActive(value: true);
			RelativeLayoutGroup relativeLayoutGroup = gameObject.AddComponent<RelativeLayoutGroup>();
			relativeLayoutGroup.AnchorYAxis(gameObject2).SetLeftEdge(gameObject2, 0f).SetRightEdge(gameObject2, -1f, gameObject5)
				.AnchorYAxis(gameObject5)
				.SetRightEdge(gameObject5, 1f)
				.SetMargin(gameObject2, new RectOffset(margin.left, itemMargin.right, margin.top, margin.bottom))
				.SetMargin(gameObject5, new RectOffset(0, margin.right, margin.top, margin.bottom))
				.OverrideSize(gameObject5, ArrowSize)
				.AnchorYAxis(gameObject4, 0f)
				.OverrideSize(gameObject4, Vector2.up);
			relativeLayoutGroup.LockLayout();
			if (DynamicSize)
			{
				relativeLayoutGroup.UnlockLayout();
			}
			gameObject4.AddOrGet<LayoutElement>().ignoreLayout = true;
			gameObject4.SetActive(value: false);
			relativeLayoutGroup.flexibleWidth = FlexSize.x;
			relativeLayoutGroup.flexibleHeight = FlexSize.y;
			OnRealize?.Invoke(gameObject);
			return gameObject;
		}

		private GameObject BuildRowPrefab(TextStyleSetting style, ColorStyleSetting entryColor)
		{
			RectOffset itemMargin = ItemMargin;
			GameObject gameObject = PUIElements.CreateUI(null, "RowEntry");
			KImage kImage = gameObject.AddComponent<KImage>();
			UIDetours.COLOR_STYLE_SETTING.Set(kImage, entryColor);
			UIDetours.APPLY_COLOR_STYLE.Invoke(kImage);
			GameObject gameObject2 = PUIElements.CreateUI(gameObject, "Selected");
			Image image = gameObject2.AddComponent<Image>();
			image.color = style.textColor;
			image.preserveAspect = true;
			image.sprite = PUITuning.Images.Checked;
			KButton kButton = gameObject.AddComponent<KButton>();
			PButton.SetupButton(kButton, kImage);
			UIDetours.FG_IMAGE.Set(kButton, image);
			gameObject.AddComponent<ToolTip>();
			GameObject gameObject3 = PUIElements.CreateUI(gameObject, "Text");
			PUIElements.AddLocText(gameObject3, style).SetText(" ");
			gameObject.AddComponent<RelativeLayoutGroup>().AnchorYAxis(gameObject2).OverrideSize(gameObject2, CheckSize)
				.SetLeftEdge(gameObject2, 0f)
				.SetMargin(gameObject2, itemMargin)
				.AnchorYAxis(gameObject3)
				.SetLeftEdge(gameObject3, -1f, gameObject2)
				.SetRightEdge(gameObject3, 1f)
				.SetMargin(gameObject3, new RectOffset(0, itemMargin.right, itemMargin.top, itemMargin.bottom))
				.LockLayout();
			gameObject.SetActive(value: false);
			return gameObject;
		}

		public PComboBox<T> SetKleiPinkStyle()
		{
			TextStyle = PUITuning.Fonts.UILightStyle;
			BackColor = PUITuning.Colors.ButtonPinkStyle;
			return this;
		}

		public PComboBox<T> SetKleiBlueStyle()
		{
			TextStyle = PUITuning.Fonts.UILightStyle;
			BackColor = PUITuning.Colors.ButtonBlueStyle;
			return this;
		}

		public PComboBox<T> SetMinWidthInCharacters(int chars)
		{
			int num = Mathf.RoundToInt((float)chars * PUIUtils.GetEmWidth(TextStyle));
			if (num > 0)
			{
				MinWidth = num;
			}
			return this;
		}

		public override string ToString()
		{
			return $"PComboBox[Name={Name}]";
		}
	}
}
