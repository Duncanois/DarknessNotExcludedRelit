using UnityEngine;
using UnityEngine.UI;

namespace PeterHan.PLib.UI
{
	internal class PSpacer : IUIComponent
	{
		public Vector2 FlexSize { get; set; }

		public Vector2 PreferredSize { get; set; }

		public string Name { get; }

		public event PUIDelegates.OnRealize OnRealize;

		public PSpacer()
		{
			Name = "Spacer";
			FlexSize = Vector2.one;
			PreferredSize = Vector2.zero;
		}

		public GameObject Build()
		{
			GameObject gameObject = new GameObject(Name);
			LayoutElement layoutElement = gameObject.AddComponent<LayoutElement>();
			layoutElement.flexibleHeight = FlexSize.y;
			layoutElement.flexibleWidth = FlexSize.x;
			layoutElement.minHeight = 0f;
			layoutElement.minWidth = 0f;
			layoutElement.preferredHeight = PreferredSize.y;
			layoutElement.preferredWidth = PreferredSize.x;
			OnRealize?.Invoke(gameObject);
			return gameObject;
		}

		public override string ToString()
		{
			return "PSpacer";
		}
	}
}
