namespace PeterHan.PLib.UI
{
	internal interface ITooltipListableOption : IListableOption
	{
		string GetToolTipText();
	}
}
