using UnityEngine;
using UnityEngine.UI;

namespace PeterHan.PLib.UI
{
	internal class PButton : PTextComponent
	{
		internal static readonly RectOffset BUTTON_MARGIN = new RectOffset(7, 7, 5, 5);

		public ColorStyleSetting Color { get; set; }

		public PUIDelegates.OnButtonPressed OnClick { get; set; }

		internal static void SetupButton(KButton button, KImage bgImage)
		{
			UIDetours.ADDITIONAL_K_IMAGES.Set(button, new KImage[0]);
			UIDetours.SOUND_PLAYER_BUTTON.Set(button, PUITuning.ButtonSounds);
			UIDetours.BG_IMAGE.Set(button, bgImage);
		}

		internal static void SetupButtonBackground(KImage bgImage)
		{
			UIDetours.APPLY_COLOR_STYLE.Invoke(bgImage);
			bgImage.sprite = PUITuning.Images.ButtonBorder;
			bgImage.type = Image.Type.Sliced;
		}

		public static void SetButtonEnabled(GameObject obj, bool enabled)
		{
			if (obj != null && obj.TryGetComponent<KButton>(out var component))
			{
				UIDetours.IS_INTERACTABLE.Set(component, enabled);
			}
		}

		public PButton()
			: this(null)
		{
		}

		public PButton(string name)
			: base(name ?? "Button")
		{
			Margin = BUTTON_MARGIN;
			Sprite = null;
			Text = null;
			ToolTip = "";
		}

		public PButton AddOnRealize(PUIDelegates.OnRealize onRealize)
		{
			OnRealize += onRealize;
			return this;
		}

		public override GameObject Build()
		{
			GameObject button = PUIElements.CreateUI(null, Name);
			GameObject sprite = null;
			GameObject text = null;
			KImage kImage = button.AddComponent<KImage>();
			ColorStyleSetting arg = Color ?? PUITuning.Colors.ButtonPinkStyle;
			UIDetours.COLOR_STYLE_SETTING.Set(kImage, arg);
			SetupButtonBackground(kImage);
			KButton kButton = button.AddComponent<KButton>();
			PUIDelegates.OnButtonPressed evt = OnClick;
			if (evt != null)
			{
				kButton.onClick += () =>
				{
					evt?.Invoke(button);
				};
			}
			SetupButton(kButton, kImage);
			if (Sprite != null)
			{
				Image image = PTextComponent.ImageChildHelper(button, this);
				UIDetours.FG_IMAGE.Set(kButton, image);
				sprite = image.gameObject;
			}
			if (!string.IsNullOrEmpty(Text))
			{
				text = PTextComponent.TextChildHelper(button, TextStyle ?? PUITuning.Fonts.UILightStyle, Text).gameObject;
			}
			PUIElements.SetToolTip(button, ToolTip).SetActive(value: true);
			RelativeLayoutGroup relativeLayoutGroup = button.AddComponent<RelativeLayoutGroup>();
			relativeLayoutGroup.Margin = Margin;
			PTextComponent.ArrangeComponent(relativeLayoutGroup, WrapTextAndSprite(text, sprite), TextAlignment);
			if (!DynamicSize)
			{
				relativeLayoutGroup.LockLayout();
			}
			relativeLayoutGroup.flexibleWidth = FlexSize.x;
			relativeLayoutGroup.flexibleHeight = FlexSize.y;
			DestroyLayoutIfPossible(button);
			InvokeRealize(button);
			return button;
		}

		public PButton SetImageLeftArrow()
		{
			Sprite = PUITuning.Images.Arrow;
			SpriteTransform = ImageTransform.FlipHorizontal;
			return this;
		}

		public PButton SetImageRightArrow()
		{
			Sprite = PUITuning.Images.Arrow;
			SpriteTransform = ImageTransform.None;
			return this;
		}

		public PButton SetKleiPinkStyle()
		{
			TextStyle = PUITuning.Fonts.UILightStyle;
			Color = PUITuning.Colors.ButtonPinkStyle;
			return this;
		}

		public PButton SetKleiBlueStyle()
		{
			TextStyle = PUITuning.Fonts.UILightStyle;
			Color = PUITuning.Colors.ButtonBlueStyle;
			return this;
		}
	}
}
