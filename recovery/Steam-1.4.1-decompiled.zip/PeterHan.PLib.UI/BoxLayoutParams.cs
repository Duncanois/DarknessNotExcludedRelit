using System;
using UnityEngine;

namespace PeterHan.PLib.UI
{
	[Serializable]
	internal sealed class BoxLayoutParams
	{
		public TextAnchor Alignment { get; set; }

		public PanelDirection Direction { get; set; }

		public RectOffset Margin { get; set; }

		public float Spacing { get; set; }

		public BoxLayoutParams()
		{
			Alignment = TextAnchor.MiddleCenter;
			Direction = PanelDirection.Horizontal;
			Margin = null;
			Spacing = 0f;
		}

		public override string ToString()
		{
			return $"BoxLayoutParams[Alignment={Alignment},Direction={Direction},Spacing={Spacing:F2}]";
		}
	}
}
