using UnityEngine;
using UnityEngine.UI;

namespace PeterHan.PLib.UI
{
	public abstract class PContainer : IUIComponent
	{
		public Color BackColor { get; set; }

		public Sprite BackImage { get; set; }

		public Vector2 FlexSize { get; set; }

		public Image.Type ImageMode { get; set; }

		public RectOffset Margin { get; set; }

		public string Name { get; protected set; }

		public event PUIDelegates.OnRealize OnRealize;

		protected PContainer(string name)
		{
			BackColor = PUITuning.Colors.Transparent;
			BackImage = null;
			FlexSize = Vector2.zero;
			ImageMode = Image.Type.Simple;
			Margin = null;
			Name = name ?? "Container";
		}

		public abstract GameObject Build();

		protected void InvokeRealize(GameObject obj)
		{
			OnRealize?.Invoke(obj);
		}

		protected void SetImage(GameObject panel)
		{
			if (BackColor.a > 0f || BackImage != null)
			{
				Image image = panel.AddComponent<Image>();
				image.color = BackColor;
				if (BackImage != null)
				{
					image.sprite = BackImage;
					image.type = ImageMode;
				}
			}
		}

		public override string ToString()
		{
			return $"PContainer[Name={Name}]";
		}
	}
}
