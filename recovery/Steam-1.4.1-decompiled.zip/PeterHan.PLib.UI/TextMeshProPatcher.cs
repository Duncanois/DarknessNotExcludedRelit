using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using PeterHan.PLib.Core;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace PeterHan.PLib.UI
{
	internal static class TextMeshProPatcher
	{
		private const string HARMONY_ID = "TextMeshProPatch";

		private static volatile bool patchChecked = false;

		private static readonly object patchLock = new object();

		private static bool AssignPositioningIfNeeded_Prefix(TMP_InputField __instance, RectTransform ___caretRectTrans, TMP_Text ___m_TextComponent)
		{
			bool result = true;
			if (___m_TextComponent != null && ___caretRectTrans != null && __instance != null && ___m_TextComponent.isActiveAndEnabled)
			{
				RectTransform rectTransform = ___m_TextComponent.rectTransform;
				if (___caretRectTrans.localPosition != rectTransform.localPosition || ___caretRectTrans.localRotation != rectTransform.localRotation || ___caretRectTrans.localScale != rectTransform.localScale || ___caretRectTrans.anchorMin != rectTransform.anchorMin || ___caretRectTrans.anchorMax != rectTransform.anchorMax || ___caretRectTrans.anchoredPosition != rectTransform.anchoredPosition || ___caretRectTrans.sizeDelta != rectTransform.sizeDelta || ___caretRectTrans.pivot != rectTransform.pivot)
				{
					__instance.StartCoroutine(ResizeCaret(___caretRectTrans, rectTransform));
					result = false;
				}
			}
			return result;
		}

		private static bool HasOurPatch(IEnumerable<Patch> patchList)
		{
			bool result = false;
			if (patchList != null)
			{
				foreach (Patch patch in patchList)
				{
					string text = patch.PatchMethod?.DeclaringType?.Name;
					if (text == "TextMeshProPatcher" || text == "PLibPatches")
					{
						result = true;
						break;
					}
				}
			}
			return result;
		}

		private static void InputFieldPatches(Type tmpType)
		{
			Harmony harmony = new Harmony("TextMeshProPatch");
			MethodInfo methodSafe = tmpType.GetMethodSafe("AssignPositioningIfNeeded", isStatic: false, PPatchTools.AnyArguments);
			if (methodSafe != null && !HasOurPatch(Harmony.GetPatchInfo(methodSafe)?.Prefixes))
			{
				harmony.Patch(methodSafe, new HarmonyMethod(typeof(TextMeshProPatcher), "AssignPositioningIfNeeded_Prefix"));
			}
			MethodInfo methodSafe2 = tmpType.GetMethodSafe("OnEnable", isStatic: false, PPatchTools.AnyArguments);
			if (methodSafe2 != null && !HasOurPatch(Harmony.GetPatchInfo(methodSafe2)?.Postfixes))
			{
				harmony.Patch(methodSafe2, null, new HarmonyMethod(typeof(TextMeshProPatcher), "OnEnable_Postfix"));
			}
		}

		private static void OnEnable_Postfix(Scrollbar ___m_VerticalScrollbar, TMP_Text ___m_TextComponent)
		{
			if (___m_TextComponent != null)
			{
				___m_TextComponent.ignoreRectMaskCulling = ___m_VerticalScrollbar != null;
			}
		}

		public static void Patch()
		{
			lock (patchLock)
			{
				if (patchChecked)
				{
					return;
				}
				Type typeSafe = PPatchTools.GetTypeSafe("TMPro.TMP_InputField");
				if (typeSafe != null)
				{
					try
					{
						InputFieldPatches(typeSafe);
					}
					catch (Exception)
					{
						PUtil.LogWarning("Unable to patch TextMeshPro bug, text fields may display improperly inside scroll areas");
					}
				}
				patchChecked = true;
			}
		}

		private static IEnumerator ResizeCaret(RectTransform caretTransform, RectTransform textTransform)
		{
			yield return new WaitForEndOfFrame();
			caretTransform.localPosition = textTransform.localPosition;
			caretTransform.localRotation = textTransform.localRotation;
			caretTransform.localScale = textTransform.localScale;
			caretTransform.anchorMin = textTransform.anchorMin;
			caretTransform.anchorMax = textTransform.anchorMax;
			caretTransform.anchoredPosition = textTransform.anchoredPosition;
			caretTransform.sizeDelta = textTransform.sizeDelta;
			caretTransform.pivot = textTransform.pivot;
		}
	}
}
