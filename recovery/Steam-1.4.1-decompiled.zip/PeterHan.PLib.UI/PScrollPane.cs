using System;
using PeterHan.PLib.Core;
using PeterHan.PLib.UI.Layouts;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace PeterHan.PLib.UI
{
	internal sealed class PScrollPane : IUIComponent
	{
		private sealed class PScrollPaneLayout : AbstractLayoutGroup
		{
			private Component[] calcElements;

			private LayoutSizes childHorizontal;

			private LayoutSizes childVertical;

			private GameObject child;

			private ILayoutController[] setElements;

			private GameObject viewport;

			internal PScrollPaneLayout()
			{
				minHeight = (minWidth = 0f);
				child = (viewport = null);
			}

			public override void CalculateLayoutInputHorizontal()
			{
				if (child == null)
				{
					UpdateComponents();
				}
				if (child != null)
				{
					calcElements = child.GetComponents<Component>();
					childHorizontal = PUIUtils.CalcSizes(child, PanelDirection.Horizontal, calcElements);
					if (childHorizontal.ignore)
					{
						throw new InvalidOperationException("ScrollPane child ignores layout!");
					}
					preferredWidth = childHorizontal.preferred;
				}
			}

			public override void CalculateLayoutInputVertical()
			{
				if (child == null)
				{
					UpdateComponents();
				}
				if (child != null && calcElements != null)
				{
					childVertical = PUIUtils.CalcSizes(child, PanelDirection.Vertical, calcElements);
					preferredHeight = childVertical.preferred;
					calcElements = null;
				}
			}

			protected override void OnEnable()
			{
				base.OnEnable();
				UpdateComponents();
			}

			public override void SetLayoutHorizontal()
			{
				if (viewport != null && child != null)
				{
					float num = childHorizontal.preferred;
					float width = viewport.rectTransform().rect.width;
					if (num < width && childHorizontal.flexible > 0f)
					{
						num = width;
					}
					setElements = child.GetComponents<ILayoutController>();
					child.rectTransform().SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, num);
					ILayoutController[] array = setElements;
					for (int i = 0; i < array.Length; i++)
					{
						array[i].SetLayoutHorizontal();
					}
				}
			}

			public override void SetLayoutVertical()
			{
				if (viewport != null && child != null && setElements != null)
				{
					float num = childVertical.preferred;
					float height = viewport.rectTransform().rect.height;
					if (num < height && childVertical.flexible > 0f)
					{
						num = height;
					}
					child.rectTransform().SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, num);
					ILayoutController[] array = setElements;
					for (int i = 0; i < array.Length; i++)
					{
						array[i].SetLayoutVertical();
					}
					setElements = null;
				}
			}

			private void UpdateComponents()
			{
				GameObject gameObject = base.gameObject;
				if (gameObject != null && gameObject.TryGetComponent<ScrollRect>(out var component))
				{
					child = component.content?.gameObject;
					viewport = component.viewport?.gameObject;
				}
				else
				{
					child = (viewport = null);
				}
			}
		}

		private sealed class ViewportLayoutGroup : UIBehaviour, ILayoutGroup, ILayoutController
		{
			public void SetLayoutHorizontal()
			{
			}

			public void SetLayoutVertical()
			{
			}
		}

		private const float DEFAULT_TRACK_SIZE = 16f;

		public bool AlwaysShowHorizontal { get; set; }

		public bool AlwaysShowVertical { get; set; }

		public Color BackColor { get; set; }

		public IUIComponent Child { get; set; }

		public Vector2 FlexSize { get; set; }

		public string Name { get; }

		public bool ScrollHorizontal { get; set; }

		public bool ScrollVertical { get; set; }

		public float TrackSize { get; set; }

		public event PUIDelegates.OnRealize OnRealize;

		public PScrollPane()
			: this(null)
		{
		}

		public PScrollPane(string name)
		{
			AlwaysShowHorizontal = (AlwaysShowVertical = true);
			BackColor = PUITuning.Colors.Transparent;
			Child = null;
			FlexSize = Vector2.zero;
			Name = name ?? "Scroll";
			ScrollHorizontal = false;
			ScrollVertical = false;
			TrackSize = 16f;
		}

		public PScrollPane AddOnRealize(PUIDelegates.OnRealize onRealize)
		{
			OnRealize += onRealize;
			return this;
		}

		public GameObject Build()
		{
			if (Child == null)
			{
				throw new InvalidOperationException("No child component");
			}
			GameObject gameObject = BuildScrollPane(null, Child.Build());
			OnRealize?.Invoke(gameObject);
			return gameObject;
		}

		internal GameObject BuildScrollPane(GameObject parent, GameObject child)
		{
			GameObject gameObject = PUIElements.CreateUI(parent, Name);
			if (BackColor.a > 0f)
			{
				gameObject.AddComponent<Image>().color = BackColor;
			}
			gameObject.SetActive(value: false);
			KScrollRect kScrollRect = gameObject.AddComponent<KScrollRect>();
			kScrollRect.horizontal = ScrollHorizontal;
			kScrollRect.vertical = ScrollVertical;
			GameObject gameObject2 = PUIElements.CreateUI(gameObject, "Viewport");
			gameObject2.rectTransform().pivot = Vector2.up;
			gameObject2.AddComponent<RectMask2D>().enabled = true;
			gameObject2.AddComponent<ViewportLayoutGroup>();
			kScrollRect.viewport = gameObject2.rectTransform();
			child.AddOrGet<Canvas>().pixelPerfect = false;
			child.AddOrGet<GraphicRaycaster>();
			PUIElements.SetAnchors(child.SetParent(gameObject2), PUIAnchoring.Beginning, PUIAnchoring.End);
			kScrollRect.content = child.rectTransform();
			if (ScrollVertical)
			{
				kScrollRect.verticalScrollbar = CreateScrollVert(gameObject);
				kScrollRect.verticalScrollbarVisibility = ((!AlwaysShowVertical) ? ScrollRect.ScrollbarVisibility.AutoHideAndExpandViewport : ScrollRect.ScrollbarVisibility.Permanent);
			}
			if (ScrollHorizontal)
			{
				kScrollRect.horizontalScrollbar = CreateScrollHoriz(gameObject);
				kScrollRect.horizontalScrollbarVisibility = ((!AlwaysShowHorizontal) ? ScrollRect.ScrollbarVisibility.AutoHideAndExpandViewport : ScrollRect.ScrollbarVisibility.Permanent);
			}
			gameObject.SetActive(value: true);
			PScrollPaneLayout pScrollPaneLayout = gameObject.AddComponent<PScrollPaneLayout>();
			pScrollPaneLayout.flexibleHeight = FlexSize.y;
			pScrollPaneLayout.flexibleWidth = FlexSize.x;
			return gameObject;
		}

		private Scrollbar CreateScrollHoriz(GameObject parent)
		{
			GameObject gameObject = PUIElements.CreateUI(parent, "Scrollbar H", canvas: true, PUIAnchoring.Stretch, PUIAnchoring.Beginning);
			Image image = gameObject.AddComponent<Image>();
			image.sprite = PUITuning.Images.ScrollBorderHorizontal;
			image.type = Image.Type.Sliced;
			Scrollbar scrollbar = gameObject.AddComponent<Scrollbar>();
			scrollbar.interactable = true;
			scrollbar.transition = Selectable.Transition.ColorTint;
			scrollbar.colors = PUITuning.Colors.ScrollbarColors;
			scrollbar.SetDirection(Scrollbar.Direction.RightToLeft, includeRectLayouts: true);
			GameObject gameObject2 = PUIElements.CreateUI(gameObject, "Handle", canvas: true, PUIAnchoring.Stretch, PUIAnchoring.End);
			PUIElements.SetAnchorOffsets(gameObject2, 1f, 1f, 1f, 1f);
			scrollbar.handleRect = gameObject2.rectTransform();
			Image image2 = gameObject2.AddComponent<Image>();
			image2.sprite = PUITuning.Images.ScrollHandleHorizontal;
			image2.type = Image.Type.Sliced;
			scrollbar.targetGraphic = image2;
			gameObject.SetActive(value: true);
			PUIElements.SetAnchorOffsets(gameObject, 2f, 2f, 0f - TrackSize, 0f);
			return scrollbar;
		}

		private Scrollbar CreateScrollVert(GameObject parent)
		{
			GameObject gameObject = PUIElements.CreateUI(parent, "Scrollbar V", canvas: true, PUIAnchoring.End);
			Image image = gameObject.AddComponent<Image>();
			image.sprite = PUITuning.Images.ScrollBorderVertical;
			image.type = Image.Type.Sliced;
			Scrollbar scrollbar = gameObject.AddComponent<Scrollbar>();
			scrollbar.interactable = true;
			scrollbar.transition = Selectable.Transition.ColorTint;
			scrollbar.colors = PUITuning.Colors.ScrollbarColors;
			scrollbar.SetDirection(Scrollbar.Direction.BottomToTop, includeRectLayouts: true);
			GameObject gameObject2 = PUIElements.CreateUI(gameObject, "Handle", canvas: true, PUIAnchoring.Stretch, PUIAnchoring.Beginning);
			PUIElements.SetAnchorOffsets(gameObject2, 1f, 1f, 1f, 1f);
			scrollbar.handleRect = gameObject2.rectTransform();
			Image image2 = gameObject2.AddComponent<Image>();
			image2.sprite = PUITuning.Images.ScrollHandleVertical;
			image2.type = Image.Type.Sliced;
			scrollbar.targetGraphic = image2;
			gameObject.SetActive(value: true);
			PUIElements.SetAnchorOffsets(gameObject, 0f - TrackSize, 0f, 2f, 2f);
			return scrollbar;
		}

		public PScrollPane SetKleiBlueColor()
		{
			BackColor = PUITuning.Colors.ButtonBlueStyle.inactiveColor;
			return this;
		}

		public PScrollPane SetKleiPinkColor()
		{
			BackColor = PUITuning.Colors.ButtonPinkStyle.inactiveColor;
			return this;
		}

		public override string ToString()
		{
			return $"PScrollPane[Name={Name},Child={Child}]";
		}
	}
}
