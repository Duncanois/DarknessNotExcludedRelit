using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace PeterHan.PLib.UI
{
	internal sealed class PComboBoxComponent : KMonoBehaviour
	{
		private struct ComboBoxItem
		{
			public readonly IListableOption data;

			public readonly Image rowImage;

			public readonly GameObject rowInstance;

			public ComboBoxItem(IListableOption data, GameObject rowInstance)
			{
				this.data = data;
				this.rowInstance = rowInstance;
				rowImage = rowInstance.GetComponentInChildrenOnly<Image>();
			}
		}

		private sealed class MouseEventHandler : MonoBehaviour, IPointerEnterHandler, IEventSystemHandler, IPointerExitHandler
		{
			public bool IsOver { get; private set; }

			internal MouseEventHandler()
			{
				IsOver = true;
			}

			public void OnPointerEnter(PointerEventData data)
			{
				IsOver = true;
			}

			public void OnPointerExit(PointerEventData data)
			{
				IsOver = false;
			}
		}

		private readonly IList<ComboBoxItem> currentItems;

		private MouseEventHandler handler;

		private bool open;

		internal RectTransform ContentContainer { get; set; }

		internal Color CheckColor { get; set; }

		internal GameObject EntryPrefab { get; set; }

		internal int MaxRowsShown { get; set; }

		internal Action<PComboBoxComponent, IListableOption> OnSelectionChanged { get; set; }

		internal GameObject Pulldown { get; set; }

		internal TMP_Text SelectedLabel { get; set; }

		internal PComboBoxComponent()
		{
			CheckColor = Color.white;
			currentItems = new List<ComboBoxItem>(32);
			handler = null;
			MaxRowsShown = 8;
			open = false;
		}

		public void Close()
		{
			Pulldown?.SetActive(value: false);
			open = false;
		}

		public void OnClick()
		{
			if (open)
			{
				Close();
			}
			else
			{
				Open();
			}
		}

		protected override void OnPrefabInit()
		{
			base.OnPrefabInit();
			handler = gameObject.AddOrGet<MouseEventHandler>();
		}

		public void Open()
		{
			GameObject pulldown = Pulldown;
			if (pulldown != null)
			{
				float num = 0f;
				int count = currentItems.Count;
				int num2 = Math.Min(MaxRowsShown, count);
				Canvas canvas = pulldown.AddOrGet<Canvas>();
				pulldown.SetActive(value: true);
				if (count > 0)
				{
					RectTransform rectTransform = currentItems[0].rowInstance.rectTransform();
					LayoutRebuilder.ForceRebuildLayoutImmediate(rectTransform);
					num = LayoutUtility.GetPreferredHeight(rectTransform);
				}
				pulldown.rectTransform().SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, (float)num2 * num);
				if (pulldown.TryGetComponent<ScrollRect>(out var component))
				{
					component.vertical = count >= MaxRowsShown;
				}
				if (canvas != null)
				{
					canvas.overrideSorting = true;
					canvas.sortingOrder = 2;
				}
			}
			open = true;
		}

		public void SetItems(IEnumerable<IListableOption> items)
		{
			if (items == null)
			{
				return;
			}
			RectTransform contentContainer = ContentContainer;
			_ = Pulldown;
			int childCount = contentContainer.childCount;
			GameObject entryPrefab = EntryPrefab;
			bool flag = open;
			if (flag)
			{
				Close();
			}
			for (int i = 0; i < childCount; i++)
			{
				UnityEngine.Object.Destroy(contentContainer.GetChild(i));
			}
			currentItems.Clear();
			foreach (IListableOption item in items)
			{
				string text = "";
				GameObject gameObject = Util.KInstantiate(entryPrefab, contentContainer.gameObject);
				gameObject.GetComponentInChildren<TextMeshProUGUI>().SetText(item.GetProperName());
				KButton componentInChildren = gameObject.GetComponentInChildren<KButton>();
				componentInChildren.ClearOnClick();
				componentInChildren.onClick += () =>
				{
					SetSelectedItem(item, fireListener: true);
					Close();
				};
				if (item is ITooltipListableOption tooltipListableOption)
				{
					text = tooltipListableOption.GetToolTipText();
				}
				if (gameObject.TryGetComponent<ToolTip>(out var component))
				{
					if (string.IsNullOrEmpty(text))
					{
						component.ClearMultiStringTooltip();
					}
					else
					{
						component.SetSimpleTooltip(text);
					}
				}
				gameObject.SetActive(value: true);
				currentItems.Add(new ComboBoxItem(item, gameObject));
			}
			SelectedLabel?.SetText((currentItems.Count > 0) ? currentItems[0].data.GetProperName() : "");
			if (flag)
			{
				Open();
			}
		}

		public void SetSelectedItem(IListableOption option, bool fireListener = false)
		{
			if (option == null)
			{
				return;
			}
			SelectedLabel?.SetText(option.GetProperName());
			foreach (ComboBoxItem currentItem in currentItems)
			{
				IListableOption data = currentItem.data;
				currentItem.rowImage.color = ((data != null && data.Equals(option)) ? CheckColor : PUITuning.Colors.Transparent);
			}
			if (fireListener)
			{
				OnSelectionChanged?.Invoke(this, option);
			}
		}

		internal void Update()
		{
			if (open && handler != null && !handler.IsOver && (Input.GetMouseButton(0) || Input.GetAxis("Mouse ScrollWheel") != 0f))
			{
				Close();
			}
		}
	}
}
