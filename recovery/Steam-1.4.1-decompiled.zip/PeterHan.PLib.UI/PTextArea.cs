using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace PeterHan.PLib.UI
{
	internal sealed class PTextArea : IUIComponent
	{
		public Color BackColor { get; set; }

		public Vector2 FlexSize { get; set; }

		public int LineCount { get; set; }

		public int MaxLength { get; set; }

		public string Name { get; }

		public int MinWidth { get; set; }

		public TextAlignmentOptions TextAlignment { get; set; }

		public string Text { get; set; }

		public TextStyleSetting TextStyle { get; set; }

		public string ToolTip { get; set; }

		public PUIDelegates.OnTextChanged OnTextChanged { get; set; }

		public TMP_InputField.OnValidateInput OnValidate { get; set; }

		public event PUIDelegates.OnRealize OnRealize;

		public PTextArea()
			: this(null)
		{
		}

		public PTextArea(string name)
		{
			BackColor = PUITuning.Colors.BackgroundLight;
			FlexSize = Vector2.one;
			LineCount = 4;
			MaxLength = 1024;
			MinWidth = 64;
			Name = name ?? "TextArea";
			Text = null;
			TextAlignment = TextAlignmentOptions.TopLeft;
			TextStyle = PUITuning.Fonts.TextDarkStyle;
			ToolTip = "";
		}

		public PTextArea AddOnRealize(PUIDelegates.OnRealize onRealize)
		{
			OnRealize += onRealize;
			return this;
		}

		public GameObject Build()
		{
			GameObject gameObject = PUIElements.CreateUI(null, Name);
			TextStyleSetting textStyleSetting = TextStyle ?? PUITuning.Fonts.TextLightStyle;
			Image image = gameObject.AddComponent<Image>();
			image.sprite = PUITuning.Images.BoxBorderWhite;
			image.type = Image.Type.Sliced;
			image.color = textStyleSetting.textColor;
			GameObject gameObject2 = PUIElements.CreateUI(gameObject, "Text Area", canvas: false);
			gameObject2.AddComponent<Image>().color = BackColor;
			RectMask2D rectMask2D = gameObject2.AddComponent<RectMask2D>();
			GameObject gameObject3 = PUIElements.CreateUI(gameObject2, "Text");
			TextMeshProUGUI textMeshProUGUI = PTextField.ConfigureField(gameObject3.AddComponent<TextMeshProUGUI>(), textStyleSetting, TextAlignment);
			textMeshProUGUI.enableWordWrapping = true;
			textMeshProUGUI.raycastTarget = true;
			gameObject.SetActive(value: false);
			TMP_InputField tMP_InputField = gameObject.AddComponent<TMP_InputField>();
			tMP_InputField.textComponent = textMeshProUGUI;
			tMP_InputField.textViewport = gameObject2.rectTransform();
			tMP_InputField.text = Text ?? "";
			textMeshProUGUI.text = Text ?? "";
			ConfigureTextEntry(tMP_InputField);
			PTextFieldEvents pTextFieldEvents = gameObject.AddComponent<PTextFieldEvents>();
			pTextFieldEvents.OnTextChanged = OnTextChanged;
			pTextFieldEvents.OnValidate = OnValidate;
			pTextFieldEvents.TextObject = gameObject3;
			PUIElements.SetToolTip(gameObject, ToolTip);
			rectMask2D.enabled = true;
			PUIElements.SetAnchorOffsets(gameObject3, new RectOffset());
			gameObject.SetActive(value: true);
			LayoutElement layoutElement = PUIUtils.InsetChild(gameObject, gameObject2, Vector2.one, new Vector2(MinWidth, (float)Math.Max(LineCount, 1) * PUIUtils.GetLineHeight(textStyleSetting))).AddOrGet<LayoutElement>();
			layoutElement.flexibleWidth = FlexSize.x;
			layoutElement.flexibleHeight = FlexSize.y;
			OnRealize?.Invoke(gameObject);
			return gameObject;
		}

		private void ConfigureTextEntry(TMP_InputField textEntry)
		{
			textEntry.characterLimit = Math.Max(1, MaxLength);
			textEntry.enabled = true;
			textEntry.inputType = TMP_InputField.InputType.Standard;
			textEntry.interactable = true;
			textEntry.isRichTextEditingAllowed = false;
			textEntry.keyboardType = TouchScreenKeyboardType.Default;
			textEntry.lineType = TMP_InputField.LineType.MultiLineNewline;
			textEntry.navigation = Navigation.defaultNavigation;
			textEntry.richText = false;
			textEntry.selectionColor = PUITuning.Colors.SelectionBackground;
			textEntry.transition = Selectable.Transition.None;
			textEntry.restoreOriginalTextOnEscape = true;
		}

		public PTextArea SetKleiPinkStyle()
		{
			TextStyle = PUITuning.Fonts.UILightStyle;
			BackColor = PUITuning.Colors.ButtonPinkStyle.inactiveColor;
			return this;
		}

		public PTextArea SetKleiBlueStyle()
		{
			TextStyle = PUITuning.Fonts.UILightStyle;
			BackColor = PUITuning.Colors.ButtonBlueStyle.inactiveColor;
			return this;
		}

		public PTextArea SetMinWidthInCharacters(int chars)
		{
			int num = Mathf.RoundToInt((float)chars * PUIUtils.GetEmWidth(TextStyle));
			if (num > 0)
			{
				MinWidth = num;
			}
			return this;
		}

		public override string ToString()
		{
			return $"PTextArea[Name={Name}]";
		}
	}
}
