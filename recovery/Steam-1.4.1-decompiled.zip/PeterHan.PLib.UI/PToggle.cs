using UnityEngine;
using UnityEngine.UI;

namespace PeterHan.PLib.UI
{
	internal sealed class PToggle : IDynamicSizable, IUIComponent
	{
		internal static readonly RectOffset TOGGLE_MARGIN = new RectOffset(1, 1, 1, 1);

		public Sprite ActiveSprite { get; set; }

		public ColorStyleSetting Color { get; set; }

		public bool DynamicSize { get; set; }

		public Vector2 FlexSize { get; set; }

		public Sprite InactiveSprite { get; set; }

		public bool InitialState { get; set; }

		public RectOffset Margin { get; set; }

		public string Name { get; }

		public PUIDelegates.OnToggleButton OnStateChanged { get; set; }

		public Vector2 Size { get; set; }

		public string ToolTip { get; set; }

		public event PUIDelegates.OnRealize OnRealize;

		public static bool GetToggleState(GameObject realized)
		{
			if (realized != null && realized.TryGetComponent<KToggle>(out var component))
			{
				return UIDetours.IS_ON.Get(component);
			}
			return false;
		}

		public static void SetToggleState(GameObject realized, bool on)
		{
			if (realized != null && realized.TryGetComponent<KToggle>(out var component))
			{
				UIDetours.IS_ON.Set(component, on);
			}
		}

		public PToggle()
			: this(null)
		{
		}

		public PToggle(string name)
		{
			ActiveSprite = PUITuning.Images.Contract;
			Color = PUITuning.Colors.ComponentDarkStyle;
			InitialState = false;
			Margin = TOGGLE_MARGIN;
			Name = name ?? "Toggle";
			InactiveSprite = PUITuning.Images.Expand;
			ToolTip = "";
		}

		public PToggle AddOnRealize(PUIDelegates.OnRealize onRealize)
		{
			OnRealize += onRealize;
			return this;
		}

		public GameObject Build()
		{
			GameObject toggle = PUIElements.CreateUI(null, Name);
			KToggle kToggle = toggle.AddComponent<KToggle>();
			PUIDelegates.OnToggleButton evt = OnStateChanged;
			if (evt != null)
			{
				kToggle.onValueChanged += (bool on) =>
				{
					evt?.Invoke(toggle, on);
				};
			}
			UIDetours.ART_EXTENSION.Set(kToggle, new KToggleArtExtensions());
			UIDetours.SOUND_PLAYER_TOGGLE.Set(kToggle, PUITuning.ToggleSounds);
			Image image = toggle.AddComponent<Image>();
			image.color = Color.activeColor;
			image.sprite = InactiveSprite;
			toggle.SetActive(value: false);
			ImageToggleState imageToggleState = toggle.AddComponent<ImageToggleState>();
			imageToggleState.TargetImage = image;
			imageToggleState.useSprites = true;
			imageToggleState.InactiveSprite = InactiveSprite;
			imageToggleState.ActiveSprite = ActiveSprite;
			imageToggleState.startingState = ((!InitialState) ? ImageToggleState.State.Inactive : ImageToggleState.State.Active);
			imageToggleState.useStartingState = true;
			imageToggleState.ActiveColour = Color.activeColor;
			imageToggleState.DisabledActiveColour = Color.disabledActiveColor;
			imageToggleState.InactiveColour = Color.inactiveColor;
			imageToggleState.DisabledColour = Color.disabledColor;
			imageToggleState.HoverColour = Color.hoverColor;
			imageToggleState.DisabledHoverColor = Color.disabledhoverColor;
			UIDetours.IS_ON.Set(kToggle, InitialState);
			toggle.SetActive(value: true);
			if (Size.x > 0f && Size.y > 0f)
			{
				toggle.SetUISize(Size, addLayout: true);
			}
			else
			{
				PUIElements.AddSizeFitter(toggle, DynamicSize);
			}
			PUIElements.SetToolTip(toggle, ToolTip).SetFlexUISize(FlexSize).SetActive(value: true);
			OnRealize?.Invoke(toggle);
			return toggle;
		}

		public override string ToString()
		{
			return $"PToggle[Name={Name}]";
		}
	}
}
