using System;

namespace PeterHan.PLib.UI
{
	[Serializable]
	internal sealed class GridComponent<T> : GridComponentSpec where T : class
	{
		public T Item { get; }

		internal GridComponent(GridComponentSpec spec, T item)
		{
			Alignment = spec.Alignment;
			Item = item;
			Column = spec.Column;
			ColumnSpan = spec.ColumnSpan;
			Margin = spec.Margin;
			Row = spec.Row;
			RowSpan = spec.RowSpan;
		}
	}
}
