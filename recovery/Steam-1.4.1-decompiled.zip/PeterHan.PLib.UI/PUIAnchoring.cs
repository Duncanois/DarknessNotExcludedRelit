namespace PeterHan.PLib.UI
{
	internal enum PUIAnchoring
	{
		Stretch,
		Beginning,
		Center,
		End
	}
}
