using System;
using PeterHan.PLib.UI.Layouts;
using UnityEngine;
using UnityEngine.UI;

namespace PeterHan.PLib.UI
{
	internal sealed class CardLayoutGroup : AbstractLayoutGroup
	{
		private CardLayoutResults horizontal;

		[SerializeField]
		private RectOffset margin;

		private CardLayoutResults vertical;

		public RectOffset Margin
		{
			get
			{
				return margin;
			}
			set
			{
				margin = value;
			}
		}

		private static CardLayoutResults Calc(GameObject obj, PanelDirection direction)
		{
			RectTransform rectTransform = obj.AddOrGet<RectTransform>();
			int childCount = rectTransform.childCount;
			CardLayoutResults cardLayoutResults = new CardLayoutResults(direction, childCount);
			ListPool<Component, BoxLayoutGroup>.PooledList pooledList = ListPool<Component, BoxLayoutGroup>.Allocate();
			for (int i = 0; i < childCount; i++)
			{
				GameObject gameObject = rectTransform.GetChild(i)?.gameObject;
				if (gameObject != null)
				{
					bool activeInHierarchy = gameObject.activeInHierarchy;
					pooledList.Clear();
					gameObject.GetComponents(pooledList);
					gameObject.SetActive(value: true);
					LayoutSizes layoutSizes = PUIUtils.CalcSizes(gameObject, direction, pooledList);
					if (!layoutSizes.ignore)
					{
						cardLayoutResults.Expand(layoutSizes);
						cardLayoutResults.children.Add(layoutSizes);
					}
					gameObject.SetActive(activeInHierarchy);
				}
			}
			pooledList.Recycle();
			return cardLayoutResults;
		}

		private static void DoLayout(RectOffset margin, CardLayoutResults required, float size)
		{
			if (required == null)
			{
				throw new ArgumentNullException("required");
			}
			PanelDirection direction = required.direction;
			ListPool<ILayoutController, BoxLayoutGroup>.PooledList pooledList = ListPool<ILayoutController, BoxLayoutGroup>.Allocate();
			size = ((direction != PanelDirection.Horizontal) ? (size - (float)(margin.top + margin.bottom)) : (size - (float)(margin.left + margin.right)));
			foreach (LayoutSizes child in required.children)
			{
				GameObject source = child.source;
				if (!(source != null))
				{
					continue;
				}
				float properSize = PUIUtils.GetProperSize(child, size);
				RectTransform rectTransform = source.AddOrGet<RectTransform>();
				if (direction == PanelDirection.Horizontal)
				{
					rectTransform.SetInsetAndSizeFromParentEdge(RectTransform.Edge.Left, margin.left, properSize);
				}
				else
				{
					rectTransform.SetInsetAndSizeFromParentEdge(RectTransform.Edge.Top, margin.top, properSize);
				}
				pooledList.Clear();
				source.GetComponents(pooledList);
				foreach (ILayoutController item in pooledList)
				{
					if (direction == PanelDirection.Horizontal)
					{
						item.SetLayoutHorizontal();
					}
					else
					{
						item.SetLayoutVertical();
					}
				}
			}
			pooledList.Recycle();
		}

		internal CardLayoutGroup()
		{
			horizontal = null;
			layoutPriority = 1;
			vertical = null;
		}

		public override void CalculateLayoutInputHorizontal()
		{
			if (!locked)
			{
				RectOffset rectOffset = Margin;
				float num = ((rectOffset == null) ? 0f : ((float)(rectOffset.left + rectOffset.right)));
				horizontal = Calc(gameObject, PanelDirection.Horizontal);
				LayoutSizes total = horizontal.total;
				minWidth = total.min + num;
				preferredWidth = total.preferred + num;
			}
		}

		public override void CalculateLayoutInputVertical()
		{
			if (!locked)
			{
				RectOffset rectOffset = Margin;
				float num = ((rectOffset == null) ? 0f : ((float)(rectOffset.top + rectOffset.bottom)));
				vertical = Calc(gameObject, PanelDirection.Vertical);
				LayoutSizes total = vertical.total;
				minHeight = total.min + num;
				preferredHeight = total.preferred + num;
			}
		}

		protected override void OnDisable()
		{
			base.OnDisable();
			horizontal = null;
			vertical = null;
		}

		protected override void OnEnable()
		{
			base.OnEnable();
			horizontal = null;
			vertical = null;
		}

		public void SetActiveCard(GameObject card)
		{
			int childCount = transform.childCount;
			for (int i = 0; i < childCount; i++)
			{
				GameObject gameObject = transform.GetChild(i)?.gameObject;
				if (gameObject != null)
				{
					gameObject.SetActive(gameObject == card);
				}
			}
		}

		public void SetActiveCard(int index)
		{
			int childCount = transform.childCount;
			for (int i = 0; i < childCount; i++)
			{
				GameObject gameObject = transform.GetChild(i)?.gameObject;
				if (gameObject != null)
				{
					gameObject.SetActive(i == index);
				}
			}
		}

		public override void SetLayoutHorizontal()
		{
			if (horizontal != null && !locked)
			{
				DoLayout(Margin ?? new RectOffset(), horizontal, rectTransform.rect.width);
			}
		}

		public override void SetLayoutVertical()
		{
			if (vertical != null && !locked)
			{
				DoLayout(Margin ?? new RectOffset(), vertical, rectTransform.rect.height);
			}
		}
	}
}
