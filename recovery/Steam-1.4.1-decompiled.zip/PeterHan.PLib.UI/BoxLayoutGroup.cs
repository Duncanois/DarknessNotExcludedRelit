using System;
using PeterHan.PLib.UI.Layouts;
using UnityEngine;
using UnityEngine.UI;

namespace PeterHan.PLib.UI
{
	internal sealed class BoxLayoutGroup : AbstractLayoutGroup
	{
		private BoxLayoutResults horizontal;

		[SerializeField]
		private BoxLayoutParams parameters;

		private BoxLayoutResults vertical;

		public BoxLayoutParams Params
		{
			get
			{
				return parameters;
			}
			set
			{
				parameters = value ?? throw new ArgumentNullException("Params");
			}
		}

		private static BoxLayoutResults Calc(GameObject obj, BoxLayoutParams args, PanelDirection direction)
		{
			RectTransform rectTransform = obj.AddOrGet<RectTransform>();
			int childCount = rectTransform.childCount;
			BoxLayoutResults boxLayoutResults = new BoxLayoutResults(direction, childCount);
			ListPool<Component, BoxLayoutGroup>.PooledList pooledList = ListPool<Component, BoxLayoutGroup>.Allocate();
			for (int i = 0; i < childCount; i++)
			{
				GameObject gameObject = rectTransform.GetChild(i)?.gameObject;
				if (!(gameObject != null) || !gameObject.activeInHierarchy)
				{
					continue;
				}
				pooledList.Clear();
				gameObject.GetComponents(pooledList);
				LayoutSizes layoutSizes = PUIUtils.CalcSizes(gameObject, direction, pooledList);
				if (!layoutSizes.ignore)
				{
					if (args.Direction == direction)
					{
						boxLayoutResults.Accum(layoutSizes, args.Spacing);
					}
					else
					{
						boxLayoutResults.Expand(layoutSizes);
					}
					boxLayoutResults.children.Add(layoutSizes);
				}
			}
			pooledList.Recycle();
			return boxLayoutResults;
		}

		private static void DoLayout(BoxLayoutParams args, BoxLayoutResults required, float size)
		{
			if (required == null)
			{
				throw new ArgumentNullException("required");
			}
			PanelDirection direction = required.direction;
			BoxLayoutStatus status = new BoxLayoutStatus(direction, args.Margin ?? new RectOffset(), size);
			if (args.Direction == direction)
			{
				DoLayoutLinear(required, args, status);
			}
			else
			{
				DoLayoutPerp(required, args, status);
			}
		}

		private static void DoLayoutLinear(BoxLayoutResults required, BoxLayoutParams args, BoxLayoutStatus status)
		{
			LayoutSizes total = required.total;
			ListPool<ILayoutController, BoxLayoutGroup>.PooledList pooledList = ListPool<ILayoutController, BoxLayoutGroup>.Allocate();
			PanelDirection direction = args.Direction;
			float size = status.size;
			float num = 0f;
			float min = total.min;
			float preferred = total.preferred;
			float num2 = Math.Max(0f, size - preferred);
			float flexible = total.flexible;
			float num3 = status.offset;
			float spacing = args.Spacing;
			if (size > min && preferred > min)
			{
				num = Math.Min(1f, (size - min) / (preferred - min));
			}
			if (num2 > 0f && flexible == 0f)
			{
				num3 += PUIUtils.GetOffset(args.Alignment, status.direction, num2);
			}
			foreach (LayoutSizes child in required.children)
			{
				GameObject source = child.source;
				if (!(source != null) || !source.activeInHierarchy)
				{
					continue;
				}
				float num4 = child.min;
				if (num > 0f)
				{
					num4 += (child.preferred - child.min) * num;
				}
				if (num2 > 0f && flexible > 0f)
				{
					num4 += num2 * child.flexible / flexible;
				}
				source.AddOrGet<RectTransform>().SetInsetAndSizeFromParentEdge(status.edge, num3, num4);
				num3 += num4 + ((num4 > 0f) ? spacing : 0f);
				pooledList.Clear();
				source.GetComponents(pooledList);
				foreach (ILayoutController item in pooledList)
				{
					if (direction == PanelDirection.Horizontal)
					{
						item.SetLayoutHorizontal();
					}
					else
					{
						item.SetLayoutVertical();
					}
				}
			}
			pooledList.Recycle();
		}

		private static void DoLayoutPerp(BoxLayoutResults required, BoxLayoutParams args, BoxLayoutStatus status)
		{
			ListPool<ILayoutController, BoxLayoutGroup>.PooledList pooledList = ListPool<ILayoutController, BoxLayoutGroup>.Allocate();
			PanelDirection direction = args.Direction;
			float size = status.size;
			foreach (LayoutSizes child in required.children)
			{
				GameObject source = child.source;
				if (!(source != null) || !source.activeInHierarchy)
				{
					continue;
				}
				float num = size;
				if (child.flexible <= 0f)
				{
					num = Math.Min(num, child.preferred);
				}
				float num2 = ((size > num) ? PUIUtils.GetOffset(args.Alignment, status.direction, size - num) : 0f);
				source.AddOrGet<RectTransform>().SetInsetAndSizeFromParentEdge(status.edge, num2 + status.offset, num);
				pooledList.Clear();
				source.GetComponents(pooledList);
				foreach (ILayoutController item in pooledList)
				{
					if (direction == PanelDirection.Horizontal)
					{
						item.SetLayoutVertical();
					}
					else
					{
						item.SetLayoutHorizontal();
					}
				}
			}
			pooledList.Recycle();
		}

		internal BoxLayoutGroup()
		{
			horizontal = null;
			layoutPriority = 1;
			parameters = new BoxLayoutParams();
			vertical = null;
		}

		public override void CalculateLayoutInputHorizontal()
		{
			if (!locked)
			{
				RectOffset margin = parameters.Margin;
				float num = ((margin == null) ? 0f : ((float)(margin.left + margin.right)));
				horizontal = Calc(gameObject, parameters, PanelDirection.Horizontal);
				LayoutSizes total = horizontal.total;
				minWidth = total.min + num;
				preferredWidth = total.preferred + num;
			}
		}

		public override void CalculateLayoutInputVertical()
		{
			if (!locked)
			{
				RectOffset margin = parameters.Margin;
				float num = ((margin == null) ? 0f : ((float)(margin.top + margin.bottom)));
				vertical = Calc(gameObject, parameters, PanelDirection.Vertical);
				LayoutSizes total = vertical.total;
				minHeight = total.min + num;
				preferredHeight = total.preferred + num;
			}
		}

		protected override void OnDisable()
		{
			base.OnDisable();
			horizontal = null;
			vertical = null;
		}

		protected override void OnEnable()
		{
			base.OnEnable();
			horizontal = null;
			vertical = null;
		}

		public override void SetLayoutHorizontal()
		{
			if (horizontal != null && !locked)
			{
				DoLayout(parameters, horizontal, rectTransform.rect.width);
			}
		}

		public override void SetLayoutVertical()
		{
			if (vertical != null && !locked)
			{
				DoLayout(parameters, vertical, rectTransform.rect.height);
			}
		}
	}
}
