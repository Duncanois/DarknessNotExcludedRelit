using System;
using PeterHan.PLib.Core;
using UnityEngine;
using UnityEngine.UI;

namespace PeterHan.PLib.UI
{
	internal class PSliderSingle : IUIComponent
	{
		public bool CustomTrack { get; set; }

		public Slider.Direction Direction { get; set; }

		public Vector2 FlexSize { get; set; }

		public ColorStyleSetting HandleColor { get; set; }

		public float HandleSize { get; set; }

		public float InitialValue { get; set; }

		public bool IntegersOnly { get; set; }

		public float MaxValue { get; set; }

		public float MinValue { get; set; }

		public string Name { get; }

		public PUIDelegates.OnSliderDrag OnDrag { get; set; }

		public float PreferredLength { get; set; }

		public PUIDelegates.OnSliderChanged OnValueChanged { get; set; }

		public string ToolTip { get; set; }

		public float TrackSize { get; set; }

		public event PUIDelegates.OnRealize OnRealize;

		public static void SetCurrentValue(GameObject realized, float value)
		{
			if (realized != null && realized.TryGetComponent<KSlider>(out var component) && !value.IsNaNOrInfinity())
			{
				component.value = value.InRange(component.minValue, component.maxValue);
			}
		}

		public PSliderSingle()
			: this("SliderSingle")
		{
		}

		public PSliderSingle(string name)
		{
			CustomTrack = false;
			Direction = Slider.Direction.LeftToRight;
			HandleColor = PUITuning.Colors.ButtonPinkStyle;
			HandleSize = 16f;
			InitialValue = 0.5f;
			IntegersOnly = false;
			MaxValue = 1f;
			MinValue = 0f;
			Name = name;
			PreferredLength = 100f;
			TrackSize = 12f;
		}

		public PSliderSingle AddOnRealize(PUIDelegates.OnRealize onRealize)
		{
			OnRealize += onRealize;
			return this;
		}

		public GameObject Build()
		{
			if (MaxValue.IsNaNOrInfinity())
			{
				throw new ArgumentException("MaxValue");
			}
			if (MinValue.IsNaNOrInfinity())
			{
				throw new ArgumentException("MinValue");
			}
			if (MaxValue <= MinValue)
			{
				throw new ArgumentOutOfRangeException("MaxValue");
			}
			GameObject slider = PUIElements.CreateUI(null, Name);
			bool flag = Direction == Slider.Direction.BottomToTop || Direction == Slider.Direction.TopToBottom;
			ColorStyleSetting colorStyleSetting = HandleColor ?? PUITuning.Colors.ButtonBlueStyle;
			slider.SetActive(value: false);
			if (!CustomTrack)
			{
				Image image = slider.AddComponent<Image>();
				image.sprite = (flag ? PUITuning.Images.ScrollBorderVertical : PUITuning.Images.ScrollBorderHorizontal);
				image.type = Image.Type.Sliced;
			}
			GameObject gameObject = PUIElements.CreateUI(slider, "Fill");
			if (!CustomTrack)
			{
				Image image2 = gameObject.AddComponent<Image>();
				image2.sprite = (flag ? PUITuning.Images.ScrollHandleVertical : PUITuning.Images.ScrollHandleHorizontal);
				image2.color = colorStyleSetting.inactiveColor;
				image2.type = Image.Type.Sliced;
			}
			PUIElements.SetAnchorOffsets(gameObject, 1f, 1f, 1f, 1f);
			KSlider ks = slider.AddComponent<KSlider>();
			ks.maxValue = MaxValue;
			ks.minValue = MinValue;
			ks.value = (InitialValue.IsNaNOrInfinity() ? MinValue : InitialValue.InRange(MinValue, MaxValue));
			ks.wholeNumbers = IntegersOnly;
			ks.handleRect = CreateHandle(slider).rectTransform();
			ks.fillRect = gameObject.rectTransform();
			ks.SetDirection(Direction, includeRectLayouts: true);
			if (OnValueChanged != null)
			{
				ks.onValueChanged.AddListener((float value) =>
				{
					OnValueChanged(slider, value);
				});
			}
			if (OnDrag != null)
			{
				ks.onDrag += () =>
				{
					OnDrag(slider, ks.value);
				};
			}
			string tt = ToolTip;
			if (!string.IsNullOrEmpty(tt))
			{
				ToolTip toolTip = slider.AddComponent<ToolTip>();
				toolTip.OnToolTip = () => string.Format(tt, ks.value);
				toolTip.refreshWhileHovering = true;
			}
			slider.SetActive(value: true);
			slider.SetMinUISize(flag ? new Vector2(TrackSize, PreferredLength) : new Vector2(PreferredLength, TrackSize));
			slider.SetFlexUISize(FlexSize);
			OnRealize?.Invoke(slider);
			return slider;
		}

		private GameObject CreateHandle(GameObject slider)
		{
			GameObject gameObject = PUIElements.CreateUI(slider, "Handle", canvas: true, PUIAnchoring.Center, PUIAnchoring.Center);
			Image image = gameObject.AddComponent<Image>();
			image.sprite = PUITuning.Images.SliderHandle;
			image.preserveAspect = true;
			gameObject.SetUISize(new Vector2(HandleSize, HandleSize));
			float num = 0f;
			switch (Direction)
			{
			case Slider.Direction.TopToBottom:
				num = 90f;
				break;
			case Slider.Direction.RightToLeft:
				num = 180f;
				break;
			case Slider.Direction.BottomToTop:
				num = 270f;
				break;
			}
			if (num != 0f)
			{
				gameObject.transform.Rotate(new Vector3(0f, 0f, num));
			}
			return gameObject;
		}

		public PSliderSingle SetKleiPinkStyle()
		{
			HandleColor = PUITuning.Colors.ButtonPinkStyle;
			return this;
		}

		public PSliderSingle SetKleiBlueStyle()
		{
			HandleColor = PUITuning.Colors.ButtonBlueStyle;
			return this;
		}

		public override string ToString()
		{
			return $"PSliderSingle[Name={Name}]";
		}
	}
}
