using System;
using UnityEngine;
using UnityEngine.UI;

namespace PeterHan.PLib.UI
{
	internal class PCheckBox : PTextComponent
	{
		private const float CHECKBOX_MARGIN = 2f;

		public const int STATE_UNCHECKED = 0;

		public const int STATE_CHECKED = 1;

		public const int STATE_PARTIAL = 2;

		public ColorStyleSetting CheckColor { get; set; }

		public Color BackColor { get; set; }

		public Vector2 CheckSize { get; set; }

		public Color ComponentBackColor { get; set; }

		public int InitialState { get; set; }

		public PUIDelegates.OnChecked OnChecked { get; set; }

		private static ToggleState[] GenerateStates(ColorStyleSetting imageColor)
		{
			StatePresentationSetting statePresentationSetting = new StatePresentationSetting
			{
				color = imageColor.activeColor,
				use_color_on_hover = true,
				color_on_hover = imageColor.hoverColor,
				image_target = null,
				name = "Partial"
			};
			return new ToggleState[3]
			{
				new ToggleState
				{
					color = PUITuning.Colors.Transparent,
					color_on_hover = PUITuning.Colors.Transparent,
					sprite = null,
					use_color_on_hover = false,
					additional_display_settings = new StatePresentationSetting[1]
					{
						new StatePresentationSetting
						{
							color = imageColor.activeColor,
							use_color_on_hover = false,
							image_target = null,
							name = "Unchecked"
						}
					}
				},
				new ToggleState
				{
					color = imageColor.activeColor,
					color_on_hover = imageColor.hoverColor,
					sprite = PUITuning.Images.Checked,
					use_color_on_hover = true,
					additional_display_settings = new StatePresentationSetting[1] { statePresentationSetting }
				},
				new ToggleState
				{
					color = imageColor.activeColor,
					color_on_hover = imageColor.hoverColor,
					sprite = PUITuning.Images.Partial,
					use_color_on_hover = true,
					additional_display_settings = new StatePresentationSetting[1] { statePresentationSetting }
				}
			};
		}

		public static int GetCheckState(GameObject realized)
		{
			int result = 0;
			if (realized == null)
			{
				throw new ArgumentNullException("realized");
			}
			MultiToggle componentInChildren = realized.GetComponentInChildren<MultiToggle>();
			if (componentInChildren != null)
			{
				result = UIDetours.CURRENT_STATE.Get(componentInChildren);
			}
			return result;
		}

		public static void SetCheckState(GameObject realized, int state)
		{
			if (realized == null)
			{
				throw new ArgumentNullException("realized");
			}
			MultiToggle componentInChildren = realized.GetComponentInChildren<MultiToggle>();
			if (componentInChildren != null && UIDetours.CURRENT_STATE.Get(componentInChildren) != state)
			{
				UIDetours.CHANGE_STATE.Invoke(componentInChildren, state);
			}
		}

		public PCheckBox()
			: this(null)
		{
		}

		public PCheckBox(string name)
			: base(name ?? "CheckBox")
		{
			BackColor = PUITuning.Colors.BackgroundLight;
			CheckColor = null;
			CheckSize = new Vector2(16f, 16f);
			ComponentBackColor = PUITuning.Colors.Transparent;
			IconSpacing = 3;
			InitialState = 0;
			Sprite = null;
			Text = null;
			ToolTip = "";
		}

		public PCheckBox AddOnRealize(PUIDelegates.OnRealize onRealize)
		{
			OnRealize += onRealize;
			return this;
		}

		public override GameObject Build()
		{
			GameObject checkbox = PUIElements.CreateUI(null, Name);
			Vector2 actualSize = CheckSize;
			GameObject sprite = null;
			GameObject text = null;
			if (ComponentBackColor.a > 0f)
			{
				checkbox.AddComponent<Image>().color = ComponentBackColor;
			}
			ColorStyleSetting colorStyleSetting = CheckColor ?? PUITuning.Colors.ComponentLightStyle;
			GameObject gameObject = PUIElements.CreateUI(checkbox, "CheckBox");
			gameObject.AddComponent<Image>().color = BackColor;
			Image toggle_image = CreateCheckImage(gameObject, colorStyleSetting, ref actualSize);
			gameObject.SetUISize(new Vector2(actualSize.x + 4f, actualSize.y + 4f), addLayout: true);
			if (Sprite != null)
			{
				sprite = PTextComponent.ImageChildHelper(checkbox, this).gameObject;
			}
			if (!string.IsNullOrEmpty(Text))
			{
				text = PTextComponent.TextChildHelper(checkbox, TextStyle ?? PUITuning.Fonts.UILightStyle, Text).gameObject;
			}
			MultiToggle mToggle = checkbox.AddComponent<MultiToggle>();
			PUIDelegates.OnChecked evt = OnChecked;
			if (evt != null)
			{
				MultiToggle multiToggle = mToggle;
				multiToggle.onClick = (System.Action)Delegate.Combine(multiToggle.onClick, (System.Action)(() =>
				{
					evt(checkbox, mToggle.CurrentState);
				}));
			}
			UIDetours.PLAY_SOUND_CLICK.Set(mToggle, arg2: true);
			UIDetours.PLAY_SOUND_RELEASE.Set(mToggle, arg2: false);
			mToggle.states = GenerateStates(colorStyleSetting);
			mToggle.toggle_image = toggle_image;
			UIDetours.CHANGE_STATE.Invoke(mToggle, InitialState);
			PUIElements.SetToolTip(checkbox, ToolTip).SetActive(value: true);
			GameObject text2 = WrapTextAndSprite(text, sprite);
			RelativeLayoutGroup relativeLayoutGroup = checkbox.AddComponent<RelativeLayoutGroup>();
			relativeLayoutGroup.Margin = Margin;
			PTextComponent.ArrangeComponent(relativeLayoutGroup, WrapTextAndSprite(text2, gameObject), TextAlignment);
			if (!DynamicSize)
			{
				relativeLayoutGroup.LockLayout();
			}
			relativeLayoutGroup.flexibleWidth = FlexSize.x;
			relativeLayoutGroup.flexibleHeight = FlexSize.y;
			DestroyLayoutIfPossible(checkbox);
			InvokeRealize(checkbox);
			return checkbox;
		}

		private Image CreateCheckImage(GameObject checkbox, ColorStyleSetting color, ref Vector2 actualSize)
		{
			Image image = PUIElements.CreateUI(checkbox, "CheckBorder").AddComponent<Image>();
			image.sprite = PUITuning.Images.CheckBorder;
			image.color = color.activeColor;
			image.type = Image.Type.Sliced;
			GameObject gameObject = PUIElements.CreateUI(checkbox, "CheckMark", canvas: true, PUIAnchoring.Center, PUIAnchoring.Center);
			Image image2 = gameObject.AddComponent<Image>();
			image2.sprite = PUITuning.Images.Checked;
			image2.preserveAspect = true;
			if (actualSize.x <= 0f || actualSize.y <= 0f)
			{
				RectTransform rect = gameObject.rectTransform();
				actualSize.x = LayoutUtility.GetPreferredWidth(rect);
				actualSize.y = LayoutUtility.GetPreferredHeight(rect);
			}
			gameObject.SetUISize(CheckSize);
			return image2;
		}

		public PCheckBox SetKleiPinkStyle()
		{
			TextStyle = PUITuning.Fonts.UILightStyle;
			BackColor = PUITuning.Colors.ButtonPinkStyle.inactiveColor;
			CheckColor = PUITuning.Colors.ComponentDarkStyle;
			return this;
		}

		public PCheckBox SetKleiBlueStyle()
		{
			TextStyle = PUITuning.Fonts.UILightStyle;
			BackColor = PUITuning.Colors.ButtonBlueStyle.inactiveColor;
			CheckColor = PUITuning.Colors.ComponentDarkStyle;
			return this;
		}
	}
}
