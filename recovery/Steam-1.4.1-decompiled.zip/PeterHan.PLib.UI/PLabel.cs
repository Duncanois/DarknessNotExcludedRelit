using UnityEngine;
using UnityEngine.UI;

namespace PeterHan.PLib.UI
{
	internal class PLabel : PTextComponent
	{
		public Color BackColor { get; set; }

		public PLabel()
			: this(null)
		{
		}

		public PLabel(string name)
			: base(name ?? "Label")
		{
			BackColor = PUITuning.Colors.Transparent;
		}

		public PLabel AddOnRealize(PUIDelegates.OnRealize onRealize)
		{
			OnRealize += onRealize;
			return this;
		}

		public override GameObject Build()
		{
			GameObject gameObject = PUIElements.CreateUI(null, Name);
			GameObject sprite = null;
			GameObject text = null;
			if (BackColor.a > 0f)
			{
				gameObject.AddComponent<Image>().color = BackColor;
			}
			if (Sprite != null)
			{
				sprite = PTextComponent.ImageChildHelper(gameObject, this).gameObject;
			}
			if (!string.IsNullOrEmpty(Text))
			{
				text = PTextComponent.TextChildHelper(gameObject, TextStyle ?? PUITuning.Fonts.UILightStyle, Text).gameObject;
			}
			PUIElements.SetToolTip(gameObject, ToolTip).SetActive(value: true);
			RelativeLayoutGroup relativeLayoutGroup = gameObject.AddComponent<RelativeLayoutGroup>();
			relativeLayoutGroup.Margin = Margin;
			PTextComponent.ArrangeComponent(relativeLayoutGroup, WrapTextAndSprite(text, sprite), TextAlignment);
			if (!DynamicSize)
			{
				relativeLayoutGroup.LockLayout();
			}
			relativeLayoutGroup.flexibleWidth = FlexSize.x;
			relativeLayoutGroup.flexibleHeight = FlexSize.y;
			DestroyLayoutIfPossible(gameObject);
			InvokeRealize(gameObject);
			return gameObject;
		}

		public PLabel SetKleiBlueColor()
		{
			BackColor = PUITuning.Colors.ButtonBlueStyle.inactiveColor;
			return this;
		}

		public PLabel SetKleiPinkColor()
		{
			BackColor = PUITuning.Colors.ButtonPinkStyle.inactiveColor;
			return this;
		}
	}
}
