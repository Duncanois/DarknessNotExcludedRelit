using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace PeterHan.PLib.UI
{
	internal sealed class PTextFieldEvents : KScreen
	{
		[MyCmpReq]
		private TMP_InputField textEntry;

		private bool editing;

		[SerializeField]
		internal PUIDelegates.OnTextChanged OnTextChanged { get; set; }

		[SerializeField]
		internal TMP_InputField.OnValidateInput OnValidate { get; set; }

		[SerializeField]
		internal GameObject TextObject { get; set; }

		internal PTextFieldEvents()
		{
			activateOnSpawn = true;
			editing = false;
			TextObject = null;
		}

		private IEnumerator DelayEndEdit()
		{
			yield return new WaitForEndOfFrame();
			StopEditing();
		}

		public override float GetSortKey()
		{
			if (!editing)
			{
				return base.GetSortKey();
			}
			return 99f;
		}

		protected override void OnCleanUp()
		{
			TMP_InputField tMP_InputField = textEntry;
			tMP_InputField.onFocus = (System.Action)Delegate.Remove(tMP_InputField.onFocus, new System.Action(OnFocus));
			textEntry.onValueChanged.RemoveListener(OnValueChanged);
			textEntry.onEndEdit.RemoveListener(OnEndEdit);
			base.OnCleanUp();
		}

		protected override void OnSpawn()
		{
			base.OnSpawn();
			TMP_InputField tMP_InputField = textEntry;
			tMP_InputField.onFocus = (System.Action)Delegate.Combine(tMP_InputField.onFocus, new System.Action(OnFocus));
			textEntry.onValueChanged.AddListener(OnValueChanged);
			textEntry.onEndEdit.AddListener(OnEndEdit);
			if (OnValidate != null)
			{
				textEntry.onValidateInput = OnValidate;
			}
		}

		private void OnEndEdit(string text)
		{
			GameObject gameObject = base.gameObject;
			if (gameObject != null)
			{
				OnTextChanged?.Invoke(gameObject, text);
				if (gameObject.activeInHierarchy)
				{
					StartCoroutine(DelayEndEdit());
				}
			}
		}

		private void OnFocus()
		{
			editing = true;
			textEntry.Select();
			textEntry.ActivateInputField();
			KScreenManager.Instance.RefreshStack();
		}

		public override void OnKeyDown(KButtonEvent e)
		{
			if (editing)
			{
				e.Consumed = true;
			}
			else
			{
				base.OnKeyDown(e);
			}
		}

		public override void OnKeyUp(KButtonEvent e)
		{
			if (editing)
			{
				e.Consumed = true;
			}
			else
			{
				base.OnKeyUp(e);
			}
		}

		private void OnValueChanged(string text)
		{
			if (gameObject != null && TextObject != null)
			{
				RectTransform rectTransform = TextObject.rectTransform();
				rectTransform.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, LayoutUtility.GetPreferredHeight(rectTransform));
			}
		}

		private void StopEditing()
		{
			if (textEntry != null && textEntry.gameObject.activeInHierarchy)
			{
				textEntry.DeactivateInputField();
			}
			editing = false;
		}
	}
}
