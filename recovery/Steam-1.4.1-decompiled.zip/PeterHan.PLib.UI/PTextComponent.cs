using PeterHan.PLib.Core;
using PeterHan.PLib.UI.Layouts;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace PeterHan.PLib.UI
{
	internal abstract class PTextComponent : IDynamicSizable, IUIComponent
	{
		private static readonly Vector2 CENTER = new Vector2(0.5f, 0.5f);

		public bool DynamicSize { get; set; }

		public Vector2 FlexSize { get; set; }

		public int IconSpacing { get; set; }

		public bool MaintainSpriteAspect { get; set; }

		public RectOffset Margin { get; set; }

		public string Name { get; }

		public Sprite Sprite { get; set; }

		public Image.Type SpriteMode { get; set; }

		public TextAnchor SpritePosition { get; set; }

		public Vector2 SpriteSize { get; set; }

		public Color SpriteTint { get; set; }

		public ImageTransform SpriteTransform { get; set; }

		public string Text { get; set; }

		public TextAnchor TextAlignment { get; set; }

		public TextStyleSetting TextStyle { get; set; }

		public string ToolTip { get; set; }

		public event PUIDelegates.OnRealize OnRealize;

		protected static void ArrangeComponent(RelativeLayoutGroup layout, GameObject target, TextAnchor alignment)
		{
			switch (alignment)
			{
			case TextAnchor.UpperLeft:
			case TextAnchor.MiddleLeft:
			case TextAnchor.LowerLeft:
				layout.SetLeftEdge(target, 0f);
				break;
			case TextAnchor.UpperRight:
			case TextAnchor.MiddleRight:
			case TextAnchor.LowerRight:
				layout.SetRightEdge(target, 1f);
				break;
			default:
				layout.AnchorXAxis(target);
				break;
			}
			switch (alignment)
			{
			case TextAnchor.LowerLeft:
			case TextAnchor.LowerCenter:
			case TextAnchor.LowerRight:
				layout.SetBottomEdge(target, 0f);
				break;
			case TextAnchor.UpperLeft:
			case TextAnchor.UpperCenter:
			case TextAnchor.UpperRight:
				layout.SetTopEdge(target, 1f);
				break;
			default:
				layout.AnchorYAxis(target);
				break;
			}
		}

		protected static Image ImageChildHelper(GameObject parent, PTextComponent settings)
		{
			GameObject gameObject = PUIElements.CreateUI(parent, "Image", canvas: true, PUIAnchoring.Beginning, PUIAnchoring.Beginning);
			gameObject.rectTransform().pivot = CENTER;
			Image image = gameObject.AddComponent<Image>();
			image.color = settings.SpriteTint;
			image.sprite = settings.Sprite;
			image.type = settings.SpriteMode;
			image.preserveAspect = settings.MaintainSpriteAspect;
			Vector3 one = Vector3.one;
			float num = 0f;
			ImageTransform spriteTransform = settings.SpriteTransform;
			if ((spriteTransform & ImageTransform.FlipHorizontal) != 0)
			{
				one.x = -1f;
			}
			if ((spriteTransform & ImageTransform.FlipVertical) != 0)
			{
				one.y = -1f;
			}
			if ((spriteTransform & ImageTransform.Rotate90) != 0)
			{
				num = 90f;
			}
			if ((spriteTransform & ImageTransform.Rotate180) != 0)
			{
				num += 180f;
			}
			RectTransform rectTransform = gameObject.rectTransform();
			rectTransform.localScale = one;
			rectTransform.Rotate(new Vector3(0f, 0f, num));
			Vector2 spriteSize = settings.SpriteSize;
			if (spriteSize.x > 0f && spriteSize.y > 0f)
			{
				gameObject.SetUISize(spriteSize, addLayout: true);
			}
			return image;
		}

		protected static LocText TextChildHelper(GameObject parent, TextStyleSetting style, string contents = "")
		{
			LocText locText = PUIElements.AddLocText(PUIElements.CreateUI(parent, "Text"), style);
			locText.alignment = TextAlignmentOptions.Center;
			locText.text = contents;
			return locText;
		}

		protected PTextComponent(string name)
		{
			DynamicSize = false;
			FlexSize = Vector2.zero;
			IconSpacing = 0;
			MaintainSpriteAspect = true;
			Margin = null;
			Name = name;
			Sprite = null;
			SpriteMode = Image.Type.Simple;
			SpritePosition = TextAnchor.MiddleLeft;
			SpriteSize = Vector2.zero;
			SpriteTint = Color.white;
			SpriteTransform = ImageTransform.None;
			Text = null;
			TextAlignment = TextAnchor.MiddleCenter;
			TextStyle = null;
			ToolTip = "";
		}

		public abstract GameObject Build();

		protected void DestroyLayoutIfPossible(GameObject component)
		{
			if (FlexSize.x == 0f && FlexSize.y == 0f && !DynamicSize)
			{
				AbstractLayoutGroup.DestroyAndReplaceLayout(component);
			}
		}

		protected void InvokeRealize(GameObject obj)
		{
			OnRealize?.Invoke(obj);
		}

		public override string ToString()
		{
			return string.Format("{3}[Name={0},Text={1},Sprite={2}]", Name, Text, Sprite, GetType().Name);
		}

		protected GameObject WrapTextAndSprite(GameObject text, GameObject sprite)
		{
			GameObject gameObject = null;
			if (text != null && sprite != null)
			{
				gameObject = PUIElements.CreateUI(text.GetParent(), "AlignmentWrapper");
				text.SetParent(gameObject);
				sprite.SetParent(gameObject);
				RelativeLayoutGroup relativeLayoutGroup = gameObject.AddOrGet<RelativeLayoutGroup>();
				switch (SpritePosition)
				{
				case TextAnchor.UpperLeft:
				case TextAnchor.MiddleLeft:
				case TextAnchor.LowerLeft:
					relativeLayoutGroup.SetLeftEdge(sprite, 0f).SetLeftEdge(text, -1f, sprite).SetMargin(sprite, new RectOffset(0, IconSpacing, 0, 0));
					break;
				case TextAnchor.UpperRight:
				case TextAnchor.MiddleRight:
				case TextAnchor.LowerRight:
					relativeLayoutGroup.SetRightEdge(sprite, 1f).SetRightEdge(text, -1f, sprite).SetMargin(sprite, new RectOffset(IconSpacing, 0, 0, 0));
					break;
				default:
					relativeLayoutGroup.AnchorXAxis(text).AnchorXAxis(sprite);
					break;
				}
				switch (SpritePosition)
				{
				case TextAnchor.UpperLeft:
				case TextAnchor.UpperCenter:
				case TextAnchor.UpperRight:
					relativeLayoutGroup.SetTopEdge(sprite, 1f).SetTopEdge(text, -1f, sprite).SetMargin(sprite, new RectOffset(0, 0, 0, IconSpacing));
					break;
				case TextAnchor.LowerLeft:
				case TextAnchor.LowerCenter:
				case TextAnchor.LowerRight:
					relativeLayoutGroup.SetBottomEdge(sprite, 0f).SetBottomEdge(text, -1f, sprite).SetMargin(sprite, new RectOffset(0, 0, IconSpacing, 0));
					break;
				default:
					relativeLayoutGroup.AnchorYAxis(text).AnchorYAxis(sprite);
					break;
				}
				if (!DynamicSize)
				{
					relativeLayoutGroup.LockLayout();
				}
			}
			else if (text != null)
			{
				gameObject = text;
			}
			else if (sprite != null)
			{
				gameObject = sprite;
			}
			return gameObject;
		}
	}
}
