using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace PeterHan.PLib.UI
{
	internal static class PUITuning
	{
		public static class Images
		{
			private static readonly IDictionary<string, Sprite> SPRITES;

			public static Sprite Arrow { get; }

			public static Sprite BoxBorder { get; }

			public static Sprite BoxBorderWhite { get; }

			public static Sprite ButtonBorder { get; }

			public static Sprite CheckBorder { get; }

			public static Sprite Checked { get; }

			public static Sprite Close { get; }

			public static Sprite Contract { get; }

			public static Sprite Expand { get; }

			public static Sprite Partial { get; }

			public static Sprite ScrollBorderHorizontal { get; }

			public static Sprite ScrollHandleHorizontal { get; }

			public static Sprite ScrollBorderVertical { get; }

			public static Sprite ScrollHandleVertical { get; }

			public static Sprite SliderHandle { get; }

			static Images()
			{
				SPRITES = new Dictionary<string, Sprite>(512);
				Sprite[] array = Resources.FindObjectsOfTypeAll<Sprite>();
				foreach (Sprite sprite in array)
				{
					string text = sprite?.name;
					if (!string.IsNullOrEmpty(text) && !SPRITES.ContainsKey(text))
					{
						SPRITES.Add(text, sprite);
					}
				}
				Arrow = GetSpriteByName("game_speed_play");
				BoxBorder = GetSpriteByName("web_box");
				BoxBorderWhite = GetSpriteByName("web_border");
				ButtonBorder = GetSpriteByName("web_button");
				CheckBorder = GetSpriteByName("overview_jobs_skill_box");
				Checked = GetSpriteByName("overview_jobs_icon_checkmark");
				Close = GetSpriteByName("cancel");
				Contract = GetSpriteByName("iconDown");
				Expand = GetSpriteByName("iconRight");
				Partial = GetSpriteByName("overview_jobs_icon_mixed");
				ScrollBorderHorizontal = GetSpriteByName("build_menu_scrollbar_frame_horizontal");
				ScrollHandleHorizontal = GetSpriteByName("build_menu_scrollbar_inner_horizontal");
				ScrollBorderVertical = GetSpriteByName("build_menu_scrollbar_frame");
				ScrollHandleVertical = GetSpriteByName("build_menu_scrollbar_inner");
				SliderHandle = GetSpriteByName("game_speed_selected_med");
			}

			public static Sprite GetSpriteByName(string name)
			{
				if (!SPRITES.TryGetValue(name, out var value))
				{
					return null;
				}
				return value;
			}
		}

		public static class Colors
		{
			public static Color BackgroundLight { get; }

			public static ColorStyleSetting ButtonPinkStyle { get; }

			public static ColorStyleSetting ButtonBlueStyle { get; }

			public static ColorStyleSetting ComponentDarkStyle { get; }

			public static ColorStyleSetting ComponentLightStyle { get; }

			public static Color DialogBackground { get; }

			public static Color DialogDarkBackground { get; }

			public static Color OptionsBackground { get; }

			public static ColorBlock ScrollbarColors { get; }

			public static Color SelectionBackground { get; }

			public static Color SelectionForeground { get; }

			public static Color Transparent { get; }

			public static Color UITextDark { get; }

			public static Color UITextLight { get; }

			static Colors()
			{
				BackgroundLight = new Color32(byte.MaxValue, byte.MaxValue, byte.MaxValue, byte.MaxValue);
				DialogBackground = new Color32(0, 0, 0, byte.MaxValue);
				DialogDarkBackground = new Color32(48, 52, 67, byte.MaxValue);
				OptionsBackground = new Color32(31, 34, 43, byte.MaxValue);
				SelectionBackground = new Color32(189, 218, byte.MaxValue, byte.MaxValue);
				SelectionForeground = new Color32(0, 0, 0, byte.MaxValue);
				Transparent = new Color32(byte.MaxValue, byte.MaxValue, byte.MaxValue, 0);
				UITextLight = new Color32(byte.MaxValue, byte.MaxValue, byte.MaxValue, byte.MaxValue);
				UITextDark = new Color32(0, 0, 0, byte.MaxValue);
				Color color = new Color(0f, 0f, 0f);
				Color color2 = new Color(0.784f, 0.784f, 0.784f, 1f);
				ComponentLightStyle = ScriptableObject.CreateInstance<ColorStyleSetting>();
				ComponentLightStyle.activeColor = color;
				ComponentLightStyle.inactiveColor = color;
				ComponentLightStyle.hoverColor = color;
				ComponentLightStyle.disabledActiveColor = color2;
				ComponentLightStyle.disabledColor = color2;
				ComponentLightStyle.disabledhoverColor = color2;
				color = new Color(1f, 1f, 1f);
				ComponentDarkStyle = ScriptableObject.CreateInstance<ColorStyleSetting>();
				ComponentDarkStyle.activeColor = color;
				ComponentDarkStyle.inactiveColor = color;
				ComponentDarkStyle.hoverColor = color;
				ComponentDarkStyle.disabledActiveColor = color2;
				ComponentDarkStyle.disabledColor = color2;
				ComponentDarkStyle.disabledhoverColor = color2;
				ButtonPinkStyle = ScriptableObject.CreateInstance<ColorStyleSetting>();
				ButtonPinkStyle.activeColor = new Color(27f / 34f, 0.4496107f, 0.6242238f);
				ButtonPinkStyle.inactiveColor = new Color(135f / 255f, 0.2724914f, 0.4009516f);
				ButtonPinkStyle.disabledColor = new Color(0.4156863f, 105f / 255f, 0.4f);
				ButtonPinkStyle.disabledActiveColor = Transparent;
				ButtonPinkStyle.hoverColor = new Color(0.6176471f, 0.3315311f, 0.4745891f);
				ButtonPinkStyle.disabledhoverColor = new Color(0.5f, 0.5f, 0.5f);
				ButtonBlueStyle = ScriptableObject.CreateInstance<ColorStyleSetting>();
				ButtonBlueStyle.activeColor = new Color(0.5033521f, 0.5444419f, 95f / 136f);
				ButtonBlueStyle.inactiveColor = new Color(0.2431373f, 67f / 255f, 0.3411765f);
				ButtonBlueStyle.disabledColor = new Color(0.4156863f, 105f / 255f, 0.4f);
				ButtonBlueStyle.disabledActiveColor = new Color(0.625f, 0.6158088f, 150f / 255f);
				ButtonBlueStyle.hoverColor = new Color(0.3461289f, 0.3739619f, 33f / 68f);
				ButtonBlueStyle.disabledhoverColor = new Color(0.5f, 0.4898898f, 0.4595588f);
				ScrollbarColors = new ColorBlock
				{
					colorMultiplier = 1f,
					fadeDuration = 0.1f,
					disabledColor = new Color(0.392f, 0.392f, 0.392f),
					highlightedColor = new Color32(161, 163, 174, byte.MaxValue),
					normalColor = new Color32(161, 163, 174, byte.MaxValue),
					pressedColor = BackgroundLight
				};
			}
		}

		public static class Fonts
		{
			private const string DEFAULT_FONT_TEXT = "NotoSans-Regular";

			private const string DEFAULT_FONT_UI = "GRAYSTROKE REGULAR SDF";

			private static readonly TMP_FontAsset DefaultTextFont;

			private static readonly TMP_FontAsset DefaultUIFont;

			private static readonly IDictionary<string, TMP_FontAsset> FONTS;

			public static int DefaultSize { get; }

			internal static TMP_FontAsset Text
			{
				get
				{
					TMP_FontAsset tMP_FontAsset = null;
					if (Localization.GetSelectedLanguageType() != Localization.SelectedLanguageType.None)
					{
						tMP_FontAsset = Localization.FontAsset;
					}
					return tMP_FontAsset ?? DefaultTextFont;
				}
			}

			public static TextStyleSetting TextDarkStyle { get; }

			public static TextStyleSetting TextLightStyle { get; }

			internal static TMP_FontAsset UI
			{
				get
				{
					TMP_FontAsset tMP_FontAsset = null;
					if (Localization.GetSelectedLanguageType() != Localization.SelectedLanguageType.None)
					{
						tMP_FontAsset = Localization.FontAsset;
					}
					return tMP_FontAsset ?? DefaultUIFont;
				}
			}

			public static TextStyleSetting UIDarkStyle { get; }

			public static TextStyleSetting UILightStyle { get; }

			static Fonts()
			{
				FONTS = new Dictionary<string, TMP_FontAsset>(16);
				TMP_FontAsset[] array = Resources.FindObjectsOfTypeAll<TMP_FontAsset>();
				foreach (TMP_FontAsset tMP_FontAsset in array)
				{
					string text = tMP_FontAsset?.name;
					if (!string.IsNullOrEmpty(text) && !FONTS.ContainsKey(text))
					{
						FONTS.Add(text, tMP_FontAsset);
					}
				}
				if ((DefaultTextFont = GetFontByName("NotoSans-Regular")) == null)
				{
					PUIUtils.LogUIWarning("Unable to find font NotoSans-Regular");
				}
				if ((DefaultUIFont = GetFontByName("GRAYSTROKE REGULAR SDF")) == null)
				{
					PUIUtils.LogUIWarning("Unable to find font GRAYSTROKE REGULAR SDF");
				}
				DefaultSize = 14;
				TextDarkStyle = ScriptableObject.CreateInstance<TextStyleSetting>();
				TextDarkStyle.enableWordWrapping = false;
				TextDarkStyle.fontSize = DefaultSize;
				TextDarkStyle.sdfFont = Text;
				TextDarkStyle.style = FontStyles.Normal;
				TextDarkStyle.textColor = Colors.UITextDark;
				TextLightStyle = TextDarkStyle.DeriveStyle(0, Colors.UITextLight);
				UIDarkStyle = ScriptableObject.CreateInstance<TextStyleSetting>();
				UIDarkStyle.enableWordWrapping = false;
				UIDarkStyle.fontSize = DefaultSize;
				UIDarkStyle.sdfFont = UI;
				UIDarkStyle.style = FontStyles.Normal;
				UIDarkStyle.textColor = Colors.UITextDark;
				UILightStyle = UIDarkStyle.DeriveStyle(0, Colors.UITextLight);
			}

			internal static TMP_FontAsset GetFontByName(string name)
			{
				if (!FONTS.TryGetValue(name, out var value))
				{
					return null;
				}
				return value;
			}
		}

		internal static ButtonSoundPlayer ButtonSounds { get; }

		internal static ToggleSoundPlayer ToggleSounds { get; }

		static PUITuning()
		{
			ButtonSounds = new ButtonSoundPlayer
			{
				Enabled = true
			};
			ToggleSounds = new ToggleSoundPlayer();
		}
	}
}
