namespace PeterHan.PLib.UI
{
	internal interface IDynamicSizable : IUIComponent
	{
		bool DynamicSize { get; set; }
	}
}
